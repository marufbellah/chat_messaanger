# Architecture

## 1. Backend layers (ek-mukhi dependency: upor theke niche)
```
Browser ── HTTP ──► app.js ─► routes/ ─► controllers/ ─► services/ ─► models/ ─► MongoDB
   │                  │ helmet, CORS, rate limit        │              │
   │                  └ error handler (middleware/)     │              └► realtime.js ─► Socket.IO ─► Browser (push)
   └─ Socket.IO ─► sockets/index.js (token check) ─► *.handlers.js ─► services/ (call log, block check)
```
| Layer | Kaj | Ja kora jabe na |
|---|---|---|
| `routes/` | URL ke controller er sathe jora, validation + auth middleware boshano | logic lekha |
| `controllers/` | `req` theke data niye service dake, `res.json` kore | DB query, business rule |
| `services/` | **Asol business rule** (message pathano, block check, token rotate...) | `req`/`res` bebohar |
| `models/` | Mongoose schema + index | business logic |
| `config/env.js` | env variable parse + validate (zod). Baki code `require('../config/env')` kore | `process.env` sorasori pora |
| `realtime.js` | Socket room niyom + emit helper | -- |

**Room niyom:** user room = `userId`, group room = `g:<groupId>`. Tai "ei user ke event pathao" = `rt.toUser(id, ev, data)`.

## 2. Auth flow
1. Login/register -> **access token** (JWT, 15 min) + **refresh token** (random, DB te sudhu SHA-256 hash).
2. Client `services/api.js` 401 pele refresh token diye notun jora ane (ek sathe onek request holeo ekbar). Refresh token **ekbar-i** cholbe (rotation).
3. Password reset/change, user inactive/delete hole shob refresh token batil -> sob device logout.
4. Forgot password / email verify: ek-bar-bebohar token (`AuthToken`, hash kore rakha, TTL index e nijei muche jay).
5. Socket: connect e access token check; expire hole client nijei refresh kore abar connect kore.

## 3. Message flow (ekta message pathano)
`POST /api/messages` -> `messageFile` (multer, memory) -> `messages.controller.send` -> `message.service.sendDirect`
(user/block check) -> `storage.save` (local/S3) -> `Message.create` -> `rt.toUser(to,'msg',m)` -> receiver er browser `useInbox` + `useMessages`.

## 4. Call flow (WebRTC)
Media browser-to-browser; server sudhu **signaling** (offer/answer/ICE) relay kore.
- 1:1: `sockets/call.handlers.js` + `call.service.js` (log: answered/missed/declined + duration). Client: `hooks/useCall.js`.
- Group: `sockets/groupCall.handlers.js` (ke ke call e, cap) + client `hooks/useGroupCall.js` (mesh). Notun-ashha user purono shobai ke offer pathay.
- TURN: `GET /api/ice` STUN + TURN (temporary HMAC credential) dey.
- Sound: `RemoteAudio` alada `<audio>`; video gulo muted -> double sound hoy na.

## 5. Frontend rules
- **services/** network + storage (UI jane na) · **context/** global state (login, theme/lang) · **hooks/** logic · **components/** sudhu UI (props niye render) · **pages/** jora lagay.
- Socket handler e stale state thekate `useSocketEvent` (shesh handler ref e rakhe).
- Text shob `i18n/translations.js` e (en + bn); component e hard-coded text nei.
- CSS: `styles/main.css` e design token (`--acc`, `--card` ...) + dark theme override.

## 6. Notun feature jora (step-by-step)
**Notun API:** (1) `validators/schemas.js` e zod schema, (2) `services/xyz.service.js` e logic, (3) `controllers/` e patla handler, (4) `routes/index.js` e line, (5) `server/test/e2e.js` e test, (6) `docs/API.md`.
**Notun real-time event:** `sockets/*.handlers.js` e handler ba service theke `rt.toUser/toGroup`; client e `useSocketEvent(socket,'event',fn)`.
**Notun UI text:** `i18n/translations.js` e en + bn dutoi.

## 7. Data model
`User` · `Message` (direct: `to`, group: `group`; reactions, replyTo, soft-delete) · `Group` · `Call` (log) · `Block` · `Audit` (admin action) · `RefreshToken` · `AuthToken`.
