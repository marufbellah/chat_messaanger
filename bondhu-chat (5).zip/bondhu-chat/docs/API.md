# API reference (`/api`)  — 🔒 = Bearer access token lagbe, 👑 = admin only
Error format: `{ "error": "message" }`. Validation fail = 400.

## Auth
| Method | Path | Body | Result |
|---|---|---|---|
| POST | `/auth/register` | name, email, password(6+) | `{token, refreshToken, user}` (verify email jay) |
| POST | `/auth/login` | email, password | `{token, refreshToken, user}` · 400 wrong · 403 inactive/unverified* |
| POST | `/auth/refresh` | refreshToken | notun `{token, refreshToken, user}` (purono ta batil) |
| POST | `/auth/logout` | refreshToken | session batil |
| POST | `/auth/forgot` | email | always `{ok}` (email ache kina bole na) |
| POST | `/auth/reset` | token, password | password set + login `{token,...}` + shob session batil |
| POST | `/auth/verify` | token | email verified |
| POST | `/auth/verify/resend` 🔒 | – | verify email abar |

\* `REQUIRE_VERIFIED=true` hole.

## Me / users / blocks 🔒
`GET /me` · `PUT /me {name}` · `PUT /me/password {current,password}` (notun session dey) · `POST /me/avatar` (multipart `file`) ·
`GET /users` → `{users, online}` · `GET /blocks` → `{blocked:[id]}` · `POST|DELETE /blocks/:id` · `GET /ice` · `GET /calls`

## Messages 🔒
| Method | Path | Note |
|---|---|---|
| GET | `/conversations` | `{last, unread}` |
| GET | `/messages/:userId?before=<ISO>&limit=50` | history (purono: `before`) |
| POST | `/messages` | multipart: `to`, `text?`, `file?`, `replyTo?` · 403 blocked |
| POST | `/messages/read/:userId` | read mark |
| PUT | `/messages/:id` | `{text}` ba multipart `file` (photo replace) ba `{removeFile:true}` |
| DELETE | `/messages/:id` | nijer message soft-delete |
| POST | `/messages/:id/react` | `{emoji}` (same emoji abar = off) |
| POST | `/messages/:id/forward` | `{users:[], groups:[]}` (file copy hoy) |

## Groups 🔒
`POST /groups {name, members}` · `GET /groups` · `PUT /groups/:id {name?, add?, remove?}` (owner) · `POST /groups/:id/leave` · `DELETE /groups/:id` (owner) ·
`GET /groups/:id/messages` · `POST /groups/:id/messages` (multipart)

## Admin 👑
`GET /admin/stats` · `GET /admin/users?q=` · `POST /admin/users` · `PUT /admin/users/:id` · `DELETE /admin/users/:id` · `DELETE /admin/messages/:id` · `GET /admin/logs`

## Socket.IO events
Connect: `io({auth:{token}})`. **Server → client:** `presence`, `msg`, `msg:edit`, `msg:delete`, `read`, `typing`, `group:update`,
`call:offer|answer|ice|end`, `gcall:active|peers|signal|left|full`.
**Client → server:** `typing {to|group}`, `call:offer|answer|ice|end {to,...}`, `gcall:join {group,video}`, `gcall:signal {to,group,data}`, `gcall:leave {group}`.
