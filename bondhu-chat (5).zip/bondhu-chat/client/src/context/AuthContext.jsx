import { createContext, useContext, useEffect, useState } from 'react';
import { api, onSessionExpired } from '../services/api';
import { session } from '../services/session';

// Ke login kora ache (me) + login/logout. Session expire hole nijei logout.
const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }) {
  const [me, setMe] = useState(null), [ready, setReady] = useState(false);
  useEffect(() => {
    onSessionExpired(() => setMe(null));
    if (!session.has()) { setReady(true); return; }
    api('/me').then(setMe).catch(() => session.clear()).finally(() => setReady(true));
  }, []);
  const start = (data) => { session.set(data); setMe(data.user); };
  const logout = () => {
    const refreshToken = session.refresh; session.clear(); setMe(null);
    if (refreshToken) fetch('/api/auth/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refreshToken }) }).catch(() => {}); // server e o token batil
  };
  return <Ctx.Provider value={{ me, setMe, ready, start, logout }}>{children}</Ctx.Provider>;
}
