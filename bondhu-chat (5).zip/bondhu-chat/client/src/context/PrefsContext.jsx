import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { translate } from '../i18n';
import { isMuted, setMuted, sfx } from '../utils/sounds';

// Theme (dark/light), bhasha (en/bn), sound mute -- shob jaygay lagbe tai context e
const Ctx = createContext(null);
export const usePrefs = () => useContext(Ctx);

export function PrefsProvider({ children }) {
  const [theme, setTheme] = useState(localStorage.theme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  const [lang, setLang] = useState(localStorage.lang || 'en'), [muted, setMute] = useState(isMuted());
  useEffect(() => { document.documentElement.dataset.theme = theme; localStorage.theme = theme; }, [theme]);
  useEffect(() => { document.documentElement.lang = lang; localStorage.lang = lang; }, [lang]);
  const t = useCallback((key) => translate(lang, key), [lang]);
  const value = useMemo(() => ({
    theme, lang, muted, t,
    toggleTheme: () => setTheme((x) => (x === 'dark' ? 'light' : 'dark')),
    toggleLang: () => setLang((x) => (x === 'en' ? 'bn' : 'en')),
    toggleMute: () => { const next = !muted; setMuted(next); setMute(next); if (!next) sfx.recv(); },
  }), [theme, lang, muted, t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
