import { createRoot } from 'react-dom/client';
import { PrefsProvider } from './context/PrefsContext';
import { AuthProvider } from './context/AuthContext';
import App from './App';
import './styles/main.css';

createRoot(document.getElementById('root')).render(
  <PrefsProvider><AuthProvider><App /></AuthProvider></PrefsProvider>,
);
