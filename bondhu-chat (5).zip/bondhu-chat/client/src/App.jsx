import { useEffect, useMemo, useState } from 'react';
import { api } from './services/api';
import { session } from './services/session';
import { useAuth } from './context/AuthContext';
import { usePrefs } from './context/PrefsContext';
import AuthPage from './components/auth/AuthPage';
import Header from './components/layout/Header';
import VerifyBanner from './components/layout/VerifyBanner';
import AdminPage from './components/admin/AdminPage';
import ChatPage from './pages/ChatPage';

// Top-level: login na thakle AuthPage, thakle Header + (Chat ba Admin)
export default function App() {
  const { me, setMe, ready } = useAuth(), { t } = usePrefs();
  const params = useMemo(() => new URLSearchParams(location.search), []);
  const [tab, setTab] = useState('chat'), [notice, setNotice] = useState(''), [resetToken, setResetToken] = useState(params.get('reset'));

  useEffect(() => { // email er "verify" link
    const token = params.get('verify'); if (!token) return;
    api('/auth/verify', { method: 'POST', body: { token }, auth: false })
      .then(() => { setNotice(t('verifyOk')); if (session.has()) api('/me').then(setMe).catch(() => {}); })
      .catch(() => setNotice(t('verifyBad'))).finally(() => history.replaceState({}, '', location.pathname));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  if (!ready) return null;
  if (!me) return <AuthPage resetToken={resetToken} onResetDone={() => setResetToken(null)} notice={notice} />;
  return (
    <div className="app">
      <Header tab={tab} setTab={setTab} />
      {!me.verified && <VerifyBanner />}
      {notice && <p className="notice">{notice}</p>}
      <main>{tab === 'chat' ? <ChatPage /> : <AdminPage />}</main>
    </div>
  );
}
