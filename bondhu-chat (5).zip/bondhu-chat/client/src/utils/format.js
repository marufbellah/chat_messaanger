export const fmt = (d) => new Date(d).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
export const hms = (s) => [s / 3600, (s / 60) % 60, s % 60].map((x) => String(Math.floor(x)).padStart(2, '0')).join(':');
// naam theke consistent rong (avatar er jonno)
export const hue = (s) => [...(s || '?')].reduce((a, c) => a + c.charCodeAt(0) * 7, 0) % 360;
// chat identify korar key: u:<userId> ba g:<groupId>
export const chatKey = (c) => (c ? c.k + ':' + c.o._id : '');
export const msgKey = (m) => (m.group ? 'g:' + m.group : 'u:' + m.from);
// sidebar/reply preview text
export const preview = (m, t) => (!m ? '' : m.deleted ? t('deleted') : m.type === 'image' ? '📷 ' + t('photo') : m.type === 'audio' ? '🎤 ' + t('record') : m.text || '📎');
