// WebRTC er shared config. ICE (STUN/TURN) server list server theke ashe (/api/ice).
import { api } from '../services/api';

export const rtc = { ice: { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] } };
export const loadIce = () => api('/ice').then((d) => { rtc.ice = d; }).catch(() => {});
export const AUDIO = { echoCancellation: true, noiseSuppression: true, autoGainControl: true };
export const mediaConstraints = (video) => ({ audio: AUDIO, video: video ? { width: { ideal: 1280 }, height: { ideal: 720 } } : false });
export const exposeForTests = (key, value) => { if (import.meta.env.DEV) window[key] = value; }; // sudhu dev/test e, production build e na
// mic ba camera on/off (track.enabled ulte dey)
export const toggleTrack = (stream, kind) => (kind === 'a' ? stream?.getAudioTracks() : stream?.getVideoTracks())?.forEach((t) => { t.enabled = !t.enabled; });
