let ctx, muted = localStorage.muted === '1';
export const isMuted = () => muted;
export const setMuted = v => { muted = v; localStorage.muted = v ? '1' : '0'; };
const tone = (f, at = 0, d = .12, v = .14) => {
  if (muted) return; try {
    const c = (ctx ||= new (window.AudioContext || window.webkitAudioContext)()); c.state === 'suspended' && c.resume();
    const o = c.createOscillator(), g = c.createGain(), s = c.currentTime + at; o.frequency.value = f; o.connect(g); g.connect(c.destination);
    g.gain.setValueAtTime(0, s); g.gain.linearRampToValueAtTime(v, s + .01); g.gain.exponentialRampToValueAtTime(.0001, s + d); o.start(s); o.stop(s + d + .02);
  } catch {}
};
export const sfx = { recv: () => { tone(880, 0, .12); tone(1175, .11, .18); }, sent: () => tone(660, 0, .07, .07), ring: () => { tone(523, 0, .25, .2); tone(659, .3, .25, .2); }, end: () => { tone(440, 0, .15); tone(330, .15, .2); } };
export const ringLoop = () => { sfx.ring(); const i = setInterval(sfx.ring, 1800); return () => clearInterval(i); };
