import { useEffect, useRef, useState } from 'react';
import { MessageCircle, Phone } from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { usePrefs } from '../context/PrefsContext';
import { useSocket } from '../hooks/useSocket';
import { useDirectory } from '../hooks/useDirectory';
import { useInbox } from '../hooks/useInbox';
import { useTyping } from '../hooks/useTyping';
import { useMessages } from '../hooks/useMessages';
import { useCall } from '../hooks/useCall';
import { useGroupCall } from '../hooks/useGroupCall';
import { loadIce } from '../utils/webrtc';
import { sfx } from '../utils/sounds';
import { chatKey } from '../utils/format';
import Sidebar from '../components/chat/Sidebar';
import ChatHeader from '../components/chat/ChatHeader';
import MessageList from '../components/chat/MessageList';
import Composer from '../components/chat/Composer';
import { ForwardModal, GroupInfoModal, NewGroupModal } from '../components/chat/Modals';
import MeetingRoom from '../components/call/MeetingRoom';
import RingingCard from '../components/call/RingingCard';

/**
 * Main chat screen. Ekhane sudhu "jora lagano" hoy -- asol kaj hooks/ ar components/ e:
 *   hooks/   -> data + real-time logic (users, messages, calls ...)
 *   components/ -> UI
 */
export default function ChatPage() {
  const { me, logout } = useAuth(), { t } = usePrefs();
  const socket = useSocket({ onKicked: logout, onAuthFail: logout });
  const [tab, setTab] = useState('u'), [chat, setChat] = useState(null), [q, setQ] = useState(''), [text, setText] = useState('');
  const [reply, setReply] = useState(null), [modal, setModal] = useState(null); // modal: 'newGroup' | 'info' | { fwd: message }
  const fileRef = useRef(), replaceRef = useRef(), replaceId = useRef();

  const dir = useDirectory(socket, me), inbox = useInbox(socket, chat, dir.users), typing = useTyping(socket, chat), messages = useMessages(socket, me, chat);
  const call = useCall(socket, me, { users: dir.users, onAccept: (peer) => { setTab('u'); setChat({ k: 'u', o: peer }); }, onError: () => alert(t('camErr')) });
  const gcall = useGroupCall(socket, me, { onFull: () => alert(t('callFull')), onError: () => alert(t('camErr')) });
  const key = chatKey(chat);

  useEffect(() => { loadIce(); }, []);
  useEffect(() => { if (chat) inbox.markOpen(key); setReply(null); setModal(null); }, [key]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { // group update hole (member add/remove, rename) open chat o refresh hoy; remove hole bondho
    if (chat?.k !== 'g') return;
    const g = dir.groups.find((x) => x._id === chat.o._id);
    g ? g !== chat.o && setChat({ k: 'g', o: g }) : setChat(null);
  }, [dir.groups]); // eslint-disable-line react-hooks/exhaustive-deps

  const nameOf = (id) => dir.nameOf(id, chat?.k === 'g' ? chat.o : null);
  const typingNames = Object.keys(typing.typers[key] || {}).map(nameOf);
  const typingText = typingNames.length ? typingNames.join(', ') + ' ' + t(typingNames.length > 1 ? 'areTyping' : 'isTyping') : '';
  const blocked = chat?.k === 'u' && dir.blocked.includes(chat.o._id);
  const groupCallInfo = chat?.k === 'g' && gcall.active[chat.o._id];
  const fail = (e) => alert(e.message);

  // ---- actions ----
  const send = async (file) => {
    const body = text.trim(); if (!body && !file) return;
    setText(''); setReply(null);
    try { const m = await messages.send({ text: body, file, replyTo: reply?._id }); inbox.setLast((x) => ({ ...x, [key]: m })); sfx.sent(); } catch (e) { fail(e); }
  };
  const createGroup = async (name, members) => {
    const g = await api('/groups', { method: 'POST', body: { name, members } }), list = await dir.refreshGroups();
    setModal(null); setTab('g'); setChat({ k: 'g', o: list.find((x) => x._id === g._id) });
  };
  const editGroup = async (body) => { try { await api('/groups/' + chat.o._id, { method: 'PUT', body }); await dir.refreshGroups(); } catch (e) { fail(e); } };
  const leaveGroup = async () => {
    const g = chat.o, owner = g.owner === me._id;
    await api(`/groups/${g._id}` + (owner ? '' : '/leave'), { method: owner ? 'DELETE' : 'POST' }); setModal(null); setChat(null); dir.refreshGroups();
  };
  const forward = async (users, groups) => {
    try { await messages.forward(modal.fwd, users, groups); if (users.includes(chat.o._id) || groups.includes(chat.o._id)) messages.reload(); setModal(null); sfx.sent(); } catch (e) { fail(e); }
  };
  const startCall = (video) => (chat.k === 'u' ? call.start(chat.o, video) : gcall.join(chat.o._id, video));
  const actions = {
    reply: setReply, forward: (m) => setModal({ fwd: m }), edit: messages.edit,
    remove: (m) => confirm(t('delMsg') + '?') && messages.remove(m).catch(fail),
    react: (m, e) => messages.react(m, e).catch(fail), removePhoto: (id) => messages.removePhoto(id).catch(fail),
    replacePhoto: (id) => { replaceId.current = id; replaceRef.current.click(); },
  };

  // ---- meeting (call screen) data: 1:1 ba group, duitor jonno ekoi format ----
  let meet = null;
  if (gcall.gc) {
    const { gc } = gcall, group = dir.groups.find((g) => g._id === gc.group);
    meet = { gbox: true, title: group?.name || '', video: gc.video, calling: false, end: gcall.leave, toggle: gcall.toggle, share: gcall.share, f: gc,
      inCall: gcall.active[gc.group]?.participants || [], members: group?.members || [],
      tiles: [{ id: 'me', name: me.name, self: true, stream: gc.local, off: gc.voff }, ...Object.entries(gc.streams).map(([uid, stream]) => ({ id: uid, name: dir.nameOf(uid, group), stream, pcOf: () => gcall.getPc(uid) }))] };
  } else if (call.call && call.call.state !== 'ringing') {
    const c = call.call;
    meet = { gbox: false, title: c.peer.name, video: c.video, calling: c.state === 'calling', end: call.hang, toggle: call.toggle, share: call.share, f: c, inCall: [me._id, c.peer._id], members: [me, c.peer],
      tiles: [{ id: 'peer', name: c.peer.name, user: c.peer, stream: call.rs, pcOf: call.getPc }, { id: 'me', name: me.name, self: true, stream: call.ls, off: c.voff }] };
  }

  const items = (tab === 'u' ? dir.users : dir.groups).filter((x) => x.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className={'chat ' + (chat ? 'open' : '')}>
      <Sidebar tab={tab} setTab={setTab} q={q} setQ={setQ} items={items} chat={chat} onPick={setChat} last={inbox.last} unread={inbox.unread}
        typers={typing.typers} isOn={dir.isOn} onNewGroup={() => setModal('newGroup')} />
      <section className="room">
        {!chat ? <div className="placeholder"><MessageCircle size={56} strokeWidth={1.2} /><p>{t('pick')}</p></div> : (
          <>
            <ChatHeader chat={chat} me={me} isOn={dir.isOn} typingText={typingText} blocked={blocked} groupCallActive={!!gcall.gc} onBack={() => setChat(null)}
              onCall={startCall} onInfo={() => setModal('info')} onToggleBlock={() => dir.toggleBlock(chat.o._id).catch(fail)} />
            {groupCallInfo && !gcall.gc && <div className="banner"><Phone size={16} /> {t('callOn')} · {groupCallInfo.participants.length}<button className="btn sm" onClick={() => gcall.join(chat.o._id, groupCallInfo.video)}>{t('joinCall')}</button></div>}
            <MessageList msgs={messages.msgs} me={me} chat={chat} nameOf={nameOf} typingText={typingText} hasMore={messages.hasMore} onLoadOlder={() => messages.loadOlder().catch(fail)} actions={actions} />
            {blocked ? <div className="blockedbar">{t('youBlocked')} <button className="link" onClick={() => dir.toggleBlock(chat.o._id)}>{t('unblock')}</button></div>
              : <Composer reply={reply} replyName={reply && nameOf(reply.from)} onCancelReply={() => setReply(null)} text={text} setText={setText} onTyping={typing.emitTyping} onSend={send} fileRef={fileRef} />}
          </>
        )}
        <input type="file" hidden ref={replaceRef} accept="image/*" onChange={(e) => { const f = e.target.files[0]; e.target.value = ''; if (f) messages.replacePhoto(replaceId.current, f).catch(fail); }} />
      </section>

      {modal === 'newGroup' && <NewGroupModal users={dir.users} onClose={() => setModal(null)} onCreate={createGroup} />}
      {modal === 'info' && chat?.k === 'g' && <GroupInfoModal group={chat.o} me={me} users={dir.users} isOn={dir.isOn} onClose={() => setModal(null)} onEdit={editGroup} onLeave={leaveGroup} />}
      {modal?.fwd && <ForwardModal users={dir.users} groups={dir.groups} onClose={() => setModal(null)} onForward={forward} />}
      {call.call?.state === 'ringing' && <RingingCard call={call.call} onAccept={call.accept} onDecline={call.hang} />}
      {meet && <MeetingRoom meet={meet} me={me} msgs={messages.msgs} nameOf={nameOf} typingText={typingText} text={text} setText={setText}
        onTyping={typing.emitTyping} onSend={send} onAttach={() => fileRef.current.click()} isOn={dir.isOn} />}
    </div>
  );
}
