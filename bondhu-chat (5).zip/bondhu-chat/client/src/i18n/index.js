import { D } from './translations';
export const translate = (lang, key) => D[lang][key] || D.en[key] || key;
