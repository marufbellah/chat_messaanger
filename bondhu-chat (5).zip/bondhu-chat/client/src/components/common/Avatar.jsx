import { hue } from '../../utils/format';
// Gol avatar: chhobi thakle chhobi, na hole naam er prothom okkhor + rong. `on` dile online dot.
export default function Avatar({ u, on, size = 42 }) {
  const bg = u.avatar ? `center/cover url(${u.avatar})` : `linear-gradient(135deg,hsl(${hue(u.name)} 70% 55%),hsl(${(hue(u.name) + 40) % 360} 70% 45%))`;
  return (
    <span className="av" style={{ width: size, height: size, fontSize: size * 0.4, background: bg }}>
      {!u.avatar && (u.name || '?')[0].toUpperCase()}{on !== undefined && <b className={on ? 'dot on' : 'dot'} />}
    </span>
  );
}
