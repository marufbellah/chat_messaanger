import { useEffect, useRef } from 'react';
import { useAudioLevel } from '../../hooks/useAudioLevel';
import Avatar from '../common/Avatar';

const Video = ({ stream }) => {
  const ref = useRef();
  useEffect(() => { if (ref.current && ref.current.srcObject !== stream) ref.current.srcObject = stream; ref.current?.play?.().catch(() => {}); }, [stream]);
  return <video ref={ref} autoPlay playsInline muted />;
};
// Ekjon participant er video box (thumbnail ba boro). Je kotha bolche tar border sobuj hoy.
export default function Tile({ stream, name, self, video, off, pcOf, user, big, active, onClick, you }) {
  const level = useAudioLevel(stream, pcOf), u = user || { name };
  const showVideo = video && !off && stream && stream.getVideoTracks().length > 0;
  return (
    <div className={'tile ' + (big ? 'big ' : '') + (active ? 'act ' : '') + (level > 0.12 ? 'speaking' : '')} onClick={onClick}>
      {stream && <Video stream={stream} />}
      {!showVideo && <div className="tileav"><Avatar u={u} size={big ? 110 : 44} /></div>}
      {big && <div className="tag"><Avatar u={u} size={30} /><b>{self ? you : name}</b></div>}
      <span className="nm">{self ? you : name}</span>
      <i className="lvl" style={{ '--l': level }}><b /><b /><b /></i>
    </div>
  );
}
