import { useEffect, useRef, useState } from 'react';
import { Volume2 } from 'lucide-react';
// Kothar sound ekhane chole (alada <audio>), video element gulo muted -- tai sound double ba miss hoy na.
// Browser autoplay block korle "Tap to enable sound" button dekhay.
export default function RemoteAudio({ stream, muted, label }) {
  const ref = useRef(), [blocked, setBlocked] = useState(false);
  useEffect(() => {
    const a = ref.current; if (!a || !stream) return;
    a.srcObject = stream; a.play().then(() => setBlocked(false)).catch(() => setBlocked(true));
  }, [stream]);
  return (
    <>
      <audio ref={ref} autoPlay className="raud" muted={muted} />
      {blocked && <button className="unmute" onClick={() => ref.current.play().then(() => setBlocked(false))}><Volume2 size={18} /> {label}</button>}
    </>
  );
}
