import { useState } from 'react';
import { Clock, MessageSquare, Maximize, Minimize, Mic, MicOff, Paperclip, PhoneOff, ScreenShare, Users, Video, VideoOff, Volume2, VolumeX } from 'lucide-react';
import { usePrefs } from '../../context/PrefsContext';
import { fmt, hms } from '../../utils/format';
import { useMeetingClock } from '../../hooks/useMeetingClock';
import Avatar from '../common/Avatar';
import RemoteAudio from './RemoteAudio';
import Tile from './Tile';

/**
 * Meeting screen (group ar 1:1 duitoi eta use kore).
 * `meet` = { gbox, title, video, calling, tiles[], members[], inCall[], f:{aoff,voff,net}, end(), toggle(kind), share }
 * Bam: thumbnails + main speaker + controls. Dan: Group Chat / Participant tab.
 */
export default function MeetingRoom({ meet, me, msgs, nameOf, typingText, text, setText, onTyping, onSend, onAttach, isOn }) {
  const { t } = usePrefs();
  const [spk, setSpk] = useState(false), [pin, setPin] = useState(null), [tab, setTab] = useState('chat'), [panel, setPanel] = useState(false), [full, setFull] = useState(false);
  const elapsed = useMeetingClock(true);
  const main = meet.tiles.find((x) => x.id === pin) || meet.tiles.find((x) => !x.self) || meet.tiles[0];
  const canShare = meet.video && !!navigator.mediaDevices?.getDisplayMedia;
  const toggleFullscreen = () => { full ? document.exitFullscreen?.() : document.documentElement.requestFullscreen?.(); setFull(!full); };

  return (
    <div className="overlay mwrap">
      <div className={'meet ' + (meet.gbox ? 'gbox' : 'callbox') + (panel ? ' showp' : '')}>
        {meet.tiles.filter((x) => !x.self).map((x) => <RemoteAudio key={x.id} stream={x.stream} muted={spk} label={t('soundOn')} />)}
        <div className="mmain">
          <div className="mtop">
            <div><h2>{meet.title}</h2>
              <small>{new Date().toLocaleDateString([], { month: 'long', day: '2-digit', year: 'numeric' })} <i>|</i> <Users size={13} /> {meet.tiles.length} {t('users')} <i>|</i> <Clock size={13} /> {hms(elapsed)}</small></div>
            {meet.calling && <span className="cstat ok">{t('calling')}</span>}
            {meet.f.net && !['connected', 'completed'].includes(meet.f.net) && !meet.calling && <span className="cstat">{['failed', 'disconnected'].includes(meet.f.net) ? t('connFail') : t('connecting')}</span>}
            <Avatar u={me} size={38} />
          </div>
          <div className="thumbs">{meet.tiles.map((x) => <Tile key={x.id} {...x} you={t('you')} video={meet.video} active={x.id === main.id} onClick={() => setPin(x.id)} />)}</div>
          <div className="stage"><Tile {...main} you={t('you')} video={meet.video} big /></div>
          <div className="ctrls">
            <button className={'cbtn ' + (spk ? 'off' : '')} title={t('speaker')} onClick={() => setSpk(!spk)}>{spk ? <VolumeX size={20} /> : <Volume2 size={20} />}</button>
            {meet.video && <button className={'cbtn ' + (meet.f.voff ? 'off' : '')} title={t('video')} onClick={() => meet.toggle('v')}>{meet.f.voff ? <VideoOff size={20} /> : <Video size={20} />}</button>}
            <button className={'cbtn ' + (meet.f.aoff ? 'off' : '')} title="Mic" onClick={() => meet.toggle('a')}>{meet.f.aoff ? <MicOff size={20} /> : <Mic size={20} />}</button>
            <button className="cbtn bad lg" title={t('end')} onClick={meet.end}><PhoneOff size={24} /></button>
            {canShare && <button className={'cbtn ' + (meet.share.sharing ? 'on' : '')} title={t(meet.share.sharing ? 'stopShare' : 'share')} onClick={meet.share.toggle}><ScreenShare size={20} /></button>}
            <button className="cbtn" title={t('full')} onClick={toggleFullscreen}>{full ? <Minimize size={20} /> : <Maximize size={20} />}</button>
            <button className="cbtn mob" title={t('chat')} onClick={() => setPanel(!panel)}><MessageSquare size={20} /></button>
          </div>
        </div>
        <aside className="mside">
          <div className="seg">
            <button className={tab === 'chat' ? 'on' : ''} onClick={() => setTab('chat')}>{meet.gbox ? t('gchat') : t('chat')}</button>
            <button className={tab === 'people' ? 'on' : ''} onClick={() => setTab('people')}>{t('people')}</button>
          </div>
          {tab === 'chat' ? (
            <>
              <div className="mlist">
                {msgs.map((m) => <MiniMessage key={m._id} m={m} mine={m.from === me._id} name={nameOf(m.from)} />)}
                {typingText && <div className="mm"><div className="mb typ">{typingText}</div></div>}
              </div>
              <div className="mcomp">
                <input placeholder={t('type')} value={text} onChange={(e) => { setText(e.target.value); onTyping(); }} onKeyDown={(e) => e.key === 'Enter' && onSend()} />
                <button className="ghost ic" aria-label="attach" onClick={onAttach}><Paperclip size={18} /></button>
                <button className="send" onClick={() => onSend()}>{t('send')}</button>
              </div>
            </>
          ) : (
            <div className="mlist">
              {meet.members.map((m) => (
                <div key={m._id} className="prow"><Avatar u={m} on={isOn(m._id) || m._id === me._id} size={36} />
                  <b>{m._id === me._id ? `${m.name} (${t('you')})` : m.name}</b>{meet.inCall.includes(m._id) && <span className="chip ok">{t('incall')}</span>}</div>
              ))}
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}

// Meeting er chat panel er chhoto bubble
function MiniMessage({ m, mine, name }) {
  const { t } = usePrefs();
  return (
    <div className={'mm ' + (mine ? 'me' : '')}>
      {!mine && <div className="mmh"><Avatar u={{ name }} size={22} /><b>{name}</b><small>{fmt(m.createdAt)}</small></div>}
      <div className="mb">{m.deleted ? t('deleted') : <>{m.type === 'image' && <img src={m.file} />}{m.type === 'audio' && <audio src={m.file} controls />}{m.text}</>}</div>
    </div>
  );
}
