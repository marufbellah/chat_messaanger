import { Phone, PhoneOff } from 'lucide-react';
import { usePrefs } from '../../context/PrefsContext';
import Avatar from '../common/Avatar';
// Keu call korle ei screen ashe: Accept / Decline
export default function RingingCard({ call, onAccept, onDecline }) {
  const { t } = usePrefs();
  return (
    <div className="overlay mwrap"><div className="callbox ringcard"><div className="ringing">
      <Avatar u={call.peer} size={110} /><h3>{call.peer.name}</h3><p>{t('incoming')}</p>
      <div className="row"><button className="rbtn ok" aria-label="accept" onClick={onAccept}><Phone /></button><button className="rbtn bad" aria-label="decline" onClick={onDecline}><PhoneOff /></button></div>
    </div></div></div>
  );
}
