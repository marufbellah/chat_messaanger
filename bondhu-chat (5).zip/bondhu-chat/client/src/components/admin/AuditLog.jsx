import { useEffect, useState } from 'react';
import { api } from '../../services/api';
import { usePrefs } from '../../context/PrefsContext';
// Admin ke ki korechhe tar record
export default function AuditLog() {
  const { t } = usePrefs(), [logs, setLogs] = useState([]);
  useEffect(() => { api('/admin/logs').then(setLogs); }, []);
  return (
    <div className="admin"><div className="tablewrap"><table>
      <thead><tr><th>{t('time')}</th><th>{t('admin')}</th><th>{t('action')}</th><th>{t('target')}</th></tr></thead>
      <tbody>
        {logs.map((x) => <tr key={x._id}><td data-l={t('time')}>{new Date(x.createdAt).toLocaleString()}</td><td data-l={t('admin')}>{x.admin?.name}</td><td data-l={t('action')}><span className="chip">{x.action}</span></td><td data-l={t('target')}>{x.target}</td></tr>)}
        {!logs.length && <tr><td colSpan="4">—</td></tr>}
      </tbody>
    </table></div></div>
  );
}
