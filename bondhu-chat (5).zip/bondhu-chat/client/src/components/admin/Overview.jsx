import { useEffect, useState } from 'react';
import { api } from '../../services/api';
import { usePrefs } from '../../context/PrefsContext';
// Admin dashboard: kotojon user, online, message, group, call
export default function Overview() {
  const { t } = usePrefs(), [s, setS] = useState(null);
  useEffect(() => { api('/admin/stats').then(setS); }, []);
  if (!s) return null;
  const cards = [[t('users'), s.users.total], [t('active'), s.users.active], [t('inactive'), s.users.inactive], ['Admins', s.users.admins], [t('onlineNow'), s.online], [t('messages'), s.messages.total], [t('today'), s.messages.today], [t('groups'), s.groups], [t('calls'), s.calls]];
  return <div className="admin"><div className="stats">{cards.map(([l, v]) => <div key={l} className="stat"><b>{v}</b><span>{l}</span></div>)}</div></div>;
}
