import { useState } from 'react';
import { BarChart3, ScrollText, Users } from 'lucide-react';
import { usePrefs } from '../../context/PrefsContext';
import UsersTable from './UsersTable';
import Overview from './Overview';
import AuditLog from './AuditLog';

export default function AdminPage() {
  const { t } = usePrefs(), [view, setView] = useState('users');
  const tabs = [['users', Users, t('users')], ['stats', BarChart3, t('overview')], ['audit', ScrollText, t('audit')]];
  return (
    <div className="adm">
      <div className="subtabs">{tabs.map(([k, Icon, label]) => <button key={k} className={view === k ? 'on' : ''} onClick={() => setView(k)}><Icon size={16} /> {label}</button>)}</div>
      {view === 'users' ? <UsersTable /> : view === 'stats' ? <Overview /> : <AuditLog />}
    </div>
  );
}
