import { useEffect, useState } from 'react';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { usePrefs } from '../../context/PrefsContext';

const BLANK = { name: '', email: '', password: '', role: 'user', active: true };

// Admin: user CRUD + active/inactive switch + search
export default function UsersTable() {
  const { t } = usePrefs(), { me } = useAuth();
  const [list, setList] = useState([]), [q, setQ] = useState(''), [form, setForm] = useState(null), [err, setErr] = useState('');
  const load = () => api('/admin/users').then(setList);
  useEffect(() => { load(); }, []);

  const save = async (e) => {
    e.preventDefault(); setErr('');
    try { await api(form._id ? '/admin/users/' + form._id : '/admin/users', { method: form._id ? 'PUT' : 'POST', body: form }); setForm(null); load(); } catch (x) { setErr(x.message); }
  };
  const toggle = (u) => api('/admin/users/' + u._id, { method: 'PUT', body: { active: !u.active } }).then(load);
  const remove = async (u) => { if (!confirm(t('confirm'))) return; try { await api('/admin/users/' + u._id, { method: 'DELETE' }); load(); } catch (x) { alert(x.message); } };
  const rows = list.filter((u) => (u.name + u.email).toLowerCase().includes(q.toLowerCase()));
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <div className="admin">
      <div className="bar"><h2>{t('users')} <small>{t('total')}: {list.length}</small></h2>
        <input placeholder={t('search')} value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn" onClick={() => setForm(BLANK)}><Plus size={16} /> {t('add')}</button></div>
      <div className="tablewrap"><table>
        <thead><tr><th>{t('name')}</th><th>{t('email')}</th><th>{t('role')}</th><th>{t('status')}</th><th>{t('actions')}</th></tr></thead>
        <tbody>
          {rows.map((u) => (
            <tr key={u._id}>
              <td data-l={t('name')}>{u.name}</td><td data-l={t('email')}>{u.email}</td><td data-l={t('role')}><span className="chip">{u.role}</span></td>
              <td data-l={t('status')}><label className="switch"><input type="checkbox" checked={u.active} disabled={u._id === me._id} onChange={() => toggle(u)} /><i /></label> {u.active ? t('active') : t('inactive')}</td>
              <td data-l={t('actions')} className="acts">
                <button className="ghost" onClick={() => setForm({ ...u, password: '' })}><Pencil size={15} /> {t('edit')}</button>
                <button className="ghost danger" disabled={u._id === me._id} onClick={() => remove(u)}><Trash2 size={15} /> {t('del')}</button>
              </td>
            </tr>
          ))}
          {!rows.length && <tr><td colSpan="5">{t('noUsers')}</td></tr>}
        </tbody>
      </table></div>
      {form && (
        <div className="overlay" onClick={() => setForm(null)}>
          <form className="modal" onClick={(e) => e.stopPropagation()} onSubmit={save}>
            <h3>{form._id ? t('edit') : t('add')}</h3>
            <input required placeholder={t('name')} value={form.name} onChange={set('name')} />
            <input required type="email" placeholder={t('email')} value={form.email} onChange={set('email')} />
            <input type="password" minLength={form.password ? 6 : 0} required={!form._id} placeholder={form._id ? t('passHint') : t('password')} value={form.password} onChange={set('password')} />
            <select value={form.role} onChange={set('role')}><option value="user">user</option><option value="admin">admin</option></select>
            <label className="row"><input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> {t('active')}</label>
            {err && <p className="err">{err}</p>}
            <div className="row end"><button type="button" className="ghost" onClick={() => setForm(null)}>{t('cancel')}</button><button className="btn">{t('save')}</button></div>
          </form>
        </div>
      )}
    </div>
  );
}
