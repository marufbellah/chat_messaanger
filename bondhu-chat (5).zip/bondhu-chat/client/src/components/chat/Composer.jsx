import { useState } from 'react';
import EmojiPicker from 'emoji-picker-react';
import { CornerUpLeft, ImagePlus, Mic, Send, Smile, Trash2, X } from 'lucide-react';
import { usePrefs } from '../../context/PrefsContext';
import { preview } from '../../utils/format';
import { useRecorder } from '../../hooks/useRecorder';

// Message likhar jaiga: emoji, photo, voice note, reply bar
export default function Composer({ reply, replyName, onCancelReply, text, setText, onTyping, onSend, fileRef }) {
  const { t, theme } = usePrefs(), [emoji, setEmoji] = useState(false);
  const send = (file) => { setEmoji(false); onSend(file); };
  const rec = useRecorder(send, () => alert(t('camErr')));
  return (
    <>
      {emoji && <div className="emoji"><EmojiPicker emojiStyle="native" theme={theme} width="100%" height={320} onEmojiClick={(e) => setText((x) => x + e.emoji)} /></div>}
      {reply && (
        <div className="replybar"><CornerUpLeft size={16} /><div><b>{replyName}</b><span>{preview(reply, t)}</span></div><button className="ghost" onClick={onCancelReply}><X size={16} /></button></div>
      )}
      <footer className="compose">
        {rec.recording ? (
          <>
            <button className="ghost ic" aria-label="cancel" onClick={() => rec.stop(false)}><Trash2 size={20} /></button>
            <span className="rec"><i />{Math.floor(rec.sec / 60)}:{String(rec.sec % 60).padStart(2, '0')} · {t('recording')}</span>
            <button className="send" aria-label="send voice" onClick={() => rec.stop(true)}><Send size={18} /></button>
          </>
        ) : (
          <>
            <button className="ghost ic" aria-label="emoji" onClick={() => setEmoji(!emoji)}><Smile size={22} /></button>
            <button className="ghost ic" aria-label="photo" onClick={() => fileRef.current.click()}><ImagePlus size={22} /></button>
            <input type="file" hidden ref={fileRef} accept="image/*,video/*,audio/*,.pdf,.zip,.doc,.docx" onChange={(e) => { send(e.target.files[0]); e.target.value = ''; }} />
            <input className="mi" value={text} placeholder={t('type')} onChange={(e) => { setText(e.target.value); onTyping(); }} onKeyDown={(e) => e.key === 'Enter' && send()} />
            <button className="ghost ic" aria-label="voice" title={t('record')} onClick={rec.start}><Mic size={22} /></button>
            <button className="send" aria-label="send" onClick={() => send()}><span className="st">{t('send')}</span><Send size={17} /></button>
          </>
        )}
      </footer>
    </>
  );
}
