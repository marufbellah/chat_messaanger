import { Search, Plus, Users, MessageCircle } from 'lucide-react';
import { usePrefs } from '../../context/PrefsContext';
import { chatKey, fmt, preview } from '../../utils/format';
import Avatar from '../common/Avatar';

// Bam pashe: Chats/Groups tab, search, conversation list
export default function Sidebar({ tab, setTab, q, setQ, items, chat, onPick, last, unread, typers, isOn, onNewGroup }) {
  const { t } = usePrefs();
  return (
    <aside className="list">
      <div className="tabs">
        <button className={tab === 'u' ? 'on' : ''} onClick={() => setTab('u')}><MessageCircle size={16} /> {t('chat')}</button>
        <button className={tab === 'g' ? 'on' : ''} onClick={() => setTab('g')}><Users size={16} /> {t('groups')}</button>
      </div>
      <div className="sbox"><Search size={16} /><input placeholder={t('search')} value={q} onChange={(e) => setQ(e.target.value)} />
        {tab === 'g' && <button className="ghost ic" title={t('newGroup')} onClick={onNewGroup}><Plus size={18} /></button>}</div>
      <div className="items">
        {items.map((x) => {
          const k = tab + ':' + x._id, l = last[k], on = tab === 'u' && isOn(x._id), typing = Object.keys(typers[k] || {}).length;
          return (
            <button key={x._id} className={'item ' + (chatKey(chat) === k ? 'sel' : '')} onClick={() => onPick({ k: tab, o: x })}>
              {tab === 'u' ? <Avatar u={x} on={on} /> : <span className="av gav"><Users size={20} /></span>}
              <span className="meta"><b>{x.name}</b>
                <small className={typing ? 'tp' : ''}>{typing ? t('isTyping') : preview(l, t) || (tab === 'u' ? t(on ? 'online' : 'offline') : x.members.length + ' ' + t('members'))}</small></span>
              <span className="rt">{l && <small>{fmt(l.createdAt)}</small>}{unread[k] > 0 && <em className="badge">{unread[k]}</em>}</span>
            </button>
          );
        })}
        {!items.length && <p className="muted pad center">{tab === 'g' ? t('noGroups') : t('noUsers')}</p>}
      </div>
    </aside>
  );
}
