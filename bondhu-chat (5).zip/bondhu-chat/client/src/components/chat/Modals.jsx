import { LogOut, Trash2, UserPlus, Users, X } from 'lucide-react';
import { useState } from 'react';
import { usePrefs } from '../../context/PrefsContext';
import Avatar from '../common/Avatar';

const Shell = ({ onClose, children }) => <div className="overlay" onClick={onClose}><div className="modal" onClick={(e) => e.stopPropagation()}>{children}</div></div>;

export function NewGroupModal({ users, onClose, onCreate }) {
  const { t } = usePrefs(), [name, setName] = useState(''), [members, setMembers] = useState([]);
  const toggle = (id, on) => setMembers((m) => (on ? [...m, id] : m.filter((x) => x !== id)));
  return (
    <Shell onClose={onClose}>
      <h3>{t('newGroup')}</h3>
      <input autoFocus placeholder={t('groupName')} value={name} onChange={(e) => setName(e.target.value)} />
      <div className="pick">{users.map((u) => <label key={u._id} className="row"><input type="checkbox" checked={members.includes(u._id)} onChange={(e) => toggle(u._id, e.target.checked)} /><Avatar u={u} size={28} /> {u.name}</label>)}</div>
      <div className="row end"><button className="ghost" onClick={onClose}>{t('cancel')}</button><button className="btn" onClick={() => name.trim() && onCreate(name, members)}>{t('create')}</button></div>
    </Shell>
  );
}

export function GroupInfoModal({ group: g, me, users, isOn, onClose, onEdit, onLeave }) {
  const { t } = usePrefs(), own = g.owner === me._id, candidates = users.filter((u) => !g.members.some((m) => m._id === u._id));
  return (
    <Shell onClose={onClose}>
      <input defaultValue={g.name} disabled={!own} onBlur={(e) => e.target.value.trim() && e.target.value !== g.name && onEdit({ name: e.target.value })} />
      <div className="pick">
        {g.members.map((m) => (
          <div key={m._id} className="row"><Avatar u={m} on={isOn(m._id) || m._id === me._id} size={32} /> {m.name}
            {m._id === g.owner ? <span className="chip">owner</span> : own && <button className="ghost ic chip" title={t('remove')} onClick={() => onEdit({ remove: [m._id] })}><X size={14} /></button>}</div>
        ))}
      </div>
      {own && candidates.length > 0 && (
        <>
          <b>{t('addMembers')}</b>
          <div className="pick">{candidates.map((u) => <div key={u._id} className="row"><Avatar u={u} size={28} /> {u.name}<button className="ghost ic chip" title={t('addMembers')} onClick={() => onEdit({ add: [u._id] })}><UserPlus size={14} /></button></div>)}</div>
        </>
      )}
      <button className="btn bad" onClick={onLeave}>{own ? <><Trash2 size={16} /> {t('delGroup')}</> : <><LogOut size={16} /> {t('leave')}</>}</button>
    </Shell>
  );
}

export function ForwardModal({ users, groups, onClose, onForward }) {
  const { t } = usePrefs(), [sel, setSel] = useState({ users: [], groups: [] });
  const toggle = (kind, id, on) => setSel((s) => ({ ...s, [kind]: on ? [...s[kind], id] : s[kind].filter((x) => x !== id) }));
  const rows = [...users.map((x) => ({ ...x, kind: 'users' })), ...groups.map((x) => ({ ...x, kind: 'groups' }))];
  return (
    <Shell onClose={onClose}>
      <h3>{t('forwardTo')}</h3>
      <div className="pick">{rows.map((x) => (
        <label key={x.kind + x._id} className="row"><input type="checkbox" checked={sel[x.kind].includes(x._id)} onChange={(e) => toggle(x.kind, x._id, e.target.checked)} />
          {x.kind === 'groups' ? <Users size={18} /> : <Avatar u={x} size={28} />} {x.name}</label>
      ))}</div>
      <div className="row end"><button className="ghost" onClick={onClose}>{t('cancel')}</button>
        <button className="btn" disabled={!sel.users.length && !sel.groups.length} onClick={() => onForward(sel.users, sel.groups)}>{t('forward')}</button></div>
    </Shell>
  );
}
