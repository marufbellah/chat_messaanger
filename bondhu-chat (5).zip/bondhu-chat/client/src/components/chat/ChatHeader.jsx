import { ArrowLeft, Phone, Video, Info, Ban, Users } from 'lucide-react';
import { usePrefs } from '../../context/PrefsContext';
import Avatar from '../common/Avatar';

export default function ChatHeader({ chat, me, isOn, typingText, blocked, groupCallActive, onBack, onCall, onInfo, onToggleBlock }) {
  const { t } = usePrefs(), dm = chat.k === 'u', o = chat.o;
  const sub = typingText || (dm ? t(isOn(o._id) ? 'online' : 'offline') : `${o.members.length} ${t('members')} · ${o.members.filter((m) => isOn(m._id) || m._id === me._id).length} ${t('online')}`);
  const canCall = dm ? isOn(o._id) && !blocked : !groupCallActive;
  return (
    <header className="rhead">
      <button className="ghost back" onClick={onBack}><ArrowLeft size={20} /></button>
      {dm ? <Avatar u={o} on={isOn(o._id)} /> : <span className="av gav"><Users size={20} /></span>}
      <span className="meta"><b>{o.name}</b><small className={typingText ? 'tp' : ''}>{sub}</small></span>
      <button className="ghost ic" title={t('audio')} disabled={!canCall} onClick={() => onCall(false)}><Phone size={20} /></button>
      <button className="ghost ic" title={t('video')} disabled={!canCall} onClick={() => onCall(true)}><Video size={20} /></button>
      {dm ? <button className="ghost ic" title={blocked ? t('unblock') : t('block')} onClick={onToggleBlock}><Ban size={20} /></button>
        : <button className="ghost ic" title="Info" onClick={onInfo}><Info size={20} /></button>}
    </header>
  );
}
