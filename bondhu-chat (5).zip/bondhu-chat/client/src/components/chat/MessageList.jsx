import { useEffect, useRef, useState } from 'react';
import { usePrefs } from '../../context/PrefsContext';
import MessageBubble from './MessageBubble';

// Message gulor scroll-korar-moto list. ⋮ menu ar edit state ekhane.
export default function MessageList({ msgs, me, chat, nameOf, typingText, hasMore, onLoadOlder, actions }) {
  const { t } = usePrefs(), [menu, setMenu] = useState(null), [edit, setEdit] = useState(null), end = useRef();
  const lastId = msgs[msgs.length - 1]?._id;
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [lastId, typingText]); // purono load korle neeche jay na
  useEffect(() => { setMenu(null); setEdit(null); }, [chat.o._id]);

  const saveEdit = async () => { try { await actions.edit(edit.id, edit.text); setEdit(null); } catch (e) { alert(e.message); } };
  const a = {
    ...actions, meId: me._id, nameOf: (id) => nameOf(id), toggleMenu: (id) => setMenu((x) => (x === id ? null : id)), closeMenu: () => setMenu(null),
    startEdit: (m) => setEdit({ id: m._id, text: m.text || '' }), onEditText: (text) => setEdit((e) => ({ ...e, text })), saveEdit, cancelEdit: () => setEdit(null),
  };
  return (
    <div className="msgs" onClick={() => setMenu(null)}>
      {hasMore && <button className="link older" onClick={onLoadOlder}>{t('older')}</button>}
      {!msgs.length && <p className="muted center">{t('empty')}</p>}
      {msgs.map((m) => (
        <MessageBubble key={m._id} m={m} mine={m.from === me._id} group={chat.k === 'g'} name={nameOf(m.from)} replyTo={m.replyTo && msgs.find((x) => x._id === m.replyTo)}
          editing={edit?.id === m._id ? edit : null} menuOpen={menu === m._id} actions={a} />
      ))}
      {typingText && <div className="rm"><div className="bub typing"><i /><i /><i /></div></div>}
      <div ref={end} />
    </div>
  );
}
