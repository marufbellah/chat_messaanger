import { Ban, Check, CheckCheck, CornerUpLeft, CornerUpRight, ImagePlus, MoreVertical, Pencil, Trash2, X } from 'lucide-react';
import { usePrefs } from '../../context/PrefsContext';
import { fmt, hue, preview } from '../../utils/format';
import Avatar from '../common/Avatar';

const QUICK = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

// Ekta message bubble: text/photo/audio/video/file, reply quote, reaction, tick, ⋮ menu
export default function MessageBubble({ m, mine, group, name, replyTo, editing, menuOpen, actions: a }) {
  const { t } = usePrefs();
  const reactions = Object.entries((m.reactions || []).reduce((acc, r) => ({ ...acc, [r.emoji]: [...(acc[r.emoji] || []), r.user] }), {}));
  return (
    <div className={'rm ' + (mine ? 'me' : '')}>
      {!mine && group && <Avatar u={{ name }} size={28} />}
      <div className={'bub ' + (m.deleted ? 'del' : '')}>
        {!mine && group && <b className="sname" style={{ color: `hsl(${hue(name)} 60% 50%)` }}>{name}</b>}
        {m.replyTo && !m.deleted && <div className="quote"><b>{replyTo ? a.nameOf(replyTo.from) : '…'}</b><span>{replyTo ? preview(replyTo, t) : '…'}</span></div>}
        {m.deleted ? <p><Ban size={14} /> {t('deleted')}</p> : (
          <>
            {m.type === 'image' && <img src={m.file} onClick={() => window.open(m.file)} />}
            {m.type === 'video' && <video src={m.file} controls />}
            {m.type === 'audio' && <audio src={m.file} controls />}
            {m.type === 'file' && <a href={m.file} target="_blank" rel="noreferrer">📎 {m.file.split('/').pop()}</a>}
            {editing ? (
              <div className="editbox">
                <input autoFocus value={editing.text} onChange={(e) => a.onEditText(e.target.value)} onKeyDown={(e) => (e.key === 'Enter' ? a.saveEdit() : e.key === 'Escape' && a.cancelEdit())} />
                <button onClick={a.saveEdit}><Check size={16} /></button><button onClick={a.cancelEdit}><X size={16} /></button>
              </div>
            ) : m.text && <p>{m.text}</p>}
          </>
        )}
        {reactions.length > 0 && !m.deleted && (
          <div className="rxs">{reactions.map(([e, users]) => <button key={e} className={'rx ' + (users.includes(a.meId) ? 'mine' : '')} onClick={() => a.react(m, e)}>{e} {users.length}</button>)}</div>
        )}
        <small>
          {m.edited && !m.deleted && t('edited') + ' · '}{fmt(m.createdAt)}
          {mine && !group && !m.deleted && (m.readAt ? <CheckCheck size={14} className="rd" /> : m.deliveredAt ? <CheckCheck size={14} /> : <Check size={14} />)}
        </small>
        {!m.deleted && !editing && <button className="more" aria-label="menu" onClick={(e) => { e.stopPropagation(); a.toggleMenu(m._id); }}><MoreVertical size={16} /></button>}
        {menuOpen && (
          <div className={'menu ' + (mine ? '' : 'l')}>
            <div className="rxbar">{QUICK.map((e) => <button key={e} onClick={() => { a.react(m, e); a.closeMenu(); }}>{e}</button>)}</div>
            <button onClick={() => { a.reply(m); a.closeMenu(); }}><CornerUpLeft size={15} /> {t('reply')}</button>
            <button onClick={() => { a.forward(m); a.closeMenu(); }}><CornerUpRight size={15} /> {t('forward')}</button>
            {mine && (
              <>
                <button onClick={() => { a.startEdit(m); a.closeMenu(); }}><Pencil size={15} /> {t('editMsg')}</button>
                {m.type === 'image' && <button onClick={() => { a.replacePhoto(m._id); a.closeMenu(); }}><ImagePlus size={15} /> {t('replacePhoto')}</button>}
                {m.type === 'image' && m.text && <button onClick={() => { a.removePhoto(m._id); a.closeMenu(); }}><X size={15} /> {t('removePhoto')}</button>}
                <button className="danger" onClick={() => { a.remove(m); a.closeMenu(); }}><Trash2 size={15} /> {t('delMsg')}</button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
