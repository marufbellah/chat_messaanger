import { useState } from 'react';
import { api } from '../../services/api';
import { usePrefs } from '../../context/PrefsContext';
// Email verify na kora user ke mone koriye dey
export default function VerifyBanner() {
  const { t } = usePrefs(), [sent, setSent] = useState(false);
  return <div className="vbar"><span>{t('verifyBanner')}</span><button className="link" disabled={sent} onClick={async () => { await api('/auth/verify/resend', { method: 'POST' }).catch(() => {}); setSent(true); }}>{sent ? t('sentOk') : t('resend')}</button></div>;
}
