import { useState } from 'react';
import { X } from 'lucide-react';
import { api } from '../../services/api';
import { session } from '../../services/session';
import { useAuth } from '../../context/AuthContext';
import { usePrefs } from '../../context/PrefsContext';
import Avatar from '../common/Avatar';

export default function ProfileModal({ onClose }) {
  const { me, setMe } = useAuth(), { t } = usePrefs();
  const [name, setName] = useState(me.name), [cur, setCur] = useState(''), [pw, setPw] = useState(''), [msg, setMsg] = useState('');
  const run = async (fn) => { try { await fn(); setMsg('✓'); } catch (e) { setMsg(e.message); } };
  const uploadAvatar = (e) => run(async () => { const f = new FormData(); f.append('file', e.target.files[0]); setMe(await api('/me/avatar', { method: 'POST', form: f })); });
  const changePassword = () => run(async () => { // server notun session dey (puron refresh token batil hoy)
    const d = await api('/me/password', { method: 'PUT', body: { current: cur, password: pw } }); session.set(d); setCur(''); setPw('');
  });
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="rowb"><h3>{t('profile')}</h3><button className="ghost" onClick={onClose}><X size={18} /></button></div>
        <div className="row"><Avatar u={me} size={64} /><label className="btn sm">{t('avatar')}<input type="file" hidden accept="image/*" onChange={uploadAvatar} /></label></div>
        <input value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn" onClick={() => run(async () => setMe(await api('/me', { method: 'PUT', body: { name } })))}>{t('save')}</button>
        <hr />
        <input type="password" placeholder={t('curPass')} value={cur} onChange={(e) => setCur(e.target.value)} />
        <input type="password" placeholder={t('newPass')} value={pw} onChange={(e) => setPw(e.target.value)} />
        <button className="btn" onClick={changePassword}>{t('changePass')}</button>
        {msg && <p className="muted">{msg}</p>}
      </div>
    </div>
  );
}
