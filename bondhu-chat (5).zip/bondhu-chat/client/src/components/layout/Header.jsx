import { useState } from 'react';
import { MessageCircle, Shield, Moon, Sun, Languages, LogOut, Volume2, VolumeX } from 'lucide-react';
import { usePrefs } from '../../context/PrefsContext';
import { useAuth } from '../../context/AuthContext';
import Avatar from '../common/Avatar';
import ProfileModal from './ProfileModal';

export function Brand({ size = 20 }) {
  const { t } = usePrefs();
  return <div className="brand"><span className="logo"><MessageCircle size={size} /></span><h1>{t('app')}</h1></div>;
}
// sound / bhasha / theme button (login page e o lage)
export function Tools() {
  const { t, theme, lang, muted, toggleMute, toggleLang, toggleTheme } = usePrefs();
  return (
    <div className="tools">
      <button className="ghost ic" title={t('sound')} onClick={toggleMute}>{muted ? <VolumeX size={19} /> : <Volume2 size={19} />}</button>
      <button className="ghost ic" title="Language" onClick={toggleLang}><Languages size={19} /><span className="hlab">{lang === 'en' ? 'বাং' : 'EN'}</span></button>
      <button className="ghost ic" title="Theme" onClick={toggleTheme}>{theme === 'dark' ? <Sun size={19} /> : <Moon size={19} />}</button>
    </div>
  );
}
export default function Header({ tab, setTab }) {
  const { t } = usePrefs(), { me, logout } = useAuth(), [profile, setProfile] = useState(false);
  return (
    <header className="top">
      <Brand />
      <nav>
        <button className={tab === 'chat' ? 'tab on' : 'tab'} onClick={() => setTab('chat')}><MessageCircle size={16} /><span>{t('chat')}</span></button>
        {me.role === 'admin' && <button className={tab === 'admin' ? 'tab on' : 'tab'} onClick={() => setTab('admin')}><Shield size={16} /><span>{t('admin')}</span></button>}
      </nav>
      <Tools />
      <button className="ghost ic" title={t('profile')} onClick={() => setProfile(true)}><Avatar u={me} size={30} /></button>
      <button className="ghost ic" title={t('logout')} onClick={logout}><LogOut size={19} /><span className="hlab">{t('logout')}</span></button>
      {profile && <ProfileModal onClose={() => setProfile(false)} />}
    </header>
  );
}
