import { useState } from 'react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { usePrefs } from '../../context/PrefsContext';
import { Brand, Tools } from '../layout/Header';

// Login / Register / Forgot password / Reset password (email er link theke ?reset=TOKEN)
export default function AuthPage({ resetToken, onResetDone, notice }) {
  const { start } = useAuth(), { t } = usePrefs();
  const [mode, setMode] = useState(resetToken ? 'reset' : 'login'), [f, setF] = useState({ name: '', email: '', password: '' }), [err, setErr] = useState(''), [info, setInfo] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const go = (m) => { setMode(m); setErr(''); setInfo(''); };

  const submit = async (e) => {
    e.preventDefault(); setErr(''); setInfo('');
    try {
      if (mode === 'forgot') { await api('/auth/forgot', { method: 'POST', body: { email: f.email }, auth: false }); setInfo(t('linkSent')); return; }
      if (mode === 'reset') { start(await api('/auth/reset', { method: 'POST', body: { token: resetToken, password: f.password }, auth: false })); history.replaceState({}, '', location.pathname); onResetDone?.(); return; }
      start(await api('/auth/' + mode, { method: 'POST', body: f, auth: false }));
    } catch (x) { setErr(x.message); }
  };
  const submitLabel = { forgot: 'sendLink', reset: 'setPass', login: 'login', register: 'register' }[mode];
  return (
    <div className="auth">
      <form className="card" onSubmit={submit}>
        <div className="rowb"><Brand size={22} /><Tools /></div>
        {notice && <p className="notice">{notice}</p>}
        {mode === 'reset' && <h3>{t('resetTitle')}</h3>}
        {mode === 'register' && <input required placeholder={t('name')} value={f.name} onChange={set('name')} />}
        {mode !== 'reset' && <input required type="email" placeholder={t('email')} value={f.email} onChange={set('email')} />}
        {mode !== 'forgot' && <input required type="password" minLength={6} placeholder={t(mode === 'reset' ? 'newPass' : 'password')} value={f.password} onChange={set('password')} />}
        {err && <p className="err">{err}</p>}{info && <p className="info">{info}</p>}
        <button className="btn lg">{t(submitLabel)}</button>
        {mode === 'login' && <button type="button" className="link" onClick={() => go('forgot')}>{t('forgot')}</button>}
        {mode !== 'reset' && <button type="button" className="link" onClick={() => go(mode === 'login' ? 'register' : 'login')}>{t(mode === 'login' ? 'noAcc' : mode === 'forgot' ? 'backLogin' : 'haveAcc')}</button>}
      </form>
    </div>
  );
}
