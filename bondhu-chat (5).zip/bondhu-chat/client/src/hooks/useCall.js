import { useEffect, useRef, useState } from 'react';
import { sfx, ringLoop } from '../utils/sounds';
import { rtc, mediaConstraints, toggleTrack, exposeForTests } from '../utils/webrtc';
import { useSocketEvent } from './useSocket';
import { useLatest } from './useLatest';
import { useScreenShare } from './useScreenShare';

// 1:1 audio/video call. state: null -> 'calling' (ami dichhi) | 'ringing' (amake dichhe) -> 'active'
export function useCall(socket, me, { users, onAccept, onError }) {
  const [call, setCall] = useState(null), [rs, setRs] = useState(null), [ls, setLs] = useState(null);
  const pc = useRef(null), local = useRef(null), queue = useRef([]), callRef = useLatest(call), usersRef = useLatest(users);
  const share = useScreenShare({ getPcs: () => (pc.current ? [pc.current] : []), getStream: () => local.current, setPreview: setLs });

  const cleanup = () => {
    if (pc.current || local.current) sfx.end();
    pc.current?.close(); pc.current = null; local.current?.getTracks().forEach((x) => x.stop()); local.current = null;
    queue.current = []; share.reset(); setRs(null); setLs(null); setCall(null);
  };
  const setup = async (peer, video) => {
    const stream = await navigator.mediaDevices.getUserMedia(mediaConstraints(video)); local.current = stream; setLs(stream);
    const p = new RTCPeerConnection(rtc.ice); pc.current = p; stream.getTracks().forEach((x) => p.addTrack(x, stream));
    p.onicecandidate = (e) => e.candidate && socket.emit('call:ice', { to: peer._id, c: e.candidate });
    p.ontrack = (e) => setRs(e.streams[0] || new MediaStream([e.track]));
    p.oniceconnectionstatechange = () => setCall((c) => c && { ...c, net: p.iceConnectionState });
    exposeForTests('__pc', p); return p;
  };
  const flushIce = async () => { for (const c of queue.current) await pc.current.addIceCandidate(c); queue.current = []; };

  const start = async (peer, video) => {
    setCall({ peer, video, state: 'calling' });
    try {
      await new Promise((r) => setTimeout(r)); // UI render hoye nik
      const p = await setup(peer, video), offer = await p.createOffer(); await p.setLocalDescription(offer);
      socket.emit('call:offer', { to: peer._id, offer, video });
    } catch { onError?.(); cleanup(); }
  };
  const hang = () => { const c = callRef.current; if (c) socket.emit('call:end', { to: c.peer._id }); cleanup(); };
  const accept = async () => {
    const c = callRef.current; onAccept?.(c.peer); setCall({ ...c, state: 'active' });
    try {
      await new Promise((r) => setTimeout(r));
      const p = await setup(c.peer, c.video); await p.setRemoteDescription(c.offer); await flushIce();
      const answer = await p.createAnswer(); await p.setLocalDescription(answer); socket.emit('call:answer', { to: c.peer._id, answer });
    } catch { onError?.(); hang(); }
  };
  const toggle = (kind) => { toggleTrack(local.current, kind); setCall((c) => ({ ...c, [kind + 'off']: !c[kind + 'off'] })); };

  useSocketEvent(socket, 'call:offer', (d) => { const peer = usersRef.current.find((u) => u._id === d.from); if (peer && !callRef.current) setCall({ peer, video: d.video, state: 'ringing', offer: d.offer }); });
  useSocketEvent(socket, 'call:answer', async (d) => { await pc.current?.setRemoteDescription(d.answer); await flushIce(); setCall((c) => c && { ...c, state: 'active' }); });
  useSocketEvent(socket, 'call:ice', (d) => { if (pc.current?.remoteDescription) pc.current.addIceCandidate(d.c); else queue.current.push(d.c); }); // answer er age ashle jomiye rakhi
  useSocketEvent(socket, 'call:end', cleanup);
  useEffect(() => { if (call?.state === 'ringing' || call?.state === 'calling') return ringLoop(); return undefined; }, [call?.state]);
  useEffect(() => cleanup, []); // eslint-disable-line react-hooks/exhaustive-deps

  return { call, rs, ls, getPc: () => pc.current, start, accept, hang, toggle, share, me };
}
