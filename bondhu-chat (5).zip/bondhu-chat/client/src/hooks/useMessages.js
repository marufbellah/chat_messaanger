import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { chatKey, msgKey } from '../utils/format';
import { useSocketEvent } from './useSocket';
import { useLatest } from './useLatest';

const pathOf = (c) => (c.k === 'g' ? `/groups/${c.o._id}/messages` : '/messages/' + c.o._id);
const PAGE = 50;

// Ekta open chat er message list + shob message action (send, edit, delete, react, forward)
export function useMessages(socket, me, chat) {
  const [msgs, setMsgs] = useState([]), [hasMore, setHasMore] = useState(false), chatRef = useLatest(chat);
  const load = () => api(pathOf(chat)).then((d) => { setMsgs(d); setHasMore(d.length >= PAGE); });
  useEffect(() => {
    setMsgs([]); setHasMore(false); if (!chat) return;
    load(); if (chat.k === 'u') api('/messages/read/' + chat.o._id, { method: 'POST' });
  }, [chat?.k, chat?.o._id]); // eslint-disable-line react-hooks/exhaustive-deps

  const upd = (m) => setMsgs((x) => x.map((y) => (y._id === m._id ? m : y)));
  useSocketEvent(socket, 'msg', (m) => {
    if (chatKey(chatRef.current) !== msgKey(m)) return;
    setMsgs((x) => [...x, m]); if (!m.group) api('/messages/read/' + m.from, { method: 'POST' });
  });
  useSocketEvent(socket, 'msg:edit', upd);
  useSocketEvent(socket, 'msg:delete', (d) => setMsgs((x) => x.map((y) => (y._id === d._id ? { ...y, deleted: true, text: '', file: undefined } : y))));
  useSocketEvent(socket, 'read', (d) => chatKey(chatRef.current) === 'u:' + d.by && setMsgs((x) => x.map((y) => (y.from === me._id && !y.readAt ? { ...y, readAt: d.at } : y))));

  const form = (o) => { const f = new FormData(); Object.entries(o).forEach(([k, v]) => v && f.append(k, v)); return f; };
  return {
    msgs, hasMore, reload: load,
    async send({ text, file, replyTo }) {
      const m = await api(chat.k === 'g' ? pathOf(chat) : '/messages', { method: 'POST', form: form({ text, file, replyTo, to: chat.k === 'u' ? chat.o._id : '' }) });
      setMsgs((x) => [...x, m]); return m;
    },
    edit: async (id, text) => upd(await api('/messages/' + id, { method: 'PUT', body: { text } })),
    replacePhoto: async (id, file) => upd(await api('/messages/' + id, { method: 'PUT', form: form({ file }) })),
    removePhoto: async (id) => upd(await api('/messages/' + id, { method: 'PUT', body: { removeFile: true } })),
    remove: async (m) => { await api('/messages/' + m._id, { method: 'DELETE' }); upd({ ...m, deleted: true, text: '', file: undefined }); },
    react: async (m, emoji) => upd(await api(`/messages/${m._id}/react`, { method: 'POST', body: { emoji } })),
    forward: (m, users, groups) => api(`/messages/${m._id}/forward`, { method: 'POST', body: { users, groups } }),
    async loadOlder() { // purono message (pagination)
      const d = await api(pathOf(chat) + '?before=' + encodeURIComponent(msgs[0].createdAt));
      setMsgs((x) => [...d, ...x]); setHasMore(d.length >= PAGE);
    },
  };
}
