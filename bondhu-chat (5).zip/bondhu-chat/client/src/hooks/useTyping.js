import { useRef, useState } from 'react';
import { useSocketEvent } from './useSocket';

// "X type korche" -- keu type korle 2.5 second dekhay
export function useTyping(socket, chat) {
  const [typers, setTypers] = useState({}), timers = useRef({}), lastEmit = useRef(0);
  useSocketEvent(socket, 'typing', (d) => {
    const k = d.group ? 'g:' + d.group : 'u:' + d.from, id = k + d.from;
    clearTimeout(timers.current[id]);
    setTypers((x) => ({ ...x, [k]: { ...x[k], [d.from]: 1 } }));
    timers.current[id] = setTimeout(() => setTypers((x) => { const c = { ...x[k] }; delete c[d.from]; return { ...x, [k]: c }; }), 2500);
  });
  const emitTyping = () => { // 1.2s e ekbar-i pathay
    const now = Date.now(); if (!chat || now - lastEmit.current < 1200) return; lastEmit.current = now;
    socket.emit('typing', chat.k === 'g' ? { group: chat.o._id } : { to: chat.o._id });
  };
  return { typers, emitTyping };
}
