import { useCallback, useEffect, useState } from 'react';
import { api } from '../services/api';
import { useSocketEvent } from './useSocket';

// Ke ke ache: users, groups, online, block list
export function useDirectory(socket, me) {
  const [users, setUsers] = useState([]), [groups, setGroups] = useState([]), [online, setOnline] = useState([]), [blocked, setBlocked] = useState([]);
  const refreshGroups = useCallback(() => api('/groups').then((g) => { setGroups(g); return g; }), []);
  useEffect(() => {
    api('/users').then((d) => { setUsers(d.users); setOnline(d.online); });
    refreshGroups(); api('/blocks').then((d) => setBlocked(d.blocked));
  }, [refreshGroups]);
  useSocketEvent(socket, 'presence', setOnline);
  useSocketEvent(socket, 'group:update', refreshGroups);

  const isOn = (id) => online.includes(id);
  const nameOf = (id, group) => (id === me._id ? me.name : (users.find((u) => u._id === id) || group?.members.find((u) => u._id === id) || { name: '?' }).name);
  const toggleBlock = async (id) => {
    const was = blocked.includes(id);
    await api('/blocks/' + id, { method: was ? 'DELETE' : 'POST' });
    setBlocked((b) => (was ? b.filter((x) => x !== id) : [...b, id]));
  };
  return { users, groups, online, isOn, blocked, nameOf, refreshGroups, toggleBlock };
}
