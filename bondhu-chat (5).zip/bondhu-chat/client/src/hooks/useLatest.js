import { useRef } from 'react';
// Sob somoy latest value dey -- socket handler e "stale state" somoshya thekate
export const useLatest = (value) => { const ref = useRef(value); ref.current = value; return ref; };
