import { useRef, useState } from 'react';
// Screen share: camera video track ke screen track diye replace kore (renegotiation lagena). Sudhu video call e.
export function useScreenShare({ getPcs, getStream, setPreview }) {
  const [sharing, setSharing] = useState(false), cam = useRef(null);
  const swap = async (track) => { for (const p of getPcs()) await p.getSenders().find((s) => s.track?.kind === 'video')?.replaceTrack(track); };
  const stop = async () => {
    if (!cam.current) return;
    await swap(cam.current); setPreview(getStream()); cam.current = null; setSharing(false);
  };
  const start = async () => {
    const stream = getStream(), camTrack = stream?.getVideoTracks()[0]; if (!camTrack) return;
    const track = (await navigator.mediaDevices.getDisplayMedia({ video: true })).getVideoTracks()[0];
    cam.current = camTrack; await swap(track); track.onended = stop; // browser er "Stop sharing" button
    setPreview(new MediaStream([track, ...stream.getAudioTracks()])); setSharing(true);
  };
  return { sharing, toggle: () => (sharing ? stop() : start().catch(() => {})), reset: () => { cam.current = null; setSharing(false); } };
}
