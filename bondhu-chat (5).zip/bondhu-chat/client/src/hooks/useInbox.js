import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { sfx } from '../utils/sounds';
import { chatKey, msgKey } from '../utils/format';
import { useSocketEvent } from './useSocket';
import { useLatest } from './useLatest';

// Sidebar er data: last message, unread count + notification, sound, tab title
export function useInbox(socket, chat, users) {
  const [unread, setUnread] = useState({}), [last, setLast] = useState({});
  const chatRef = useLatest(chat), usersRef = useLatest(users);
  useEffect(() => {
    api('/conversations').then((d) => {
      setLast(Object.fromEntries(d.last.map((x) => ['u:' + x._id, x.last])));
      setUnread(Object.fromEntries(d.unread.map((x) => ['u:' + x._id, x.n])));
    });
    const ask = () => window.Notification?.permission === 'default' && Notification.requestPermission();
    addEventListener('click', ask, { once: true });
  }, []);
  useSocketEvent(socket, 'msg', (m) => {
    const k = msgKey(m); setLast((x) => ({ ...x, [k]: m })); sfx.recv();
    if (document.hidden && window.Notification?.permission === 'granted') new Notification(usersRef.current.find((u) => u._id === m.from)?.name || 'Bondhu Chat', { body: m.text || (m.type === 'image' ? '📷' : '📎') });
    if (chatKey(chatRef.current) !== k) setUnread((x) => ({ ...x, [k]: (x[k] || 0) + 1 }));
  });
  // edit/delete hole sidebar preview o bodlay
  const patchLast = (id, fn) => setLast((x) => Object.fromEntries(Object.entries(x).map(([k, v]) => [k, v?._id === id ? fn(v) : v])));
  useSocketEvent(socket, 'msg:edit', (m) => patchLast(m._id, () => m));
  useSocketEvent(socket, 'msg:delete', (d) => patchLast(d._id, (v) => ({ ...v, deleted: true, text: '', file: undefined })));
  useEffect(() => { const n = Object.values(unread).reduce((a, b) => a + b, 0); document.title = (n ? `(${n}) ` : '') + 'Bondhu Chat'; }, [unread]);
  return { unread, last, setLast, patchLast, markOpen: (k) => setUnread((x) => ({ ...x, [k]: 0 })) };
}
