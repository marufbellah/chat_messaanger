import { useEffect, useRef, useState } from 'react';
import { createSocket } from '../services/socket';

export function useSocket({ onKicked, onAuthFail }) {
  const [socket, setSocket] = useState(null);
  const cb = useRef({ onKicked, onAuthFail }); cb.current = { onKicked, onAuthFail };
  useEffect(() => {
    const s = createSocket({ onKicked: () => cb.current.onKicked(), onAuthFail: () => cb.current.onAuthFail() });
    setSocket(s); return () => s.disconnect();
  }, []);
  return socket;
}
// socket event e subscribe; component unmount hole nijei unsubscribe
export function useSocketEvent(socket, event, handler) {
  const ref = useRef(handler); ref.current = handler;
  useEffect(() => {
    if (!socket) return undefined;
    const fn = (...a) => ref.current(...a);
    socket.on(event, fn); return () => socket.off(event, fn);
  }, [socket, event]);
}
