import { useEffect, useRef, useState } from 'react';
import { sfx } from '../utils/sounds';
import { rtc, mediaConstraints, toggleTrack, exposeForTests } from '../utils/webrtc';
import { useSocketEvent } from './useSocket';
import { useLatest } from './useLatest';
import { useScreenShare } from './useScreenShare';

// Group call (mesh): proti participant baki shobar sathe alada connection rakhe.
// Notun-ashha user purono shobai ke offer pathay (server 'gcall:peers' e list dey), tai glare hoy na.
export function useGroupCall(socket, me, { onFull, onError }) {
  const [gc, setGc] = useState(null), [active, setActive] = useState({});
  const gcRef = useLatest(gc), peers = useRef({}), stream = useRef(null);
  const share = useScreenShare({ getPcs: () => Object.values(peers.current), getStream: () => stream.current, setPreview: (s) => setGc((x) => x && { ...x, local: s }) });

  const mkPeer = (uid, group) => {
    const p = new RTCPeerConnection(rtc.ice); peers.current[uid] = p; exposeForTests('__gpcs', peers.current);
    stream.current.getTracks().forEach((t) => p.addTrack(t, stream.current));
    p.onicecandidate = (e) => e.candidate && socket.emit('gcall:signal', { to: uid, group, data: { ice: e.candidate } });
    p.ontrack = (e) => setGc((x) => x && { ...x, streams: { ...x.streams, [uid]: e.streams[0] } });
    return p;
  };
  const dropPeer = (uid) => {
    peers.current[uid]?.close(); delete peers.current[uid];
    setGc((x) => { if (!x) return x; const s = { ...x.streams }; delete s[uid]; return { ...x, streams: s }; });
  };
  const join = async (group, video) => {
    try {
      stream.current = await navigator.mediaDevices.getUserMedia(mediaConstraints(video));
      setGc({ group, video, local: stream.current, streams: {} }); socket.emit('gcall:join', { group, video });
    } catch { onError?.(); }
  };
  const leave = () => {
    const g = gcRef.current; if (!g) return;
    socket.emit('gcall:leave', { group: g.group }); Object.keys(peers.current).forEach(dropPeer);
    stream.current?.getTracks().forEach((x) => x.stop()); stream.current = null; share.reset(); setGc(null); sfx.end();
  };
  const toggle = (kind) => { toggleTrack(stream.current, kind); setGc((x) => ({ ...x, [kind + 'off']: !x[kind + 'off'] })); };

  useSocketEvent(socket, 'gcall:active', (d) => {
    setActive((x) => { const n = { ...x }; if (d.participants.length) n[d.group] = d; else delete n[d.group]; return n; });
    if (d.starter && d.starter !== me._id && !gcRef.current) sfx.ring();
  });
  useSocketEvent(socket, 'gcall:peers', async (d) => { // ami notun, tai ami offer pathai
    for (const uid of d.peers) { const p = mkPeer(uid, d.group); await p.setLocalDescription(await p.createOffer()); socket.emit('gcall:signal', { to: uid, group: d.group, data: { sdp: p.localDescription } }); }
  });
  useSocketEvent(socket, 'gcall:signal', (d) => {
    const p = peers.current[d.from] || (d.data.sdp?.type === 'offer' && stream.current ? mkPeer(d.from, d.group) : null); if (!p) return;
    p.queue = (p.queue || Promise.resolve()).then(async () => { // signal gulo line e (ekta shesh hole arekta)
      try {
        if (d.data.sdp) {
          await p.setRemoteDescription(d.data.sdp);
          if (d.data.sdp.type === 'offer') { await p.setLocalDescription(await p.createAnswer()); socket.emit('gcall:signal', { to: d.from, group: d.group, data: { sdp: p.localDescription } }); }
        } else if (d.data.ice) await p.addIceCandidate(d.data.ice);
      } catch (e) { console.warn(e); }
    });
  });
  useSocketEvent(socket, 'gcall:left', (d) => dropPeer(d.from));
  useSocketEvent(socket, 'gcall:full', () => { stream.current?.getTracks().forEach((x) => x.stop()); stream.current = null; setGc(null); onFull?.(); });
  useEffect(() => leave, []); // eslint-disable-line react-hooks/exhaustive-deps

  return { gc, active, join, leave, toggle, share, getPc: (uid) => peers.current[uid] };
}
