import { useEffect, useState } from 'react';
// Remote user kotha bolle 0..1 level dey (WebRTC receiver stats theke). Kothar animation / "speaking" border er jonno.
export function useAudioLevel(stream, getPc) {
  const [level, setLevel] = useState(0);
  useEffect(() => {
    if (!stream || !getPc) return undefined;
    const i = setInterval(() => {
      try { const r = getPc()?.getReceivers().find((x) => x.track?.kind === 'audio'); setLevel(Math.min(1, (r?.getSynchronizationSources?.()[0]?.audioLevel || 0) * 4)); } catch { /* ignore */ }
    }, 200);
    return () => { clearInterval(i); setLevel(0); };
  }, [stream]); // eslint-disable-line react-hooks/exhaustive-deps
  return level;
}
