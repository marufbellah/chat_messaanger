import { useEffect, useState } from 'react';
// Meeting shuru theke koto second hoyeche
export function useMeetingClock(running) {
  const [sec, setSec] = useState(0);
  useEffect(() => {
    if (!running) return undefined;
    const t0 = Date.now(), i = setInterval(() => setSec((Date.now() - t0) / 1000), 1000); setSec(0);
    return () => clearInterval(i);
  }, [running]);
  return sec;
}
