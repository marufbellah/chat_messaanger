import { useEffect, useRef, useState } from 'react';
import { AUDIO } from '../utils/webrtc';
// Voice note record. stop(true) = pathao, stop(false) = batil
export function useRecorder(onFile, onError) {
  const [sec, setSec] = useState(null), ref = useRef();
  useEffect(() => { if (sec === null) return undefined; const i = setInterval(() => setSec((s) => s + 1), 1000); return () => clearInterval(i); }, [sec === null]); // eslint-disable-line react-hooks/exhaustive-deps
  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: AUDIO });
      const mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4'].find((x) => window.MediaRecorder?.isTypeSupported(x));
      const mr = new MediaRecorder(stream, mime ? { mimeType: mime } : {}), chunks = [];
      mr.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      ref.current = { mr, stream, chunks }; mr.start(); setSec(0);
    } catch { onError?.(); }
  };
  const stop = (send) => {
    const { mr, stream, chunks } = ref.current;
    mr.onstop = () => { stream.getTracks().forEach((x) => x.stop()); if (send) onFile(new File(chunks, 'voice.' + (mr.mimeType.includes('mp4') ? 'm4a' : 'webm'), { type: mr.mimeType.split(';')[0] })); };
    mr.stop(); setSec(null);
  };
  return { recording: sec !== null, sec, start, stop };
}
