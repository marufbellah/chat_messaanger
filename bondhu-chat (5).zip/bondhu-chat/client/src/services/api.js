import { session } from './session';

const handlers = { expired: () => {} };
export const onSessionExpired = (fn) => { handlers.expired = fn; };

// Access token expire hole refresh token diye notun token ane. Ek sathe onek request 401 pele ekbar-i refresh hoy.
let refreshing = null;
export function refreshSession() {
  refreshing ||= fetch('/api/auth/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refreshToken: session.refresh }) })
    .then(async (r) => { if (!r.ok) { session.clear(); return false; } session.set(await r.json()); return true; })
    .catch(() => false).finally(() => { refreshing = null; });
  return refreshing;
}

// Shob API call ekhan diye jay. FormData dile file upload, body dile JSON.
export async function api(url, { method = 'GET', body, form, auth = true } = {}) {
  const run = () => fetch('/api' + url, {
    method, body: form || (body && JSON.stringify(body)),
    headers: { ...(auth && session.access ? { Authorization: 'Bearer ' + session.access } : {}), ...(body ? { 'Content-Type': 'application/json' } : {}) },
  });
  let r = await run();
  if (r.status === 401 && auth && session.refresh && !url.startsWith('/auth/')) {
    if (await refreshSession()) r = await run(); else handlers.expired();
  }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || 'Error');
  return data;
}
