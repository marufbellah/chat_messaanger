// Login token gulo browser e rakha (localStorage). Access token = choto-meyadi, refresh token = lomba-meyadi.
export const session = {
  get access() { return localStorage.token || ''; },
  get refresh() { return localStorage.refreshToken || ''; },
  has() { return !!(localStorage.token || localStorage.refreshToken); },
  set({ token, refreshToken }) { localStorage.token = token; localStorage.refreshToken = refreshToken; },
  clear() { localStorage.removeItem('token'); localStorage.removeItem('refreshToken'); },
};
