import { io } from 'socket.io-client';
import { session } from './session';
import { refreshSession } from './api';

// Real-time connection. Token expire hole nijei refresh kore abar connect kore.
export function createSocket({ onKicked, onAuthFail }) {
  const socket = io({ auth: (cb) => cb({ token: session.access }) });
  socket.on('disconnect', (reason) => { if (reason === 'io server disconnect') onKicked(); }); // admin inactive/delete korle
  socket.on('connect_error', async (err) => {
    if (err.message !== 'unauthorized') return;
    (await refreshSession()) ? socket.connect() : onAuthFail();
  });
  return socket;
}
