exec(open('ui_test2.py').read().split("a = mk(); b = mk(); c = mk()")[0])
import json
def assert_(c): assert c
a = mk(); b = mk(); ad = mk(); DR += [a, b, ad]
test("register 2 users", lambda: [register(d, n, e) for d, n, e in [(a, f"Uma{R}", f"uma{R}@t.com"), (b, f"Vik{R}", f"vik{R}@t.com")]])
a.refresh(); sel_item(a, f"Vik{R}"); b.refresh(); W(b, ".item"); sel_item(b, f"Uma{R}")
def live(d, video):
    r = js(d, "const au=document.querySelector('audio.raud'); const s=au&&au.srcObject; if(!s) return null; const v=document.querySelector('.stage video'); return JSON.stringify({a:s.getAudioTracks().filter(t=>t.readyState==='live').length,v:s.getVideoTracks().filter(t=>t.readyState==='live').length,w:v?v.videoWidth:0})")

    if not r: return False
    j = json.loads(r); return j['a'] >= 1 and (j['v'] >= 1 and j['w'] > 0 if video else True)
def call(video):
    W(a, f".rhead button[title='{'Video' if video else 'Audio'}']").click(); W(b, ".callbox .rbtn.ok", 10).click()
    for d in (a, b): WebDriverWait(d, 20).until(lambda x: live(x, video))
    if video: shot(a, "n5_call11")
    W(a, ".ctrls .bad").click(); gone(a, ".callbox"); gone(b, ".callbox")
test("1:1 audio call (accept, live audio, end)", call, False)
test("1:1 video call (live video, end)", call, True)
test("mute/camera toggle buttons work in call", lambda: (W(a, ".rhead button[title='Video']").click(), W(b, ".callbox .rbtn.ok", 10).click(), W(a, ".ctrls button"), js(a, "document.querySelector(\".ctrls button[title='Mic']\").click()"), time.sleep(.5), assert_(js(a, "return __pc.getSenders().find(s=>s.track&&s.track.kind==='audio').track.enabled") == False), W(a, ".ctrls .bad").click(), gone(b, ".callbox")))
login(ad, "admin@bondhu.com", "admin123"); W(ad, ".list")
def admin():
    btn(ad, "Admin panel").click(); btn(ad, "Add user").click(); fill(ad, "Full name", f"Zed{R}"); fill(ad, "Email", f"zed{R}@t.com"); fill(ad, "Password", P); btn(ad, "Save").click()
    WebDriverWait(ad, 8).until(lambda d: f"Zed{R}" in d.find_element(By.CSS_SELECTOR, "table").text)
    r = [x for x in ad.find_elements(By.CSS_SELECTOR, "tbody tr") if f"Zed{R}" in x.text][0]; js(ad, "arguments[0].click()", r.find_element(By.CSS_SELECTOR, ".switch input"))
    WebDriverWait(ad, 8).until(lambda d: "Inactive" in [x for x in d.find_elements(By.CSS_SELECTOR, "tbody tr") if f"Zed{R}" in x.text][0].text); shot(ad, "n6_admin")
    r = [x for x in ad.find_elements(By.CSS_SELECTOR, "tbody tr") if f"Zed{R}" in x.text][0]; js(ad, "const b=arguments[0]; setTimeout(()=>b.click(),0)", r.find_element(By.CSS_SELECTOR, ".danger"))
    WebDriverWait(ad, 8).until(lambda d: f"Zed{R}" not in (js(d, "return document.querySelector('table').textContent") or ''))
try: admin(); print("  ✓ admin panel: add, deactivate, delete (new icon UI)")
except Exception: print("  ✗ admin"); traceback.print_exc()
test("bangla mode renders new UI", lambda: (W(a, ".tools button[title='Language']").click(), W(a, "input[placeholder='মানুষ খুঁজুন']"), shot(a, "n7_bn"), W(a, ".tools button[title='Theme']").click(), shot(a, "n8_dark")))
for d in DR:
    try: d.quit()
    except: pass
p = sum(1 for r in res if r[1]); print(f"\n{p} passed, {len(res)-p} failed")
