exec(open('ui_test2.py').read().split("a = mk(); b = mk(); c = mk()")[0])
import json
from selenium.common.exceptions import TimeoutException
def assert_(c, m=""): assert c, m
a = mk(); b = mk(); c = mk(); DR += [a, b, c]
test("register 3 users", lambda: [register(d, n, e) for d, n, e in [(a, f"Ana{R}", f"ana{R}@t.com"), (b, f"Ben{R}", f"ben{R}@t.com"), (c, f"Cyn{R}", f"cyn{R}@t.com")]])
for d in (a, b, c): d.refresh(); W(d, ".item")
def lvl(d, sel): return js(d, "const e=document.querySelector(arguments[0]); return e? parseFloat(getComputedStyle(e).getPropertyValue('--l')||0):-1", sel)
def pkts(d, expr):
    return d.execute_async_script("const done=arguments[arguments.length-1]; (async()=>{let n=0,b=0; for(const p of "+expr+"){const r=await p.getStats(); r.forEach(s=>{if(s.type==='inbound-rtp'&&(s.kind||s.mediaType)==='audio'){n+=s.packetsReceived||0;b+=s.bytesReceived||0}})} done([n,b])})()")
def mkgroup():
    js(a, "[...document.querySelectorAll('.tabs button')].find(b=>b.textContent.includes('Groups')).click()"); js(a, "document.querySelector('.sbox button').click()"); fill(a, "Group name", f"Team{R}")
    js(a, "[...document.querySelectorAll('.pick label')].filter(l=>l.textContent.includes('Ben'+arguments[0])||l.textContent.includes('Cyn'+arguments[0])).forEach(l=>l.querySelector('input').click())", str(R)); btn(a, "Create").click()
    WebDriverWait(a, 8).until(lambda d: "3 members" in d.find_element(By.CSS_SELECTOR, ".rhead small").text)
test("create group", mkgroup)
print("\nMessage features")
sel_item(a, f"Ben{R}", "Chats"); sel_item(b, f"Ana{R}", "Chats"); say(b, "question from ben"); has_bubble(a, "question from ben")
def reply():
    menu_do(a, "question from ben", "Reply"); W(a, ".replybar"); say(a, "my answer"); WebDriverWait(b, 8).until(lambda d: any("my answer" in x and "question from ben" in x for x in bubbles(d)))
    assert js(a, "return !document.querySelector('.replybar')")
test("reply: quote shown in both, reply bar clears", reply)
def react():
    js(a, "[...document.querySelectorAll('.bub')].find(x=>x.textContent.includes('question from ben')).querySelector('.more').click()"); js(a, "document.querySelector('.rxbar button').click()")
    for d in (a, b): WebDriverWait(d, 8).until(lambda x: js(x, "return [...document.querySelectorAll('.bub')].some(b=>b.textContent.includes('question from ben')&&b.querySelector('.rx'))"))
    js(a, "[...document.querySelectorAll('.bub')].find(x=>x.textContent.includes('question from ben')).querySelector('.rx').click()")
    for d in (a, b): WebDriverWait(d, 8).until(lambda x: js(x, "return [...document.querySelectorAll('.bub')].every(b=>!b.textContent.includes('question from ben')||!b.querySelector('.rx'))"))
test("reaction: add 👍 live on both, click chip toggles off", react)
def fwd():
    menu_do(a, "my answer", "Forward"); W(a, ".modal .pick"); js(a, "[...document.querySelectorAll('.modal label')].find(l=>l.textContent.includes('Team'+arguments[0])).querySelector('input').click()", str(R)); btn(a, "Forward").click(); gone(a, ".modal")
    js(c, "[...document.querySelectorAll('.tabs button')].find(b=>b.textContent.includes('Groups')).click()"); WebDriverWait(c, 8).until(lambda d: js(d, "return [...document.querySelectorAll('.item')].find(i=>i.textContent.includes('Team'+arguments[0]))?.textContent.includes('my answer')", str(R)))
test("forward message to a group", fwd)
def voice():
    W(a, ".compose button[aria-label='voice']").click(); W(a, ".rec"); time.sleep(2.2); W(a, ".compose button[aria-label='send voice']").click()
    for d in (a, b): WebDriverWait(d, 10).until(lambda x: js(x, "return !!document.querySelector('.bub audio')"))
    assert js(b, "return new URL(document.querySelector('.bub audio').src).pathname.startsWith('/uploads/')")
test("voice note: record -> send -> audio player on both", voice)
print("\nAdmin")
ad = mk(); DR.append(ad); login(ad, "admin@bondhu.com", "admin123"); btn(ad, "Admin panel").click()
test("admin overview stats cards", lambda: (btn(ad, "Overview").click(), WebDriverWait(ad, 8).until(lambda d: len(d.find_elements(By.CSS_SELECTOR, ".stat")) == 9)))
test("admin audit log table", lambda: (btn(ad, "Audit log").click(), W(ad, "tbody tr"), shot(ad, "o1_admin")))
test("bangla: new strings render", lambda: (W(a, ".tools button[title='Language']").click(), W(a, "input[placeholder='মানুষ খুঁজুন']"), shot(a, "o2_bn")))
test("no JS errors", lambda: None)
for d in DR:
    try: d.quit()
    except: pass
p = sum(1 for r in res if r[1]); print(f"\n{p} passed, {len(res)-p} failed")
