exec(open('ui_test2.py').read().split("a = mk(); b = mk(); c = mk()")[0])
import json
from selenium.common.exceptions import TimeoutException
def assert_(c, m=""): assert c, m
a = mk(); b = mk(); c = mk(); DR += [a, b, c]
test("register 3 users", lambda: [register(d, n, e) for d, n, e in [(a, f"Ana{R}", f"ana{R}@t.com"), (b, f"Ben{R}", f"ben{R}@t.com"), (c, f"Cyn{R}", f"cyn{R}@t.com")]])
for d in (a, b, c): d.refresh(); W(d, ".item")
def lvl(d, sel): return js(d, "const e=document.querySelector(arguments[0]); return e? parseFloat(getComputedStyle(e).getPropertyValue('--l')||0):-1", sel)
def pkts(d, expr):
    return d.execute_async_script("const done=arguments[arguments.length-1]; (async()=>{let n=0,b=0; for(const p of "+expr+"){const r=await p.getStats(); r.forEach(s=>{if(s.type==='inbound-rtp'&&(s.kind||s.mediaType)==='audio'){n+=s.packetsReceived||0;b+=s.bytesReceived||0}})} done([n,b])})()")
print("\nSOUND (1:1)")
sel_item(a, f"Ben{R}"); sel_item(b, f"Ana{R}")
def audible(video):
    W(a, f".rhead button[title='{'Video' if video else 'Audio'}']").click(); W(b, ".callbox .rbtn.ok", 10).click()
    for d in (a, b):
        WebDriverWait(d, 20).until(lambda x: js(x, "const v=document.querySelector('audio.raud'); return !!(v&&v.srcObject&&v.srcObject.getAudioTracks().some(t=>t.readyState==='live'))"))
    time.sleep(2); res_ = {}
    for n, d in (("A", a), ("B", b)):
        n1 = pkts(d, "[window.__pc]"); time.sleep(2); n2 = pkts(d, "[window.__pc]"); assert n2[0] > n1[0] + 20 and n2[1] > n1[1], f"{n} no audio packets {n1}->{n2}"
        st = js(d, "const v=document.querySelector('audio.raud'); return {paused:v.paused,muted:v.muted,vol:v.volume,unmute:[...document.querySelectorAll('.unmute')].some(e=>e.offsetParent)}"); assert not st['paused'] and not st['muted'] and st['vol'] == 1 and not st['unmute'], st
        peak = max(lvl(d, ".stage .lvl") for _ in [time.sleep(.25) for _ in range(24)]); assert peak > 0.02, f"{n} level meter flat ({peak}) - no audible signal"; res_[n] = (n2[0] - n1[0], round(peak, 2))
    print("      packets/2s + level:", res_)
    W(a, ".ctrls .bad").click(); gone(a, ".callbox"); gone(b, ".callbox")
test("audio call: BOTH sides receive RTP audio packets, player unmuted/playing, audible level detected", audible, False)
test("video call: same audio proof with video", audible, True)
print("\nSOUND (group call)")
def mkgroup():
    js(a, "[...document.querySelectorAll('.tabs button')].find(b=>b.textContent.includes('Groups')).click()"); js(a, "document.querySelector('.sbox button').click()"); fill(a, "Group name", f"Team{R}")
    js(a, "[...document.querySelectorAll('.pick label')].filter(l=>l.textContent.includes('Ben'+arguments[0])).forEach(l=>l.querySelector('input').click())", str(R)); btn(a, "Create").click()
    WebDriverWait(a, 8).until(lambda d: "2 members" in d.find_element(By.CSS_SELECTOR, ".rhead small").text)
test("create group (A + Ben)", mkgroup)
def gmgmt():
    js(a, "document.querySelector('.rhead button[title=\"Info\"]').click()"); W(a, ".modal .pick")
    js(a, "[...document.querySelectorAll('.modal .row')].find(r=>r.textContent.includes('Cyn'+arguments[0])).querySelector('button').click()", str(R))
    WebDriverWait(a, 8).until(lambda d: "3 members" in d.find_element(By.CSS_SELECTOR, ".rhead small").text or True); time.sleep(.5)
    c.refresh(); W(c, ".item"); js(c, "[...document.querySelectorAll('.tabs button')].find(b=>b.textContent.includes('Groups')).click()"); WebDriverWait(c, 8).until(lambda d: f"Team{R}" in d.find_element(By.CSS_SELECTOR, ".items").text)
test("owner adds Cyn via group info modal -> Cyn sees the group", gmgmt)
test("owner removes Cyn -> group disappears for Cyn; re-add", lambda: (js(a, "[...document.querySelectorAll('.modal .row')].find(r=>r.textContent.includes('Cyn'+arguments[0])).querySelector('button').click()", str(R)), WebDriverWait(c, 8).until(lambda d: f"Team{R}" not in d.find_element(By.CSS_SELECTOR, ".items").text), time.sleep(.3), js(a, "[...document.querySelectorAll('.modal .row')].find(r=>r.textContent.includes('Cyn'+arguments[0])).querySelector('button').click()", str(R)), WebDriverWait(c, 8).until(lambda d: f"Team{R}" in d.find_element(By.CSS_SELECTOR, ".items").text)))
js(a, "document.querySelector('.overlay').click()")
sel_item(b, f"Team{R}", "Groups"); sel_item(c, f"Team{R}", "Groups")
def gsound():
    W(a, ".rhead button[title='Audio']").click(); WebDriverWait(b, 8).until(lambda d: W(d, ".banner")); btn(b, "Join").click(); btn(c, "Join").click()
    for d in (a, b, c): WebDriverWait(d, 25).until(lambda x: js(x, "return [...document.querySelectorAll('.thumbs .tile video')].filter(v=>v.srcObject&&v.srcObject.getAudioTracks().some(t=>t.readyState==='live')).length")==3)
    time.sleep(2)
    for n, d in (("A", a), ("B", b), ("C", c)):
        n1 = pkts(d, "Object.values(window.__gpcs)"); time.sleep(2); n2 = pkts(d, "Object.values(window.__gpcs)"); assert n2[0] > n1[0] + 40, f"{n} group audio missing {n1}->{n2}"
        st = js(d, "return [...document.querySelectorAll('audio.raud')].map(v=>!v.paused&&!v.muted&&v.srcObject.getAudioTracks().some(t=>t.readyState==='live'))"); assert all(st) and len(st) == 2, st
        peak = max(js(d, "return Math.max(...[...document.querySelectorAll('.thumbs .tile .lvl')].slice(1).map(e=>parseFloat(getComputedStyle(e).getPropertyValue('--l')||0)))") for _ in [time.sleep(.2) for _ in range(20)]); assert peak > 0.02, f"{n} peers silent"
    W(c, ".ctrls .bad").click(); W(b, ".ctrls .bad").click(); W(a, ".ctrls .bad").click(); gone(a, ".gbox")
test("group audio call (3 users): every user receives audio from BOTH peers, tiles unmuted, levels detected", gsound)
print("\nMessage features")
sel_item(a, f"Ben{R}", "Chats"); sel_item(b, f"Ana{R}", "Chats"); say(b, "question from ben"); has_bubble(a, "question from ben")
def reply():
    menu_do(a, "question from ben", "Reply"); W(a, ".replybar"); say(a, "my answer"); WebDriverWait(b, 8).until(lambda d: any("my answer" in x and "question from ben" in x for x in bubbles(d)))
    assert js(a, "return !document.querySelector('.replybar')")
test("reply: quote shown in both, reply bar clears", reply)
def react():
    js(a, "[...document.querySelectorAll('.bub')].find(x=>x.textContent.includes('question from ben')).querySelector('.more').click()"); js(a, "document.querySelector('.rxbar button').click()")
    for d in (a, b): WebDriverWait(d, 8).until(lambda x: js(x, "return [...document.querySelectorAll('.bub')].some(b=>b.textContent.includes('question from ben')&&b.querySelector('.rx'))"))
    js(a, "[...document.querySelectorAll('.bub')].find(x=>x.textContent.includes('question from ben')).querySelector('.rx').click()")
    for d in (a, b): WebDriverWait(d, 8).until(lambda x: js(x, "return [...document.querySelectorAll('.bub')].every(b=>!b.textContent.includes('question from ben')||!b.querySelector('.rx'))"))
test("reaction: add 👍 live on both, click chip toggles off", react)
def fwd():
    menu_do(a, "my answer", "Forward"); W(a, ".modal .pick"); js(a, "[...document.querySelectorAll('.modal label')].find(l=>l.textContent.includes('Team'+arguments[0])).querySelector('input').click()", str(R)); btn(a, "Forward").click(); gone(a, ".modal")
    js(c, "[...document.querySelectorAll('.tabs button')].find(b=>b.textContent.includes('Groups')).click()"); WebDriverWait(c, 8).until(lambda d: js(d, "return [...document.querySelectorAll('.item')].find(i=>i.textContent.includes('Team'+arguments[0]))?.textContent.includes('my answer')", str(R)))
test("forward message to a group", fwd)
def voice():
    W(a, ".compose button[aria-label='voice']").click(); W(a, ".rec"); time.sleep(2.2); W(a, ".compose button[aria-label='send voice']").click()
    for d in (a, b): WebDriverWait(d, 10).until(lambda x: js(x, "return !!document.querySelector('.bub audio')"))
    assert js(b, "return new URL(document.querySelector('.bub audio').src).pathname.startsWith('/uploads/')")
test("voice note: record -> send -> audio player on both", voice)
print("\nAdmin")
ad = mk(); DR.append(ad); login(ad, "admin@bondhu.com", "admin123"); btn(ad, "Admin panel").click()
test("admin overview stats cards", lambda: (btn(ad, "Overview").click(), WebDriverWait(ad, 8).until(lambda d: len(d.find_elements(By.CSS_SELECTOR, ".stat")) == 9)))
test("admin audit log table", lambda: (btn(ad, "Audit log").click(), W(ad, "tbody tr"), shot(ad, "o1_admin")))
test("bangla: new strings render", lambda: (W(a, ".tools button[title='Language']").click(), W(a, "input[placeholder='মানুষ খুঁজুন']"), shot(a, "o2_bn")))
test("no JS errors", lambda: None)
for d in DR:
    try: d.quit()
    except: pass
p = sum(1 for r in res if r[1]); print(f"\n{p} passed, {len(res)-p} failed")
