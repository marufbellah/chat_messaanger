import time, random, traceback, os, base64, shutil
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException

URL = os.environ.get("APP_URL", "http://127.0.0.1:5173"); SH = os.environ.get("SHOTS_DIR", os.path.join(os.getcwd(), "shots")); os.makedirs(SH, exist_ok=True); R = random.randint(1000, 9999)
PNG = os.path.join(os.environ.get("TMPDIR", "/tmp"), "bondhu_test.png")
open(PNG, "wb").write(base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="))
def mk(w=1280, h=850):
    o = Options(); o.add_argument("-headless"); o.set_capability("unhandledPromptBehavior", "accept"); o.binary_location = (os.environ.get("FIREFOX_BIN") or shutil.which("firefox"))
    for k, v in {"media.navigator.streams.fake": True, "media.navigator.permission.disabled": True, "media.peerconnection.ice.obfuscate_host_addresses": False,
                 "media.peerconnection.ice.loopback": True, "media.autoplay.default": 0, "media.getdisplaymedia.screen.enabled": True, "media.getdisplaymedia.browser.enabled": True, "media.autoplay.blocking_policy": 0, "media.autoplay.block-webaudio": False, "intl.accept_languages": "en-US"}.items(): o.set_preference(k, v)
    d = webdriver.Firefox(options=o, service=Service((os.environ.get("GECKODRIVER") or shutil.which("geckodriver")))); d.set_window_size(w, h); d.get(URL); return d
def W(d, css, t=8, vis=True):
    return WebDriverWait(d, t).until(lambda x: next((e for e in x.find_elements(By.CSS_SELECTOR, css) if (e.is_displayed() or not vis)), None))
def gone(d, css, t=8): WebDriverWait(d, t).until(lambda x: x.execute_script("return ![...document.querySelectorAll(arguments[0])].some(e=>e.getClientRects().length>0)", css))
def btn(d, text, t=8): return WebDriverWait(d, t).until(lambda x: next((e for e in x.find_elements(By.XPATH, f"//button[normalize-space()='{text}']") if e.is_displayed()), None))
def fill(d, ph, val): e = W(d, f"input[placeholder='{ph}']"); e.clear(); e.send_keys(val)
def shot(d, n): d.save_screenshot(f"{SH}/{n}.png")
def bubbles(d): return d.execute_script("return [...document.querySelectorAll('.bub')].map(e=>e.textContent)")
def has_bubble(d, s, t=8): WebDriverWait(d, t).until(lambda x: any(s in b for b in bubbles(x)))
res = []
def test(name, fn, *a):
    try: fn(*a); res.append((name, True, "")); print("  ✓", name)
    except Exception as e:
        res.append((name, False, repr(e)[:200])); print("  ✗", name, "\n     ", repr(e)[:300])
        for d in DR: 
            try: shot(d, "FAIL_" + name[:20].replace(" ", "_") + str(DR.index(d)))
            except: pass
DR = []
A = f"alice{R}@t.com"; B = f"bob{R}@t.com"; P = "secret12"
def register(d, name, email):
    btn(d, "New here? Create an account").click(); fill(d, "Full name", name); fill(d, "Email", email); fill(d, "Password", P); btn(d, "Create account").click(); W(d, ".list")
def login(d, email, pw=P): fill(d, "Email", email); fill(d, "Password", pw); btn(d, "Log in").click()


def js(d, code, *a): return d.execute_script(code, *a)
def sel_item(d, name, tab=None):
    if tab: js(d, "[...document.querySelectorAll('.tabs button')].find(b=>b.textContent.includes(arguments[0])).click()", tab)
    WebDriverWait(d, 10).until(lambda x: x.execute_script("const e=[...document.querySelectorAll('.item')].find(i=>i.textContent.includes(arguments[0])); if(e){e.click();return true}", name)); W(d, ".compose")
def say(d, text): e = W(d, ".compose .mi"); e.send_keys(text, Keys.ENTER)
def menu_do(d, bubble_text, action):
    js(d, "const b=[...document.querySelectorAll('.bub')].find(x=>x.textContent.includes(arguments[0])); b.querySelector('.more').click()", bubble_text)
    WebDriverWait(d, 5).until(lambda x: x.execute_script("const m=[...document.querySelectorAll('.menu button')].find(b=>b.textContent.includes(arguments[0])); if(m){m.click();return true}", action))
a = mk(); b = mk(); c = mk(); DR += [a, b, c]
for d in DR: js(d, "window.__e=[]; addEventListener('error',e=>__e.push(e.message))")
print("\nSetup"); 
test("register 3 users", lambda: [register(d, n, e) for d, n, e in [(a, f"Ana{R}", f"ana{R}@t.com"), (b, f"Ben{R}", f"ben{R}@t.com"), (c, f"Cyn{R}", f"cyn{R}@t.com")]])
a.refresh(); b.refresh(); W(a, ".item"); W(b, ".item")
for d in (a, b): js(d, "window.__e=[]; addEventListener('error',e=>__e.push(e.message))")
print("\nDirect chat")
test("A sends to Ben; Ben gets badge; opens; read ticks turn blue for A", lambda: (sel_item(a, f"Ben{R}"), say(a, "hello ben"), W(b, ".item .badge"), sel_item(b, f"Ana{R}"), W(b, ".bub"), W(a, ".bub .rd")))
test("typing indicator shows name/typing in header + dots bubble", lambda: (a.find_element(By.CSS_SELECTOR, ".compose .mi").send_keys("x"), WebDriverWait(b, 5).until(lambda d: js(d, "return !!document.querySelector('.rhead small.tp') && !!document.querySelector('.bub.typing')")), shot(b, "n1_typing")))
a.find_element(By.CSS_SELECTOR, ".compose .mi").clear()
def edit():
    menu_do(a, "hello ben", "Edit"); i = W(a, ".editbox input"); i.send_keys(Keys.CONTROL + "a"); i.send_keys("hello EDITED", Keys.ENTER)
    for d in (a, b): WebDriverWait(d, 6).until(lambda x: any("hello EDITED" in t and "edited" in t for t in bubbles(x)))
test("edit message -> updates live for both with 'edited' label", edit)
def photo():
    a.find_element(By.CSS_SELECTOR, ".compose input[type=file]").send_keys(PNG); W(a, ".bub img"); W(b, ".bub img")
    src1 = js(a, "return document.querySelector('.bub img').getAttribute('src')")
    js(a, "document.querySelector('.bub img').closest('.bub').querySelector('.more').click()")
    WebDriverWait(a, 5).until(lambda x: x.execute_script("const m=[...document.querySelectorAll('.menu button')].find(b=>b.textContent.includes('Replace photo')); if(m){m.click();return true}"))
    inp = a.find_element(By.CSS_SELECTOR, ".room > input[type=file]"); js(a, "arguments[0].style.display='block'", inp); inp.send_keys(PNG)
    for d in (a, b): WebDriverWait(d, 8).until(lambda x: x.execute_script("return document.querySelector('.bub img').getAttribute('src')") != src1)
test("photo send + REPLACE photo (new file, both sides update live)", photo)
def delete():
    js(a, "const b=document.querySelector('.bub img').closest('.bub'); b.querySelector('.more').click()"); from selenium.common.exceptions import UnexpectedAlertPresentException as UA
    WebDriverWait(a, 5).until(lambda x: x.execute_script("const m=[...document.querySelectorAll('.menu button')].find(b=>b.textContent.includes('Delete')); if(m){setTimeout(()=>m.click(),0);return true}"))
    pass
    for d in (a, b): WebDriverWait(d, 6).until(lambda x: any("This message was deleted" in t for t in bubbles(x)))
test("delete photo message -> 'deleted' placeholder for both", delete)
print("\nGroups")
def mkgroup():
    js(a, "[...document.querySelectorAll('.tabs button')].find(b=>b.textContent.includes('Groups')).click()"); js(a, "document.querySelector(\".sbox button\").click()"); fill(a, "Group name", f"Team{R}")
    js(a, "[...document.querySelectorAll('.pick label')].filter(l=>l.textContent.includes('Ben'+arguments[0])||l.textContent.includes('Cyn'+arguments[0])).forEach(l=>l.querySelector('input').click())", str(R)); btn(a, "Create").click(); W(a, ".rhead")
    WebDriverWait(a, 8).until(lambda d: "3 members" in d.find_element(By.CSS_SELECTOR, ".rhead small").text); shot(a, "n2_group")
test("A creates group with Ben + Cyn", mkgroup)
test("Ben and Cyn see the group; group message reaches both with sender name", lambda: (sel_item(b, f"Team{R}", "Groups"), sel_item(c, f"Team{R}", "Groups"), say(a, "hi team"), has_bubble(b, "hi team"), has_bubble(c, "hi team"), say(b, "yo from ben"), has_bubble(c, "yo from ben"), W(c, ".sname")))
def gtyping():
    c.find_element(By.CSS_SELECTOR, ".compose .mi").send_keys("z"); WebDriverWait(a, 5).until(lambda d: f"Cyn{R}" in W(d, ".rhead small.tp").text and "typing" in W(d, ".rhead small.tp").text)
test("group typing shows WHO is typing ('Cyn.. is typing…')", gtyping)
c.find_element(By.CSS_SELECTOR, ".compose .mi").clear()
print("\nGroup call (3 browsers, mesh)")
import json
def streams(d): return json.loads(js(d, "return JSON.stringify([...document.querySelectorAll('.thumbs .tile video')].map(v=>{const s=v.srcObject;return s?{a:s.getAudioTracks().filter(t=>t.readyState==='live').length,v:s.getVideoTracks().filter(t=>t.readyState==='live').length,w:v.videoWidth}:null}))"))
def gcall():
    W(a, ".rhead button[title='Video']").click(); WebDriverWait(b, 8).until(lambda d: "Call in progress" in W(d, ".banner").text); WebDriverWait(c, 8).until(lambda d: "Call in progress" in W(d, ".banner").text)
    btn(b, "Join").click(); W(b, ".gbox"); btn(c, "Join").click(); W(c, ".gbox")
    def ok(d): s = streams(d); return len(s) == 3 and all(x and x['a'] >= 1 and x['v'] >= 1 and x['w'] > 0 for x in s)
    for d in (a, b, c): WebDriverWait(d, 25).until(ok)
    shot(a, "n3_group_call"); W(c, ".ctrls .bad").click(); WebDriverWait(a, 8).until(lambda d: len(streams(d)) == 2)
    W(b, ".ctrls .bad").click(); W(a, ".ctrls .bad").click(); gone(a, ".gbox")
test("group video call: 3 users, every tile has live audio+video; leaving removes tile", gcall)
test("call banner disappears after everyone leaves", lambda: gone(b, ".banner"))
print("\nMisc")
def sound():
    W(a, ".tools button[title='Sound']").click(); assert js(a, "return localStorage.muted") == "1"; W(a, ".tools button[title='Sound']").click(); assert js(a, "return localStorage.muted") == "0"
test("sound mute toggle persists", sound)
def prof():
    W(a, ".top button[title='Profile']").click(); i = W(a, ".modal input"); i.clear(); i.send_keys(f"AnaNew{R}"); btn(a, "Save").click(); time.sleep(.8); js(a, "document.querySelector('.overlay').click()"); gone(a, ".modal")
    assert js(a, "return !!document.querySelector('.top .av')")
test("profile modal: rename works", prof)
def mobile():
    a.set_window_size(390, 800); time.sleep(.5); btn(a, "Chats").click() if False else None
    assert js(a, "return document.documentElement.scrollWidth<=innerWidth"), "overflow"; shot(a, "n4_mobile")
test("mobile layout has no overflow", mobile)
test("no JS runtime errors in any browser", lambda: [(_ for _ in ()).throw(AssertionError(js(d, "return __e.join('|')"))) for d in (a, b, c) if js(d, "return __e.length")] and None)
for d in DR:
    try: d.quit()
    except: pass
p = sum(1 for r in res if r[1]); print(f"\n{p} passed, {len(res)-p} failed")
