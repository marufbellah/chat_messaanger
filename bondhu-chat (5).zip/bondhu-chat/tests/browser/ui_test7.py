exec(open('ui_test2.py').read().split("a = mk(); b = mk(); c = mk()")[0])
import re, json, urllib.request
def assert_(c, m=""): assert c, m
LOG = os.environ.get("SERVER_LOG", "server.log")  # server er output file (dev mode e email ekhane print hoy)
def mail_token(email, key):  # dev mode e email server log e print hoy
    blocks = [b for b in open(LOG, errors="ignore").read().split("[mail:dev]") if f"to={email}" in b and f"?{key}=" in b]
    return re.search(r"\?" + key + r"=([\w-]+)", blocks[-1]).group(1)
def post(path, body, tok=None):
    r = urllib.request.Request("http://127.0.0.1:5000/api" + path, data=json.dumps(body).encode(), headers={"Content-Type": "application/json", **({"Authorization": "Bearer " + tok} if tok else {})})
    return json.load(urllib.request.urlopen(r))
def uid(d): return d.execute_script("return JSON.parse(atob(localStorage.token.split('.')[1])).id")
a = mk(); b = mk(); DR += [a, b]
XE, YE, NEWPW = f"xena{R}@t.com", f"yuri{R}@t.com", "brandnew99"
test("register X and Y", lambda: (register(a, f"Xena{R}", XE), register(b, f"Yuri{R}", YE)))
print("\nEmail verify + password recovery")
def verify():
    assert_(vis_banner(a)); time.sleep(.5); tok = mail_token(XE, "verify"); a.get(f"{URL}/?verify={tok}"); W(a, ".notice"); assert_("verified" in W(a, ".notice").text.lower())
    WebDriverWait(a, 8).until(lambda d: not d.find_elements(By.CSS_SELECTOR, ".vbar"))
def vis_banner(d): return bool(d.find_elements(By.CSS_SELECTOR, ".vbar"))
test("unverified banner shows; clicking the emailed link verifies and hides the banner", verify)
def forgot():
    btn(a, "Log out").click(); W(a, ".card"); btn(a, "Forgot password?").click(); fill(a, "Email", XE); btn(a, "Send reset link").click()
    WebDriverWait(a, 8).until(lambda d: "reset link" in d.find_element(By.CSS_SELECTOR, ".info").text); time.sleep(.5)
    tok = mail_token(XE, "reset"); a.get(f"{URL}/?reset={tok}"); fill(a, "New password", NEWPW); btn(a, "Set new password").click(); W(a, ".list")
    btn(a, "Log out").click(); W(a, ".card"); login(a, XE, NEWPW); W(a, ".list")
test("forgot password -> email link -> set new password -> logged in -> login works with new password", forgot)
def refresh():
    old = js(a, "return localStorage.token"); js(a, "localStorage.token='garbage'"); a.refresh(); W(a, ".list"); new = js(a, "return localStorage.token")
    assert_(new != "garbage" and new != old, "token not refreshed")
test("expired/invalid access token is silently refreshed (stays logged in after reload)", refresh)
print("\nBlock + pagination")
a.refresh(); b.refresh(); W(a, ".item"); W(b, ".item"); sel_item(a, f"Yuri{R}"); sel_item(b, f"Xena{R}")
def block():
    W(a, ".rhead button[title='Block']").click(); W(a, ".blockedbar"); assert_(js(a, "return document.querySelector(\".rhead button[title='Audio']\").disabled")); assert_(js(a, "return !document.querySelector('.compose .mi')"))
    say_b = lambda: (W(b, ".compose .mi").send_keys("are you there", Keys.ENTER), time.sleep(1))
    say_b(); assert_(js(a, "return ![...document.querySelectorAll('.bub')].some(x=>x.textContent.includes('are you there'))"), "blocked msg delivered")
    js(a, "document.querySelector('.blockedbar button').click()"); W(a, ".compose .mi"); assert_(not a.find_elements(By.CSS_SELECTOR, ".blockedbar"))
test("block: composer replaced, calls disabled, blocked user's message not delivered; unblock restores", block)
def older():
    tok = post("/auth/login", {"email": XE, "password": NEWPW})["token"]; yid = uid(b)
    for i in range(55): post("/messages", {"to": yid, "text": f"bulk {i}"}, tok)
    a.refresh(); W(a, ".item"); sel_item(a, f"Yuri{R}"); WebDriverWait(a, 10).until(lambda d: js(d, "return document.querySelectorAll('.bub').length") >= 50)
    n1 = js(a, "return document.querySelectorAll('.bub').length"); assert_(n1 <= 51, n1); W(a, ".older").click()
    WebDriverWait(a, 8).until(lambda d: js(d, "return document.querySelectorAll('.bub').length") > n1); assert_(js(a, "return document.querySelectorAll('.bub').length") >= 55)
    WebDriverWait(a, 8).until(lambda d: not d.find_elements(By.CSS_SELECTOR, ".older"))
test("message history paginates: 50 shown, 'Load older' fetches the rest", older)
print("\nScreen share")
def share():
    b.refresh(); W(b, ".item"); sel_item(b, f"Xena{R}"); W(a, ".rhead button[title='Video']").click(); W(b, ".callbox .rbtn.ok", 10).click(); W(a, ".meet"); time.sleep(4)
    js(a, "navigator.mediaDevices.getDisplayMedia = async () => { const c=document.createElement('canvas'); c.width=640; c.height=360; const x=c.getContext('2d'); setInterval(()=>{x.fillStyle='#'+Math.floor(Math.random()*0xffffff).toString(16).padStart(6,'0'); x.fillRect(0,0,640,360)},100); return c.captureStream(10); }")  # sandbox e screen nei, tai capture stub; baki logic real
    before = js(a, "return __pc.getSenders().find(s=>s.track&&s.track.kind==='video').track.id"); W(a, ".cbtn[title='Share screen']").click(); time.sleep(2)
    after = js(a, "return __pc.getSenders().find(s=>s.track&&s.track.kind==='video').track.id"); assert_(after != before, "video sender track not replaced")
    assert_(js(a, "return !!document.querySelector(\".cbtn.on[title='Stop sharing']\")")); n1 = js(b, "const s=__pc.getReceivers().find(r=>r.track.kind==='video'); return s.track.readyState"); assert_(n1 == "live")
    W(a, ".cbtn[title='Stop sharing']").click(); time.sleep(1); back = js(a, "return __pc.getSenders().find(s=>s.track&&s.track.kind==='video').track.id"); assert_(back == before, "camera not restored")
    W(a, ".ctrls .bad").click(); gone(a, ".meet"); gone(b, ".meet")
test("screen share swaps the video track live and restores the camera on stop", share)
for d in DR:
    try: d.quit()
    except: pass
p = sum(1 for r in res if r[1]); print(f"\n{p} passed, {len(res)-p} failed")
