exec(open('ui_test2.py').read().split("a = mk(); b = mk(); c = mk()")[0])
# Mobile regression: submit button visible on phone, can register, can end a call on phone, no overflow
a = mk(1200, 800); m = mk(390, 800); DR += [a, m]
def assert_(c): assert c
def vis(d, css): return d.execute_script("const e=document.querySelector(arguments[0]); if(!e) return false; const r=e.getBoundingClientRect(); return r.width>20&&r.height>20&&getComputedStyle(e).display!=='none'", css)
test("mobile: login + register submit buttons are visible", lambda: (W(m, ".card"), assert_(vis(m, ".card .btn")), btn(m, "New here? Create an account").click(), assert_(vis(m, ".card .btn")), fill(m, "Full name", f"Mob{R}"), fill(m, "Email", f"mob{R}@t.com"), fill(m, "Password", P), btn(m, "Create account").click(), W(m, ".list")))
register(a, f"Web{R}", f"web{R}@t.com"); m.refresh(); a.refresh(); W(a, ".item"); W(m, ".item")
def call():
    sel_item(a, f"Mob{R}"); W(a, ".rhead button[title='Video']").click(); W(m, ".callbox .rbtn.ok", 10); assert_(vis(m, ".rbtn.ok") and vis(m, ".rbtn.bad")); m.find_element(By.CSS_SELECTOR, ".callbox .rbtn.ok").click(); W(m, ".meet"); time.sleep(3)
    assert_(vis(m, ".ctrls .bad")), "end button hidden on mobile"; assert_(js(m, "return document.documentElement.scrollWidth<=innerWidth"))
    js(m, "document.querySelector('.cbtn.mob').click()"); W(m, ".mside"); W(m, ".mcomp input").send_keys("hi from phone", Keys.ENTER); has_bubble(a, "hi from phone")
    js(m, "document.querySelector('.cbtn.mob').click()"); W(m, ".ctrls .bad").click(); gone(m, ".meet"); gone(a, ".meet")
test("mobile: ring buttons, in-call chat panel, End button works, no overflow", call)
for d in DR:
    try: d.quit()
    except: pass
p = sum(1 for r in res if r[1]); print(f"\n{p} passed, {len(res)-p} failed")
