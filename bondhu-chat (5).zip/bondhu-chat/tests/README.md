# Tests
- **API + socket (Node, real MongoDB):** `cd server && npm test` -> `server/test/e2e.js` (65 test)
- **Browser UI (Selenium + Firefox):** `tests/browser/ui_test2..7.py` — API (:5000) ar client (:5173) chalu rekhe, `cd tests/browser` theke chalan.
  Env: `APP_URL` (default http://127.0.0.1:5173), `FIREFOX_BIN`, `GECKODRIVER`, `SERVER_LOG` (ui_test7: dev-mode e email ekhane print hoy), `SHOTS_DIR`.
  | File | Ki test kore |
  |---|---|
  | ui_test2 | chat, typing, edit/delete/photo replace, group, group video call, profile, mobile |
  | ui_test3 | 1:1 audio/video call + mic/camera toggle, admin panel |
  | ui_test4 | **kothar sound er proof** (RTP audio packet + audio level), group management, reply/react/forward/voice note |
  | ui_test5 | reply/react/forward/voice/admin tabs |
  | ui_test6 | mobile regression (login button, call End button) |
  | ui_test7 | verify email, forgot/reset password, token refresh, block, pagination, screen share |
