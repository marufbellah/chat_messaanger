const { User } = require('../models'), rt = require('../realtime'), blocks = require('../services/block.service');
const h = require('../utils/asyncHandler');
// chat korar moto shob active user + ke ke online
exports.list = h(async (req, res) => {
  const users = await User.find({ active: true, _id: { $ne: req.user._id } }).sort('name');
  res.json({ users: users.map((u) => u.toPublic()), online: rt.online() });
});
exports.blocked = h(async (req, res) => res.json({ blocked: await blocks.listIds(req.user._id) }));
exports.block = h(async (req, res) => { await blocks.block(req.user, req.params.id); res.json({ ok: true }); });
exports.unblock = h(async (req, res) => { await blocks.unblock(req.user, req.params.id); res.json({ ok: true }); });
