const crypto = require('crypto'), mongoose = require('mongoose');
const env = require('../config/env'), calls = require('../services/call.service');
const h = require('../utils/asyncHandler');
exports.health = (req, res) => res.json({ ok: true, db: mongoose.connection.readyState === 1, uptime: process.uptime() });
exports.calls = h(async (req, res) => res.json(await calls.historyOf(req.user._id)));
// STUN (free) + TURN (apnar server). TURN na thakle alada network e (CGNAT/mobile data) call connect hoy na
exports.ice = (req, res) => {
  const iceServers = [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }];
  if (env.TURN_URL) {
    const urls = env.TURN_URL.split(',').map((x) => x.trim());
    if (env.TURN_SECRET) { // coturn "use-auth-secret": 24 ghonta cholar moto temporary credential
      const username = Math.floor(Date.now() / 1000) + 86400 + ':' + req.user._id;
      iceServers.push({ urls, username, credential: crypto.createHmac('sha1', env.TURN_SECRET).update(username).digest('base64') });
    } else if (env.TURN_USER) iceServers.push({ urls, username: env.TURN_USER, credential: env.TURN_PASS });
  }
  res.json({ iceServers });
};
