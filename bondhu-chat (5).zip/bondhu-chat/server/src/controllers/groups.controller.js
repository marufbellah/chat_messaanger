const groups = require('../services/group.service'), messages = require('../services/message.service');
const h = require('../utils/asyncHandler');
const mine = (req) => groups.getForMember(req.params.id, req.user._id); // member na hole 404
exports.create = h(async (req, res) => res.json(await groups.create(req.user, req.body)));
exports.list = h(async (req, res) => res.json(await groups.listFor(req.user._id)));
exports.update = h(async (req, res) => res.json(await groups.update(req.user, await mine(req), req.body)));
exports.leave = h(async (req, res) => { await groups.leave(req.user, await mine(req)); res.json({ ok: true }); });
exports.remove = h(async (req, res) => { await groups.remove(req.user, await mine(req)); res.json({ ok: true }); });
exports.history = h(async (req, res) => { await mine(req); res.json(await messages.history({ group: req.params.id }, req.query)); });
exports.send = h(async (req, res) => res.json(await messages.sendGroup(req.user, await mine(req), req.body, req.file)));
