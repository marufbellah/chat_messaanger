const auth = require('../services/auth.service'), storage = require('../services/storage');
const h = require('../utils/asyncHandler'), { E } = require('../utils/httpError');
exports.get = (req, res) => res.json(req.user.toPublic());
exports.update = h(async (req, res) => { req.user.name = req.body.name; await req.user.save(); res.json(req.user.toPublic()); });
exports.changePassword = h(async (req, res) => res.json(await auth.changePassword(req.user, req.body)));
exports.avatar = h(async (req, res) => {
  if (!req.file) throw E(400, 'Image required');
  const old = req.user.avatar; req.user.avatar = await storage.save(req.file); await req.user.save(); storage.remove(old);
  res.json(req.user.toPublic());
});
