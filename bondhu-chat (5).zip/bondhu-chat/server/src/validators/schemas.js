// Request body er niyom (zod). Controller e dhokar age check hoy.
const { z } = require('zod');
const name = z.string({ required_error: 'Name required' }).trim().min(1, 'Name required').max(60, 'Name too long');
const email = z.string({ required_error: 'Email required' }).trim().email('Invalid email');
const password = z.string({ required_error: 'Password required' }).min(6, 'Password must be at least 6 characters');
const ids = z.array(z.string()).optional();

exports.register = z.object({ name, email, password });
exports.login = z.object({ email: z.string(), password: z.string() });
exports.refresh = z.object({ refreshToken: z.string().min(1) });
exports.forgot = z.object({ email: z.string() });
exports.reset = z.object({ token: z.string().min(1), password });
exports.verify = z.object({ token: z.string().min(1) });
exports.updateMe = z.object({ name });
exports.changePassword = z.object({ current: z.string(), password });
exports.adminCreate = z.object({ name, email, password: password.optional(), role: z.enum(['user', 'admin']).optional(), active: z.boolean().optional() });
exports.adminUpdate = z.object({ name: name.optional(), email: email.optional(), password: password.optional(), role: z.enum(['user', 'admin']).optional(), active: z.boolean().optional() });
exports.groupCreate = z.object({ name: z.string().trim().min(1, 'Group name required').max(60), members: ids });
exports.groupUpdate = z.object({ name: z.string().trim().min(1).max(60).optional(), add: ids, remove: ids });
exports.react = z.object({ emoji: z.string().min(1).max(8) });
exports.forward = z.object({ users: ids, groups: ids });
