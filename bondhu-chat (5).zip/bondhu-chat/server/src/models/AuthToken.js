const { Schema, model } = require('mongoose');
// ek-bar-bebohar-joggo token: password reset ar email verify
module.exports = model('AuthToken', new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User' }, type: { type: String, enum: ['reset', 'verify'] }, hash: { type: String, unique: true },
  expires: { type: Date, index: { expireAfterSeconds: 0 } },
}, { timestamps: true }));
