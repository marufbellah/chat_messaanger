const { Schema, model } = require('mongoose');
module.exports = model('Group', new Schema({
  name: { type: String, trim: true, required: true, maxlength: 60 },
  owner: { type: Schema.Types.ObjectId, ref: 'User' },
  members: [{ type: Schema.Types.ObjectId, ref: 'User' }],
}, { timestamps: true }));
