const { Schema, model } = require('mongoose');
module.exports = model('Call', new Schema({
  from: { type: Schema.Types.ObjectId, ref: 'User' }, to: { type: Schema.Types.ObjectId, ref: 'User' }, video: Boolean,
  status: { type: String, default: 'ringing' }, // ringing|answered|ended|missed|declined
  answeredAt: Date, endedAt: Date, duration: Number,
}, { timestamps: true }));
