const { Schema, model } = require('mongoose');
const ref = (r) => ({ type: Schema.Types.ObjectId, ref: r });
const schema = new Schema({
  from: ref('User'), to: ref('User'), group: ref('Group'), // direct message e `to`, group message e `group`
  text: { type: String, maxlength: 5000 }, file: String, type: { type: String, default: 'text' }, // text|image|audio|video|file
  replyTo: ref('Message'),
  reactions: [{ _id: false, user: ref('User'), emoji: String }],
  edited: Boolean, deleted: Boolean, deliveredAt: Date, readAt: Date,
}, { timestamps: true });
schema.index({ from: 1, to: 1, createdAt: -1 });
schema.index({ group: 1, createdAt: -1 });
module.exports = model('Message', schema);
