const { Schema, model } = require('mongoose');
const schema = new Schema({ by: { type: Schema.Types.ObjectId, ref: 'User' }, user: { type: Schema.Types.ObjectId, ref: 'User' } }, { timestamps: true });
schema.index({ by: 1, user: 1 }, { unique: true });
module.exports = model('Block', schema);
