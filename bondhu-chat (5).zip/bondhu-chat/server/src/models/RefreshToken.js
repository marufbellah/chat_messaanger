const { Schema, model } = require('mongoose');
// Raw token DB te thake na, sudhu hash. Expire hole MongoDB nijei muche dey (TTL index).
module.exports = model('RefreshToken', new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', index: true }, hash: { type: String, unique: true },
  expires: { type: Date, index: { expireAfterSeconds: 0 } },
}, { timestamps: true }));
