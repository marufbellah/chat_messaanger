const { Schema, model } = require('mongoose');
const schema = new Schema({
  name: { type: String, trim: true, required: true, maxlength: 60 },
  email: { type: String, unique: true, lowercase: true, trim: true, required: true },
  password: { type: String, required: true },
  avatar: String,
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  active: { type: Boolean, default: true },
  verified: { type: Boolean, default: false },
  lastSeen: Date,
}, { timestamps: true });
// password kokhono client ke pathano hoy na
schema.methods.toPublic = function toPublic() {
  const { _id, name, email, avatar, role, active, verified, lastSeen, createdAt } = this;
  return { _id, name, email, avatar, role, active, verified, lastSeen, createdAt };
};
module.exports = model('User', schema);
