const { Schema, model } = require('mongoose');
module.exports = model('Audit', new Schema({ admin: { type: Schema.Types.ObjectId, ref: 'User' }, action: String, target: String, meta: Object }, { timestamps: true }));
