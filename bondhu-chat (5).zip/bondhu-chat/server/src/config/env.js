// Ekhane shob environment variable ek jaygay validate kora hoy. Onno file process.env ke sorasori pore na.
require('dotenv').config();
const path = require('path');
const { z } = require('zod');

const bool = z.enum(['true', 'false']).default('false').transform((v) => v === 'true');
const opt = z.string().optional();

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().default(5000),
  MONGO_URI: z.string().default('mongodb://127.0.0.1:27017/bondhu'),
  CLIENT_URL: z.string().default('*'), // CORS origin (comma separated)
  APP_URL: z.string().default('http://localhost:5173'), // email er link e use hoy
  // auth
  JWT_SECRET: z.string().default('dev_secret'),
  ACCESS_TTL: z.string().default('15m'),
  REFRESH_TTL_DAYS: z.coerce.number().default(30),
  REQUIRE_VERIFIED: bool, // true hole email verify na korle login hobe na
  AUTH_RATE_MAX: z.coerce.number().default(30), // 15 minute e login/register limit
  ADMIN_EMAIL: z.string().default('admin@bondhu.com'),
  ADMIN_PASSWORD: z.string().default('admin123'),
  // file storage
  STORAGE: z.enum(['local', 's3']).default('local'),
  UPLOAD_DIR: z.string().default(path.join(__dirname, '../../uploads')),
  S3_BUCKET: opt, S3_REGION: z.string().default('us-east-1'), S3_ENDPOINT: opt, S3_PUBLIC_URL: opt, S3_ACCESS_KEY: opt, S3_SECRET_KEY: opt,
  // email
  SMTP_URL: opt, MAIL_FROM: z.string().default('Bondhu Chat <no-reply@bondhu.local>'),
  // calls
  MAX_GROUP_CALL: z.coerce.number().default(8), // mesh WebRTC er jonno 8 er beshi na
  TURN_URL: opt, TURN_SECRET: opt, TURN_USER: opt, TURN_PASS: opt,
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) { console.error('Invalid environment:', parsed.error.flatten().fieldErrors); process.exit(1); }
const env = { ...parsed.data, isProd: parsed.data.NODE_ENV === 'production', isTest: parsed.data.NODE_ENV === 'test' };
if (env.isProd && ['dev_secret', 'change_me'].includes(env.JWT_SECRET)) { console.error('Set a strong JWT_SECRET'); process.exit(1); }
if (env.STORAGE === 's3' && !env.S3_BUCKET) { console.error('S3_BUCKET required when STORAGE=s3'); process.exit(1); }
module.exports = env;
