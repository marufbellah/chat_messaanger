const { E } = require('../utils/httpError');
const { isId } = require('../utils/helpers');
// zod schema diye req.body check kore; thik na hole 400
exports.validate = (schema) => (req, res, next) => {
  const r = schema.safeParse(req.body ?? {});
  if (!r.success) return next(E(400, r.error.issues[0]?.message || 'Invalid data'));
  req.body = r.data; next();
};
// router.param('id', idParam) -- :id valid ObjectId kina check kore
exports.idParam = (req, res, next, v) => (isId(v) ? next() : res.status(400).json({ error: 'Invalid id' }));
