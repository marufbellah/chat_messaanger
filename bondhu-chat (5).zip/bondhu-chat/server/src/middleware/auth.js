const asyncHandler = require('../utils/asyncHandler');
const { E } = require('../utils/httpError');
const tokens = require('../services/token.service');
const { User } = require('../models');

// Bearer access token verify kore req.user set kore
exports.authenticate = asyncHandler(async (req, res, next) => {
  let id;
  try { id = tokens.verifyAccess((req.headers.authorization || '').replace('Bearer ', '')); } catch { throw E(401, 'Unauthorized'); }
  const user = await User.findById(id);
  if (!user || !user.active) throw E(401, 'Unauthorized or inactive');
  req.user = user; next();
});
exports.requireAdmin = (req, res, next) => (req.user.role === 'admin' ? next() : next(E(403, 'Admin only')));
