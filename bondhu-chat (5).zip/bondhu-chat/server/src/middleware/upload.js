const multer = require('multer');
const { E } = require('../utils/httpError');
// File memory te thake, tarpor storage service (local ba S3) e save hoy
const make = (re, mb) => multer({
  storage: multer.memoryStorage(), limits: { fileSize: mb * 1024 * 1024 },
  fileFilter: (req, f, cb) => (re.test(f.mimetype) ? cb(null, true) : cb(E(400, 'File type not allowed'))),
});
const MESSAGE_TYPES = /^(image\/(?!svg)|audio\/|video\/|application\/(pdf|zip|msword|vnd\.openxmlformats))/; // SVG block (script inject hote pare)
exports.messageFile = make(MESSAGE_TYPES, 25).single('file');
exports.avatarFile = make(/^image\/(?!svg)/, 3).single('file');
