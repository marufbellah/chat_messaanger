const logger = require('../utils/logger');
exports.notFound = (req, res) => res.status(404).json({ error: 'Not found' });
// Shob error ekhane ashe. HttpError/Multer/Mongo duplicate => client friendly message, baki => 500
exports.errorHandler = (err, req, res, next) => { // eslint-disable-line no-unused-vars
  let status = err.status, message = err.message;
  if (err.name === 'MulterError') status = 400;
  else if (err.code === 11000) { status = 409; message = 'Already exists'; }
  if (!status) { logger.error(err); status = 500; message = 'Server error'; }
  res.status(status).json({ error: message });
};
