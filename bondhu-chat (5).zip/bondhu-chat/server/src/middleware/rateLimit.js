const rateLimit = require('express-rate-limit');
const env = require('../config/env');
exports.apiLimiter = rateLimit({ windowMs: 60e3, max: 300 });
exports.authLimiter = rateLimit({ windowMs: 15 * 60e3, max: env.AUTH_RATE_MAX, message: { error: 'Too many attempts, try later' } });
