// Entry point: DB connect -> admin seed -> HTTP + Socket server chalu
const http = require('http'), mongoose = require('mongoose');
const env = require('./config/env'), logger = require('./utils/logger');
const { app, origin } = require('./app');

const server = http.createServer(app);
require('./sockets')(server, origin);

mongoose.connect(env.MONGO_URI).then(async () => {
  await require('./db/seed')();
  server.listen(env.PORT, () => logger.info('Server running on ' + env.PORT));
}).catch((e) => { logger.error('Startup failed:', e.message); process.exit(1); });

// graceful shutdown: connection gulo bhalo vabe bondho kore
['SIGINT', 'SIGTERM'].forEach((sig) => process.on(sig, () => { require('./realtime').close(); server.close(() => mongoose.disconnect().then(() => process.exit(0))); }));
