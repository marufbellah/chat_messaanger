class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
module.exports = { HttpError, E: (status, message) => new HttpError(status, message) };
