const mongoose = require('mongoose');
module.exports = {
  isId: (id) => mongoose.isValidObjectId(id),
  escapeRegex: (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'),
  uniq: (arr) => [...new Set(arr)],
};
