// async controller er error Express er error handler e pathay
module.exports = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
