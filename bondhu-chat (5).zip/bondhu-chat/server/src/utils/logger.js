const env = require('../config/env');
const log = (level) => (...a) => { if (!env.isTest || level === 'error') console[level === 'error' ? 'error' : 'log'](new Date().toISOString(), level.toUpperCase(), ...a); };
module.exports = { info: log('info'), warn: log('warn'), error: log('error') };
