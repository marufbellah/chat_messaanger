// Express app (server start kore na -- test e alada kore bebohar kora jay)
const express = require('express'), helmet = require('helmet'), cors = require('cors'), morgan = require('morgan');
const env = require('./config/env'), routes = require('./routes'), storage = require('./services/storage');
const { apiLimiter, authLimiter } = require('./middleware/rateLimit');
const { notFound, errorHandler } = require('./middleware/error');

const app = express();
const origin = env.CLIENT_URL === '*' ? '*' : env.CLIENT_URL.split(',');
app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }), cors({ origin }), express.json({ limit: '100kb' }));
if (!env.isTest) app.use(morgan(env.isProd ? 'combined' : 'dev'));
if (env.STORAGE === 'local') app.use('/uploads', express.static(storage.dir));
app.use('/api', apiLimiter);
app.use('/api/auth', authLimiter);
app.use('/api', routes);
app.use('/api', notFound);
app.use(errorHandler);
module.exports = { app, origin };
