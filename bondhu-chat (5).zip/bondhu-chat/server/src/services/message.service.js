const { Message, User, Group } = require('../models');
const rt = require('../realtime'), storage = require('./storage'), blocks = require('./block.service');
const { E } = require('../utils/httpError');
const { isId } = require('../utils/helpers');

const kindOf = (mime = '') => (mime.startsWith('image') ? 'image' : mime.startsWith('audio') ? 'audio' : mime.startsWith('video') ? 'video' : 'file');

// ---- send ----
async function create({ from, to, group, body, file }) {
  const text = (body.text || '').trim();
  if (!text && !file) throw E(400, 'Empty message');
  const url = file ? await storage.save(file) : undefined;
  const m = await Message.create({ from, to, group, text, file: url, type: file ? kindOf(file.mimetype) : 'text',
    replyTo: isId(body.replyTo) ? body.replyTo : undefined, deliveredAt: to && rt.isOnline(to) ? new Date() : undefined });
  group ? rt.toGroup(group, 'msg', m, from) : rt.toUser(to, 'msg', m);
  return m;
}
exports.sendDirect = async (user, body, file) => {
  const to = body.to;
  if (String(to) === String(user._id)) throw E(400, "Can't message yourself");
  if (!isId(to) || !(await User.exists({ _id: to, active: true }))) throw E(404, 'User not found');
  if (await blocks.isBlockedBetween(user._id, to)) throw E(403, "You can't message this user");
  return create({ from: user._id, to, body, file });
};
exports.sendGroup = (user, group, body, file) => create({ from: user._id, group: group._id, body, file });

// ---- read ----
// before (ISO date) diye pagination: purono message load korar jonno
exports.history = async (filter, { before, limit } = {}) => {
  const q = { ...filter }; if (before) q.createdAt = { $lt: new Date(before) };
  return (await Message.find(q).sort('-createdAt').limit(Math.min(+limit || 50, 100))).reverse();
};
exports.directFilter = (me, other) => ({ $or: [{ from: me, to: other }, { from: other, to: me }] });
exports.conversations = async (me) => {
  const last = await Message.aggregate([{ $match: { group: { $exists: false }, $or: [{ from: me }, { to: me }] } }, { $sort: { createdAt: -1 } },
    { $group: { _id: { $cond: [{ $eq: ['$from', me] }, '$to', '$from'] }, last: { $first: '$$ROOT' } } }]);
  const unread = await Message.aggregate([{ $match: { to: me, readAt: { $exists: false } } }, { $group: { _id: '$from', n: { $sum: 1 } } }]);
  return { last, unread };
};
exports.markRead = async (me, otherId) => {
  const now = new Date(), r = await Message.updateMany({ from: otherId, to: me, readAt: { $exists: false } }, { readAt: now, deliveredAt: now });
  rt.toUser(otherId, 'read', { by: String(me), at: now });
  return r.modifiedCount;
};

// ---- change ----
exports.softDelete = async (m) => {
  if (m.file) storage.remove(m.file);
  Object.assign(m, { deleted: true, text: '', file: undefined }); await m.save();
  rt.toMessageAudience(m, 'msg:delete', { _id: m._id });
};
exports.edit = async (user, id, body, file) => {
  const m = await Message.findOne({ _id: id, from: user._id, deleted: { $ne: true } });
  if (!m) throw E(404, 'Message not found');
  if (file) { storage.remove(m.file); m.file = await storage.save(file); m.type = kindOf(file.mimetype); } // photo replace
  else if (String(body.removeFile) === 'true' && m.file) { // photo remove (caption thakle)
    if (!m.text) throw E(400, 'Delete the message instead');
    storage.remove(m.file); m.file = undefined; m.type = 'text';
  }
  if (typeof body.text === 'string') {
    if (!body.text.trim() && !m.file) throw E(400, 'Empty message');
    m.text = body.text.trim();
  }
  m.edited = true; await m.save(); rt.toMessageAudience(m, 'msg:edit', m);
  return m;
};
exports.removeOwn = async (user, id) => {
  const m = await Message.findOne({ _id: id, from: user._id }); if (!m) throw E(404, 'Message not found');
  await exports.softDelete(m);
};
// user ei message dekhte pare kina (participant ba group member)
const canSee = async (m, uid) => String(m.from) === uid || String(m.to) === uid || (!!m.group && !!(await Group.exists({ _id: m.group, members: uid })));
const visible = async (id, uid) => { const m = await Message.findOne({ _id: id, deleted: { $ne: true } }); if (!m || !(await canSee(m, uid))) throw E(404, 'Message not found'); return m; };

exports.react = async (user, id, emoji) => {
  const me = String(user._id), m = await visible(id, me), i = m.reactions.findIndex((r) => String(r.user) === me);
  if (i >= 0 && m.reactions[i].emoji === emoji) m.reactions.splice(i, 1); // same emoji abar dile off
  else if (i >= 0) m.reactions[i].emoji = emoji; else m.reactions.push({ user: me, emoji });
  await m.save(); rt.toMessageAudience(m, 'msg:edit', m);
  return m;
};
exports.forward = async (user, id, { users = [], groups = [] }) => {
  const me = String(user._id), src = await visible(id, me), targets = [];
  for (const to of users.filter(isId)) if (to !== me && (await User.exists({ _id: to, active: true })) && !(await blocks.isBlockedBetween(me, to))) targets.push({ to });
  for (const group of groups.filter(isId)) if (await Group.exists({ _id: group, members: me })) targets.push({ group });
  for (const t of targets) {
    const file = src.file ? await storage.copy(src.file).catch(() => undefined) : undefined; // file COPY hoy, tai original delete hole o thake
    if (!src.text && !file) continue;
    const m = await Message.create({ from: me, ...t, text: src.text, file, type: file ? src.type : 'text', deliveredAt: t.to && rt.isOnline(t.to) ? new Date() : undefined });
    t.group ? rt.toGroup(t.group, 'msg', m, me) : rt.toUser(t.to, 'msg', m);
  }
  return targets.length;
};
// message + tar file gulo mushe fele (user/group delete er somoy)
exports.purge = async (filter) => {
  for (const m of await Message.find({ ...filter, file: { $exists: true } })) await storage.remove(m.file);
  await Message.deleteMany(filter);
};
