const nodemailer = require('nodemailer');
const env = require('../config/env');
const logger = require('../utils/logger');

// SMTP_URL (jemon smtps://user:pass@smtp.gmail.com) na thakle email sudhu console e print hoy -- development e shubidha
const transport = nodemailer.createTransport(env.SMTP_URL || { jsonTransport: true });
const outbox = []; // sudhu test e: kon email gelo dekhar jonno

async function send({ to, subject, text }) {
  await transport.sendMail({ from: env.MAIL_FROM, to, subject, text });
  if (!env.SMTP_URL) logger.info(`[mail:dev] to=${to} | ${subject}\n${text}`);
  if (env.isTest) outbox.push({ to, subject, text });
}
exports.outbox = outbox;
exports.sendReset = (user, token) => send({ to: user.email, subject: 'Reset your Bondhu password',
  text: `Hi ${user.name},\n\nSet a new password here (valid for 1 hour):\n${env.APP_URL}/?reset=${token}\n\nIf you did not ask for this, ignore this email.` });
exports.sendVerify = (user, token) => send({ to: user.email, subject: 'Verify your Bondhu email',
  text: `Hi ${user.name},\n\nConfirm your email (valid for 24 hours):\n${env.APP_URL}/?verify=${token}\n` });
