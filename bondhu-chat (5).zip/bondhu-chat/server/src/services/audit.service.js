const { Audit } = require('../models');
// admin ja kore tar record. Fail hole main kaj atkay na.
exports.record = (admin, action, target, meta) => Audit.create({ admin: admin._id, action, target: String(target), meta }).catch(() => {});
