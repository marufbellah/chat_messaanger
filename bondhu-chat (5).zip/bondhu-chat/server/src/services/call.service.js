const { Call } = require('../models');
// 1:1 call er log. `live` = ekhon cholche emon call (duijoner pair => Call id)
const live = new Map(), key = (a, b) => [a, b].sort().join(':');
exports.offer = (from, to, video) => Call.create({ from, to, video: !!video }).then((c) => live.set(key(from, to), c._id)).catch(() => {});
exports.missed = (from, to, video) => Call.create({ from, to, video: !!video, status: 'missed', endedAt: new Date() }).catch(() => {});
exports.answered = (a, b) => Call.findByIdAndUpdate(live.get(key(a, b)), { status: 'answered', answeredAt: new Date() }).catch(() => {});
exports.ended = async (endedBy, other) => {
  const k = key(endedBy, other), id = live.get(k); live.delete(k);
  const c = id && (await Call.findById(id)); if (!c) return;
  c.endedAt = new Date();
  if (c.answeredAt) { c.status = 'ended'; c.duration = Math.round((c.endedAt - c.answeredAt) / 1000); }
  else c.status = String(c.from) === endedBy ? 'missed' : 'declined';
  await c.save().catch(() => {});
};
exports.historyOf = (userId) => Call.find({ $or: [{ from: userId }, { to: userId }] }).sort('-createdAt').limit(50).populate('from to', 'name avatar');
