const bcrypt = require('bcryptjs');
const env = require('../config/env');
const { User } = require('../models');
const tokens = require('./token.service'), mail = require('./mail.service');
const { E } = require('../utils/httpError');
const logger = require('../utils/logger');

const hash = (p) => bcrypt.hash(p, 10);
const session = async (user) => ({ ...(await tokens.issueSession(user)), user: user.toPublic() });
const sendVerification = async (user) => mail.sendVerify(user, await tokens.createOneTime(user, 'verify', 24 * 3600e3));

exports.register = async ({ name, email, password }) => {
  const user = await User.create({ name, email, password: await hash(password) });
  sendVerification(user).catch((e) => logger.error('verify mail failed', e.message)); // email fail hole registration atkay na
  return session(user);
};
exports.login = async ({ email, password }) => {
  const user = await User.findOne({ email: String(email).toLowerCase() });
  if (!user || !(await bcrypt.compare(String(password), user.password))) throw E(400, 'Wrong email or password');
  if (!user.active) throw E(403, 'Account is inactive');
  if (env.REQUIRE_VERIFIED && !user.verified) throw E(403, 'Please verify your email first');
  return session(user);
};
exports.refresh = async (raw) => { const { user, token, refreshToken } = await tokens.rotate(raw); return { token, refreshToken, user: user.toPublic() }; };
exports.logout = (raw) => tokens.revoke(raw);
// Email ache kina ta bole na (user enumeration thekate)
exports.forgotPassword = async (email) => {
  const user = await User.findOne({ email: String(email).toLowerCase(), active: true });
  if (user) await mail.sendReset(user, await tokens.createOneTime(user, 'reset', 3600e3));
};
exports.resetPassword = async ({ token, password }) => {
  const user = await User.findById(await tokens.consumeOneTime(token, 'reset'));
  if (!user || !user.active) throw E(400, 'This link is invalid or has expired');
  user.password = await hash(password); user.verified = true; await user.save();
  await tokens.revokeAll(user._id); // shob device logout
  return session(user);
};
exports.verifyEmail = async (token) => {
  const user = await User.findById(await tokens.consumeOneTime(token, 'verify'));
  if (user) { user.verified = true; await user.save(); }
};
exports.resendVerification = async (user) => { if (!user.verified) await sendVerification(user); };
exports.changePassword = async (user, { current, password }) => {
  if (!(await bcrypt.compare(String(current), user.password))) throw E(400, 'Wrong current password');
  user.password = await hash(password); await user.save();
  await tokens.revokeAll(user._id);
  return session(user);
};
exports.hashPassword = hash;
