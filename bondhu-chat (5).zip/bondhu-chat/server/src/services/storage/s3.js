const { newName } = require('./names');
// AWS S3 ba S3-compatible (Cloudflare R2, MinIO, DigitalOcean Spaces). `client` inject kora jay (test er jonno).
module.exports = (env, injected) => {
  const sdk = require('@aws-sdk/client-s3');
  const client = injected || new sdk.S3Client({
    region: env.S3_REGION, endpoint: env.S3_ENDPOINT || undefined, forcePathStyle: !!env.S3_ENDPOINT,
    credentials: env.S3_ACCESS_KEY ? { accessKeyId: env.S3_ACCESS_KEY, secretAccessKey: env.S3_SECRET_KEY } : undefined,
  });
  const Bucket = env.S3_BUCKET;
  const base = (env.S3_PUBLIC_URL || `https://${Bucket}.s3.${env.S3_REGION}.amazonaws.com`).replace(/\/$/, '');
  const keyOf = (url) => url.slice(base.length + 1);
  return {
    async save(file) {
      const Key = newName(file.originalname);
      await client.send(new sdk.PutObjectCommand({ Bucket, Key, Body: file.buffer, ContentType: file.mimetype, CacheControl: 'public,max-age=31536000' }));
      return `${base}/${Key}`;
    },
    async remove(url) { if (url?.startsWith(base)) await client.send(new sdk.DeleteObjectCommand({ Bucket, Key: keyOf(url) })).catch(() => {}); },
    async copy(url) { const Key = newName(url); await client.send(new sdk.CopyObjectCommand({ Bucket, CopySource: `${Bucket}/${keyOf(url)}`, Key })); return `${base}/${Key}`; },
  };
};
