const path = require('path'), crypto = require('crypto');
// unique file name: 1699999999999-ab12cd.png
exports.newName = (original = '') => `${Date.now()}-${crypto.randomBytes(4).toString('hex')}${path.extname(original).toLowerCase().replace(/[^.a-z0-9]/g, '')}`;
