const env = require('../../config/env');
// STORAGE=local | s3 -- baki code ei interface (save/remove/copy) ei use kore, driver kon ta jane na
module.exports = env.STORAGE === 's3' ? require('./s3')(env) : require('./local')(env.UPLOAD_DIR);
