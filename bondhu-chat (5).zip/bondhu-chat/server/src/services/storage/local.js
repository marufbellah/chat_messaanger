const fs = require('fs'), path = require('path');
const { newName } = require('./names');
// Server er disk e save kore; URL hoy /uploads/<name>
module.exports = (dir) => {
  fs.mkdirSync(dir, { recursive: true });
  const fileOf = (url) => path.join(dir, path.basename(url));
  return {
    dir,
    async save(file) { const name = newName(file.originalname); await fs.promises.writeFile(path.join(dir, name), file.buffer); return '/uploads/' + name; },
    async remove(url) { if (url) await fs.promises.unlink(fileOf(url)).catch(() => {}); },
    async copy(url) { const name = newName(url); await fs.promises.copyFile(fileOf(url), path.join(dir, name)); return '/uploads/' + name; },
  };
};
