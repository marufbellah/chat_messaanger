// Access token (JWT, kom somoyer) + Refresh token (DB te hash kore rakha, rotate hoy) + ek-bar-bebohar token (reset/verify)
const jwt = require('jsonwebtoken'), crypto = require('crypto');
const env = require('../config/env');
const { RefreshToken, AuthToken, User } = require('../models');
const { E } = require('../utils/httpError');

const sha = (s) => crypto.createHash('sha256').update(String(s || '')).digest('hex');
const random = () => crypto.randomBytes(32).toString('base64url');

exports.signAccess = (user) => jwt.sign({ id: user._id }, env.JWT_SECRET, { expiresIn: env.ACCESS_TTL });
exports.verifyAccess = (token) => jwt.verify(token, env.JWT_SECRET).id;

exports.issueSession = async (user) => {
  const raw = random();
  await RefreshToken.create({ user: user._id, hash: sha(raw), expires: new Date(Date.now() + env.REFRESH_TTL_DAYS * 864e5) });
  return { token: exports.signAccess(user), refreshToken: raw };
};
// Refresh token ekbar-i cholbe (rotation): purono ta muche notun dey. Churi hoye gele attacker er ta o ekbar-i kaj korbe.
exports.rotate = async (raw) => {
  const doc = await RefreshToken.findOneAndDelete({ hash: sha(raw), expires: { $gt: new Date() } });
  if (!doc) throw E(401, 'Invalid refresh token');
  const user = await User.findById(doc.user);
  if (!user || !user.active) throw E(401, 'Account unavailable');
  return { user, ...(await exports.issueSession(user)) };
};
exports.revoke = (raw) => RefreshToken.deleteOne({ hash: sha(raw) });
exports.revokeAll = (userId) => RefreshToken.deleteMany({ user: userId });

exports.createOneTime = async (user, type, ttlMs) => {
  await AuthToken.deleteMany({ user: user._id, type });
  const raw = random();
  await AuthToken.create({ user: user._id, type, hash: sha(raw), expires: new Date(Date.now() + ttlMs) });
  return raw;
};
exports.consumeOneTime = async (raw, type) => {
  const doc = await AuthToken.findOneAndDelete({ hash: sha(raw), type, expires: { $gt: new Date() } });
  if (!doc) throw E(400, 'This link is invalid or has expired');
  return doc.user;
};
