const { Block, User } = require('../models');
const { E } = require('../utils/httpError');
const { isId } = require('../utils/helpers');
exports.isBlockedBetween = (a, b) => Block.exists({ $or: [{ by: a, user: b }, { by: b, user: a }] }).then(Boolean);
exports.listIds = async (by) => (await Block.find({ by })).map((b) => String(b.user));
exports.block = async (by, userId) => {
  if (String(by._id) === String(userId)) throw E(400, "You can't block yourself");
  if (!isId(userId) || !(await User.exists({ _id: userId }))) throw E(404, 'User not found');
  await Block.updateOne({ by: by._id, user: userId }, { by: by._id, user: userId }, { upsert: true });
};
exports.unblock = (by, userId) => Block.deleteOne({ by: by._id, user: userId });
