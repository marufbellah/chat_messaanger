const { User, Group, Message, Call, Block } = require('../models');
const rt = require('../realtime'), tokens = require('./token.service'), messages = require('./message.service'), auth = require('./auth.service');
const { E } = require('../utils/httpError');
const { escapeRegex } = require('../utils/helpers');

exports.stats = async () => {
  const day = new Date(); day.setHours(0, 0, 0, 0);
  const [total, active, admins, msgs, today, groups, calls] = await Promise.all([User.countDocuments(), User.countDocuments({ active: true }), User.countDocuments({ role: 'admin' }),
    Message.countDocuments(), Message.countDocuments({ createdAt: { $gte: day } }), Group.countDocuments(), Call.countDocuments()]);
  return { users: { total, active, inactive: total - active, admins }, online: rt.online().length, messages: { total: msgs, today }, groups, calls };
};
exports.listUsers = async (q) => {
  const filter = q ? { $or: ['name', 'email'].map((k) => ({ [k]: new RegExp(escapeRegex(String(q)), 'i') })) } : {};
  return (await User.find(filter).sort('-createdAt').limit(500)).map((u) => u.toPublic());
};
exports.createUser = async ({ name, email, password, role, active }) =>
  (await User.create({ name, email, role, active, verified: true, password: await auth.hashPassword(password || '123456') })).toPublic();
exports.updateUser = async (admin, id, body) => {
  if (String(admin._id) === id && (body.role === 'user' || body.active === false)) throw E(400, "You can't demote or deactivate yourself");
  const up = { ...body }; delete up.password;
  if (body.password) up.password = await auth.hashPassword(body.password);
  const user = await User.findByIdAndUpdate(id, up, { new: true, runValidators: true });
  if (!user) throw E(404, 'User not found');
  if (!user.active || body.password) await tokens.revokeAll(user._id); // inactive ba password reset hole shob session shesh
  if (!user.active) rt.kick(user._id);
  return { user: user.toPublic(), changes: { ...up, password: up.password ? '***' : undefined } };
};
exports.deleteUser = async (admin, id) => {
  if (String(admin._id) === id) throw E(400, "You can't delete yourself");
  const user = await User.findByIdAndDelete(id); if (!user) throw E(404, 'User not found');
  for (const g of await Group.find({ owner: id })) { await messages.purge({ group: g._id }); rt.leaveGroup(g.members, g._id); await g.deleteOne(); }
  await Group.updateMany({ members: id }, { $pull: { members: id } });
  await messages.purge({ $or: [{ from: id }, { to: id }] });
  await Promise.all([tokens.revokeAll(id), Block.deleteMany({ $or: [{ by: id }, { user: id }] })]);
  rt.kick(id);
  return user;
};
