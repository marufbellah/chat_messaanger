const { Group, User } = require('../models');
const rt = require('../realtime');
const messages = require('./message.service');
const { E } = require('../utils/httpError');
const { isId, uniq } = require('../utils/helpers');

// Group ta ei user er member hole return kore, noile 404
exports.getForMember = async (id, userId) => (await Group.findOne({ _id: id, members: userId })) || (() => { throw E(404, 'Group not found'); })();
const activeIds = async (ids) => (await User.find({ _id: { $in: (ids || []).filter(isId) }, active: true }).select('_id')).map((u) => String(u._id));
exports.listFor = (userId) => Group.find({ members: userId }).populate('members', 'name avatar').sort('-updatedAt');
exports.create = async (user, { name, members }) => {
  const ids = uniq([String(user._id), ...(await activeIds(members))]);
  const g = await Group.create({ name, owner: user._id, members: ids });
  rt.joinGroup(ids, g._id); ids.forEach((u) => rt.toUser(u, 'group:update', g));
  return g;
};
exports.update = async (user, g, { name, add, remove }) => {
  if (String(g.owner) !== String(user._id)) throw E(403, 'Only the owner can edit');
  if (name) g.name = name;
  const added = await activeIds(add), removed = (remove || []).filter((x) => isId(x) && String(x) !== String(g.owner));
  g.members = uniq([...g.members.map(String).filter((x) => !removed.includes(x)), ...added]);
  await g.save(); rt.joinGroup(added, g._id); rt.leaveGroup(removed, g._id);
  [...g.members, ...removed].forEach((u) => rt.toUser(u, 'group:update', g));
  return g;
};
exports.leave = async (user, g) => {
  if (String(g.owner) === String(user._id)) throw E(400, 'Owner must delete the group');
  g.members.pull(user._id); await g.save(); rt.leaveGroup([user._id], g._id);
};
exports.remove = async (user, g) => {
  if (String(g.owner) !== String(user._id) && user.role !== 'admin') throw E(403, 'Only the owner can delete');
  await messages.purge({ group: g._id }); await g.deleteOne(); rt.leaveGroup(g.members, g._id);
};
