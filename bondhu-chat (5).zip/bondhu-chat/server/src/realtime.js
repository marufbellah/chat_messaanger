// Socket.IO ke service/controller theke bebohar korar jonno ekta choto wrapper.
// Room niyom: user room = userId, group room = 'g:' + groupId
const { Server } = require('socket.io');
let io;
const rt = {
  init(server, origin) { io = new Server(server, { cors: { origin } }); return io; },
  close() { io?.close(); },
  online: () => [...io.sockets.adapter.rooms.keys()].filter((k) => /^[a-f0-9]{24}$/.test(k)),
  isOnline: (id) => io.sockets.adapter.rooms.has(String(id)),
  toUser: (id, ev, data) => io.to(String(id)).emit(ev, data),
  toGroup(gid, ev, data, exceptUser) { let r = io.to('g:' + gid); if (exceptUser) r = r.except(String(exceptUser)); r.emit(ev, data); },
  // message jar kache jabe: direct hole receiver + sender (onno tab), group hole group room
  toMessageAudience(m, ev, data) { (m.group ? io.to('g:' + m.group) : io.to(String(m.to))).to(String(m.from)).emit(ev, data); },
  joinGroup: (userIds, gid) => userIds.forEach((u) => io.in(String(u)).socketsJoin('g:' + gid)),
  leaveGroup: (userIds, gid) => userIds.forEach((u) => io.in(String(u)).socketsLeave('g:' + gid)),
  kick: (id) => io.in(String(id)).disconnectSockets(true),
};
module.exports = rt;
