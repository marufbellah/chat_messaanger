const { User } = require('../models');
const auth = require('../services/auth.service');
const env = require('../config/env');
// prothom bar chalale ekta admin account toiri kore
module.exports = async () => {
  const email = env.ADMIN_EMAIL.toLowerCase();
  if (!(await User.exists({ email }))) await User.create({ name: 'Admin', email, role: 'admin', verified: true, password: await auth.hashPassword(env.ADMIN_PASSWORD) });
};
