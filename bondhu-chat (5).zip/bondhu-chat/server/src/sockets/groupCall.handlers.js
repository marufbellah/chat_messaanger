// Group call (mesh WebRTC): proti participant baki shobar sathe direct connection kore.
// Server sudhu "ke ke call e ache" mone rakhe ar signaling relay kore. MAX_GROUP_CALL er beshi hole 'gcall:full'.
const rt = require('../realtime'), env = require('../config/env');
const { isId } = require('../utils/helpers');
const calls = new Map(); // groupId -> { video, set: Set(userId) }  (server er memory; restart hole reset)

module.exports = (socket) => {
  const me = socket.uid, room = (g) => 'g:' + g;
  const announce = (g, c, extra) => rt.toGroup(g, 'gcall:active', { group: g, participants: [...c.set], video: c.video, ...extra });
  const leave = (g) => {
    const c = calls.get(g); if (!c || !c.set.delete(me)) return;
    rt.toGroup(g, 'gcall:left', { group: g, from: me });
    if (!c.set.size) calls.delete(g);
    announce(g, c);
  };
  socket.on('gcall:join', (d) => {
    const g = d?.group; if (!isId(g) || !socket.rooms.has(room(g))) return; // group member na hole ignore
    const c = calls.get(g) || { video: !!d.video, set: new Set() };
    if (!c.set.has(me) && c.set.size >= env.MAX_GROUP_CALL) return socket.emit('gcall:full', { group: g, max: env.MAX_GROUP_CALL });
    calls.set(g, c);
    const peers = [...c.set].filter((x) => x !== me); c.set.add(me);
    socket.emit('gcall:peers', { group: g, peers }); // notun-ashha user ei peers der offer pathabe
    announce(g, c, { starter: peers.length ? undefined : me });
  });
  socket.on('gcall:signal', (d) => { const c = calls.get(d?.group); if (c?.set.has(me) && c.set.has(d.to)) rt.toUser(d.to, 'gcall:signal', { from: me, group: d.group, data: d.data }); });
  socket.on('gcall:leave', (d) => leave(d?.group));
  socket.on('disconnect', () => { if (!rt.isOnline(me)) for (const g of [...calls.keys()]) leave(g); });
};
