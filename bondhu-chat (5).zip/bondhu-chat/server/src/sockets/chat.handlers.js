const rt = require('../realtime');
const { isId } = require('../utils/helpers');
// "type korche" indicator
module.exports = (socket) => {
  socket.on('typing', (d) => {
    if (d?.group && socket.rooms.has('g:' + d.group)) rt.toGroup(d.group, 'typing', { from: socket.uid, group: d.group }, socket.uid);
    else if (isId(d?.to)) rt.toUser(d.to, 'typing', { from: socket.uid });
  });
};
