// 1:1 audio/video call er signaling (offer/answer/ice). Media server er upor diye jay na -- browser to browser (WebRTC)
const rt = require('../realtime'), calls = require('../services/call.service'), blocks = require('../services/block.service');
const { isId } = require('../utils/helpers');

module.exports = (socket) => {
  const me = socket.uid;
  const relay = (ev, d) => rt.toUser(d.to, ev, { ...d, from: me });
  socket.on('call:offer', async (d) => {
    if (!isId(d?.to) || d.to === me) return;
    if (!rt.isOnline(d.to) || (await blocks.isBlockedBetween(me, d.to))) { // offline ba block: missed
      calls.missed(me, d.to, d.video); return socket.emit('call:end', { from: d.to });
    }
    relay('call:offer', d); calls.offer(me, d.to, d.video);
  });
  socket.on('call:answer', (d) => { if (!isId(d?.to)) return; relay('call:answer', d); calls.answered(me, d.to); });
  socket.on('call:ice', (d) => isId(d?.to) && relay('call:ice', d));
  socket.on('call:end', (d) => { if (!isId(d?.to)) return; relay('call:end', d); calls.ended(me, d.to); });
};
