// Real-time layer: login check + kon event kon file handle kore
const rt = require('../realtime'), tokens = require('../services/token.service');
const { User } = require('../models');

module.exports = (server, origin) => {
  const io = rt.init(server, origin);
  // Socket connect er age access token check
  io.use(async (socket, next) => {
    try {
      const id = tokens.verifyAccess(socket.handshake.auth?.token);
      const user = await User.findById(id);
      if (!user || !user.active) throw new Error('inactive');
      socket.uid = String(id); next();
    } catch { next(new Error('unauthorized')); }
  });
  io.on('connection', (socket) => {
    require('./presence.handlers')(io, socket);
    require('./chat.handlers')(socket);
    require('./call.handlers')(socket);
    require('./groupCall.handlers')(socket);
  });
  return io;
};
