const rt = require('../realtime');
const { Group, Message, User } = require('../models');
// connect: nijer room + group room e dhuke, online list shobaike janiye dey. disconnect: lastSeen save.
module.exports = (io, socket) => {
  socket.join(socket.uid);
  Group.find({ members: socket.uid }).select('_id').then((gs) => socket.join(gs.map((g) => 'g:' + g._id)));
  Message.updateMany({ to: socket.uid, deliveredAt: { $exists: false } }, { deliveredAt: new Date() }).catch(() => {});
  io.emit('presence', rt.online());
  socket.on('disconnect', async () => {
    if (!rt.isOnline(socket.uid)) await User.findByIdAndUpdate(socket.uid, { lastSeen: new Date() }).catch(() => {}); // onno tab ache kina
    io.emit('presence', rt.online());
  });
};
