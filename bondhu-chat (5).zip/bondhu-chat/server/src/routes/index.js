// Shob API route ek jaygay: kon URL kon controller e jay ta ekhane dekha jay
const router = require('express').Router();
const env = require('../config/env');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { validate, idParam } = require('../middleware/validate');
const { messageFile, avatarFile } = require('../middleware/upload');
const s = require('../validators/schemas');
const C = { auth: require('../controllers/auth.controller'), me: require('../controllers/me.controller'), users: require('../controllers/users.controller'),
  msg: require('../controllers/messages.controller'), grp: require('../controllers/groups.controller'), misc: require('../controllers/misc.controller'), admin: require('../controllers/admin.controller') };

router.param('id', idParam);
router.get('/health', C.misc.health);

// auth (public)
router.post('/auth/register', validate(s.register), C.auth.register);
router.post('/auth/login', validate(s.login), C.auth.login);
router.post('/auth/refresh', validate(s.refresh), C.auth.refresh);
router.post('/auth/logout', C.auth.logout);
router.post('/auth/forgot', validate(s.forgot), C.auth.forgot);
router.post('/auth/reset', validate(s.reset), C.auth.reset);
router.post('/auth/verify', validate(s.verify), C.auth.verify);

// ekhon theke login lagbe
router.use(authenticate);
router.post('/auth/verify/resend', C.auth.resendVerify);
router.get('/me', C.me.get);
router.put('/me', validate(s.updateMe), C.me.update);
router.put('/me/password', validate(s.changePassword), C.me.changePassword);
router.post('/me/avatar', avatarFile, C.me.avatar);
router.get('/ice', C.misc.ice);
router.get('/calls', C.misc.calls);

router.get('/users', C.users.list);
router.get('/blocks', C.users.blocked);
router.post('/blocks/:id', C.users.block);
router.delete('/blocks/:id', C.users.unblock);

router.get('/conversations', C.msg.conversations);
router.get('/messages/:id', C.msg.history);
router.post('/messages', messageFile, C.msg.send);
router.post('/messages/read/:id', C.msg.markRead);
router.put('/messages/:id', messageFile, C.msg.edit);
router.delete('/messages/:id', C.msg.remove);
router.post('/messages/:id/react', validate(s.react), C.msg.react);
router.post('/messages/:id/forward', validate(s.forward), C.msg.forward);

router.post('/groups', validate(s.groupCreate), C.grp.create);
router.get('/groups', C.grp.list);
router.put('/groups/:id', validate(s.groupUpdate), C.grp.update);
router.post('/groups/:id/leave', C.grp.leave);
router.delete('/groups/:id', C.grp.remove);
router.get('/groups/:id/messages', C.grp.history);
router.post('/groups/:id/messages', messageFile, C.grp.send);

// admin
router.use('/admin', requireAdmin);
router.get('/admin/stats', C.admin.stats);
router.get('/admin/users', C.admin.listUsers);
router.post('/admin/users', validate(s.adminCreate), C.admin.createUser);
router.put('/admin/users/:id', validate(s.adminUpdate), C.admin.updateUser);
router.delete('/admin/users/:id', C.admin.deleteUser);
router.delete('/admin/messages/:id', C.admin.deleteMessage);
router.get('/admin/logs', C.admin.logs);

if (env.isTest) router.get('/__test/outbox', (req, res) => res.json(require('../services/mail.service').outbox)); // sudhu test e
module.exports = router;
