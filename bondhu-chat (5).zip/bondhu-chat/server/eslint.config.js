const js = require('@eslint/js');
const globals = require('globals');
module.exports = [
  js.configs.recommended,
  { files: ['src/**/*.js', 'test/**/*.js', 'eslint.config.js'], languageOptions: { sourceType: 'commonjs', ecmaVersion: 2022, globals: { ...globals.node } },
    rules: { 'no-unused-vars': ['warn', { argsIgnorePattern: '^_', caughtErrors: 'none' }], 'no-empty': ['error', { allowEmptyCatch: true }] } },
];
