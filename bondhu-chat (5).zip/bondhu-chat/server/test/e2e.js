// End-to-end test: spawns the server on a fresh DB and exercises every API + socket feature.
// Run: MongoDB chalu rakhun, tarpor `npm test`
const { spawn } = require('child_process'), { io } = require('socket.io-client'), assert = require('assert');
const PORT = 5055, BASE = `http://localhost:${PORT}`, DB = 'bondhu_test_' + Date.now();
const env = { ...process.env, PORT, MONGO_URI: (process.env.MONGO_URI_BASE || 'mongodb://127.0.0.1:27017/') + DB, ADMIN_EMAIL: 'admin@t.com', ADMIN_PASSWORD: 'admin123', JWT_SECRET: 'test_secret', NODE_ENV: 'test', MAX_GROUP_CALL: '2', AUTH_RATE_MAX: '80' };
let pass = 0, fail = 0; const fails = [];
const test = async (name, fn) => { try { await fn(); pass++; console.log('  ✓', name); } catch (e) { fail++; fails.push(name); console.log('  ✗', name, '\n     ', e.message); } };
const api = async (method, url, { token, body, form } = {}) => {
  const h = {}; if (token) h.Authorization = 'Bearer ' + token; if (body) h['Content-Type'] = 'application/json';
  const r = await fetch(BASE + '/api' + url, { method, headers: h, body: form || (body && JSON.stringify(body)) });
  return { s: r.status, d: await r.json().catch(() => ({})) };
};
const png = () => new Blob([Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64')], { type: 'image/png' });
const fd = (o, file, name = 'a.png', blob = png()) => { const f = new FormData(); Object.entries(o).forEach(([k, v]) => f.append(k, v)); if (file !== false) f.append('file', blob, name); return f; };
const sock = token => new Promise((res, rej) => {
  const s = io(BASE, { auth: { token }, transports: ['websocket'], reconnection: false }); s.log = [];
  s.onAny((ev, d) => s.log.push([ev, d]));
  s.waitFor = (ev, pred = () => true, ms = 3000) => new Promise((ok, no) => { const t0 = Date.now(), iv = setInterval(() => { const h = s.log.find(([e, d]) => e === ev && pred(d)); if (h) { clearInterval(iv); ok(h[1]); } else if (Date.now() - t0 > ms) { clearInterval(iv); no(new Error('timeout waiting for ' + ev)); } }, 20); });
  s.on('connect', () => res(s)); s.on('connect_error', rej);
});
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const srv = spawn('node', ['src/server.js'], { env, cwd: __dirname + '/..' }); let out = ''; srv.stdout.on('data', d => out += d); srv.stderr.on('data', d => out += d);
  for (let i = 0; i < 60; i++) { try { if ((await fetch(BASE + '/api/health')).ok) break; } catch {} await sleep(250); }
  const T = {}; let ga; // group id
  console.log('\nHealth & Auth');
  await test('health endpoint + db connected', async () => { const r = await api('GET', '/health'); assert(r.s === 200 && r.d.db === true); });
  await test('register rejects bad input', async () => { assert.equal((await api('POST', '/auth/register', { body: { name: '', email: 'x', password: '1' } })).s, 400); });
  for (const n of ['alice', 'bob', 'carol']) await test('register ' + n, async () => { const r = await api('POST', '/auth/register', { body: { name: n, email: n + '@t.com', password: 'secret1' } }); assert.equal(r.s, 200); T[n] = r.d.token; T[n + 'Id'] = r.d.user._id; assert.equal(r.d.user.role, 'user'); assert(!r.d.user.password); });
  await test('duplicate email -> 409', async () => assert.equal((await api('POST', '/auth/register', { body: { name: 'a', email: 'ALICE@t.com', password: 'secret1' } })).s, 409));
  await test('login ok / wrong password -> 400', async () => { assert.equal((await api('POST', '/auth/login', { body: { email: 'alice@t.com', password: 'secret1' } })).s, 200); assert.equal((await api('POST', '/auth/login', { body: { email: 'alice@t.com', password: 'nope' } })).s, 400); });
  await test('admin seeded and can login', async () => { const r = await api('POST', '/auth/login', { body: { email: 'admin@t.com', password: 'admin123' } }); assert.equal(r.d.user.role, 'admin'); T.admin = r.d.token; T.adminId = r.d.user._id; });
  await test('protected route without/with bad token -> 401', async () => { assert.equal((await api('GET', '/me')).s, 401); assert.equal((await api('GET', '/me', { token: 'junk' })).s, 401); });

  console.log('\nProfile');
  await test('GET/PUT /me', async () => { assert.equal((await api('GET', '/me', { token: T.alice })).d.email, 'alice@t.com'); assert.equal((await api('PUT', '/me', { token: T.alice, body: { name: 'Alice W' } })).d.name, 'Alice W'); });
  await test('change password (wrong current rejected, then ok)', async () => {
    assert.equal((await api('PUT', '/me/password', { token: T.alice, body: { current: 'bad', password: 'newpass1' } })).s, 400);
    assert.equal((await api('PUT', '/me/password', { token: T.alice, body: { current: 'secret1', password: 'newpass1' } })).s, 200);
    assert.equal((await api('POST', '/auth/login', { body: { email: 'alice@t.com', password: 'newpass1' } })).s, 200); });
  await test('avatar upload ok, svg rejected', async () => { const r = await api('POST', '/me/avatar', { token: T.alice, form: fd({}, true) }); assert.equal(r.s, 200); assert(r.d.avatar.startsWith('/uploads/')); assert.equal((await fetch(BASE + r.d.avatar)).status, 200);
    assert.equal((await api('POST', '/me/avatar', { token: T.alice, form: fd({}, true, 'x.svg', new Blob(['<svg/>'], { type: 'image/svg+xml' })) })).s, 400); });

  console.log('\nAdmin');
  await test('normal user blocked from admin routes (403)', async () => assert.equal((await api('GET', '/admin/users', { token: T.alice })).s, 403));
  await test('admin create user', async () => { const r = await api('POST', '/admin/users', { token: T.admin, body: { name: 'Dave', email: 'dave@t.com', password: 'secret1', role: 'user', active: true } }); assert.equal(r.s, 200); T.daveId = r.d._id; });
  await test('admin list + search', async () => { const a = await api('GET', '/admin/users', { token: T.admin }); assert(a.d.length >= 5); const q = await api('GET', '/admin/users?q=dav', { token: T.admin }); assert.equal(q.d.length, 1); });
  await test('admin update user (rename, role)', async () => { const r = await api('PUT', '/admin/users/' + T.daveId, { token: T.admin, body: { name: 'David', role: 'admin' } }); assert(r.d.name === 'David' && r.d.role === 'admin'); await api('PUT', '/admin/users/' + T.daveId, { token: T.admin, body: { role: 'user' } }); });
  await test('admin cannot demote/deactivate/delete self', async () => { for (const [m, b] of [['PUT', { role: 'user' }], ['PUT', { active: false }], ['DELETE']]) assert.equal((await api(m, '/admin/users/' + T.adminId, { token: T.admin, body: b })).s, 400); });
  await test('invalid id -> 400, unknown api -> 404', async () => { assert.equal((await api('PUT', '/admin/users/xyz', { token: T.admin, body: {} })).s, 400); assert.equal((await api('GET', '/nothing', { token: T.admin })).s, 404); });

  console.log('\nDirect chat (REST + realtime)');
  const sa = await sock(T.alice), sb = await sock(T.bob);
  await test('presence shows both online', async () => { const r = await api('GET', '/users', { token: T.alice }); assert(r.d.online.includes(T.bobId)); assert(!r.d.users.find(u => u._id === T.aliceId)); });
  let m1;
  await test('send text -> bob receives via socket', async () => { const r = await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId, text: 'hello bob' }, false) }); assert.equal(r.s, 200); m1 = r.d; assert(m1.deliveredAt); const got = await sb.waitFor('msg', d => d._id === m1._id); assert.equal(got.text, 'hello bob'); });
  await test('cannot message self / unknown user / empty', async () => { assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.aliceId, text: 'x' }, false) })).s, 400); assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: '5f0000000000000000000000', text: 'x' }, false) })).s, 404); assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, false) })).s, 400); });
  await test('send image + audio + disallowed exe', async () => {
    const i = await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, true) }); assert.equal(i.d.type, 'image'); assert.equal((await fetch(BASE + i.d.file)).status, 200);
    const a = await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, true, 'v.webm', new Blob(['x'], { type: 'audio/webm' })) }); assert.equal(a.d.type, 'audio');
    assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, true, 'x.exe', new Blob(['MZ'], { type: 'application/x-msdownload' })) })).s, 400); });
  await test('oversize file (>25MB) rejected', async () => assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, true, 'big.mp4', new Blob([Buffer.alloc(26 * 1024 * 1024)], { type: 'video/mp4' })) })).s, 400));
  await test('history + pagination', async () => { const all = (await api('GET', '/messages/' + T.bobId, { token: T.alice })).d; assert.equal(all.length, 3); assert.equal(all[0]._id, m1._id); const p = (await api('GET', `/messages/${T.bobId}?limit=1`, { token: T.alice })).d; assert.equal(p.length, 1); const b = (await api('GET', `/messages/${T.bobId}?before=${all[2].createdAt}`, { token: T.alice })).d; assert.equal(b.length, 2); });
  await test('conversations: last message + unread for bob', async () => { const r = (await api('GET', '/conversations', { token: T.bob })).d; assert.equal(r.unread.find(u => u._id === T.aliceId).n, 3); assert.equal(r.last.length, 1); });
  await test('mark read -> alice gets read event, unread cleared', async () => { await api('POST', '/messages/read/' + T.aliceId, { token: T.bob }); await sa.waitFor('read', d => d.by === T.bobId); assert.equal((await api('GET', '/conversations', { token: T.bob })).d.unread.length, 0); });
  await test('typing indicator', async () => { sa.emit('typing', { to: T.bobId }); await sb.waitFor('typing', d => d.from === T.aliceId); });
  await test('edit own message (bob sees msg:edit); cannot edit others', async () => { const r = await api('PUT', '/messages/' + m1._id, { token: T.alice, body: { text: 'hello edited' } }); assert(r.d.edited); await sb.waitFor('msg:edit', d => d.text === 'hello edited'); assert.equal((await api('PUT', '/messages/' + m1._id, { token: T.bob, body: { text: 'hack' } })).s, 404); });
  await test('delete own message (soft, bob notified); cannot delete others', async () => { assert.equal((await api('DELETE', '/messages/' + m1._id, { token: T.bob })).s, 404); assert.equal((await api('DELETE', '/messages/' + m1._id, { token: T.alice })).s, 200); await sb.waitFor('msg:delete', d => d._id === m1._id); const h = (await api('GET', '/messages/' + T.bobId, { token: T.alice })).d; assert(h.find(m => m._id === m1._id).deleted); });
  await test('offline user: message marked delivered on connect', async () => { const r = await api('POST', '/messages', { token: T.alice, form: fd({ to: T.carolId, text: 'hi carol' }, false) }); assert(!r.d.deliveredAt); const sc = await sock(T.carol); await sleep(300); const h = (await api('GET', '/messages/' + T.aliceId, { token: T.carol })).d; assert(h[0].deliveredAt); sc.close(); });

  console.log('\nGroups');
  await test('create group (alice + bob; unknown member ignored)', async () => { const r = await api('POST', '/groups', { token: T.alice, body: { name: 'Team', members: [T.bobId, 'bad', '5f0000000000000000000000'] } }); assert.equal(r.s, 200); assert.equal(r.d.members.length, 2); ga = r.d._id; await sb.waitFor('group:update'); });
  await test('list groups (member only)', async () => { assert.equal((await api('GET', '/groups', { token: T.bob })).d.length, 1); assert.equal((await api('GET', '/groups', { token: T.carol })).d.length, 0); });
  await test('group message -> bob receives, alice (sender) does not echo, carol blocked', async () => {
    const r = await api('POST', `/groups/${ga}/messages`, { token: T.alice, form: fd({ text: 'team hello' }, false) }); assert.equal(r.s, 200); const g = await sb.waitFor('msg', d => d.group === ga); assert.equal(g.text, 'team hello');
    await sleep(150); assert(!sa.log.find(([e, d]) => e === 'msg' && d.group === ga));
    assert.equal((await api('GET', `/groups/${ga}/messages`, { token: T.carol })).s, 404); assert.equal((await api('POST', `/groups/${ga}/messages`, { token: T.carol, form: fd({ text: 'x' }, false) })).s, 404); assert.equal((await api('GET', `/groups/${ga}/messages`, { token: T.bob })).d.length, 1); });
  await test('group file message + typing', async () => { assert.equal((await api('POST', `/groups/${ga}/messages`, { token: T.bob, form: fd({}, true) })).d.type, 'image'); sb.emit('typing', { group: ga }); await sa.waitFor('typing', d => d.group === ga); });
  await test('owner adds carol live; carol receives; non-owner cannot edit', async () => { const sc = await sock(T.carol); assert.equal((await api('PUT', '/groups/' + ga, { token: T.bob, body: { name: 'x' } })).s, 403); const r = await api('PUT', '/groups/' + ga, { token: T.alice, body: { add: [T.carolId], name: 'Team A' } }); assert.equal(r.d.members.length, 3); await api('POST', `/groups/${ga}/messages`, { token: T.alice, form: fd({ text: 'welcome' }, false) }); await sc.waitFor('msg', d => d.group === ga && d.text === 'welcome'); sc.close(); });
  await test('remove member: bob stops receiving', async () => { await api('PUT', '/groups/' + ga, { token: T.alice, body: { remove: [T.bobId] } }); const n = sb.log.length; await api('POST', `/groups/${ga}/messages`, { token: T.alice, form: fd({ text: 'after remove' }, false) }); await sleep(300); assert(!sb.log.slice(n).find(([e, d]) => e === 'msg' && d.text === 'after remove')); });
  await test('leave group / owner cannot leave', async () => { assert.equal((await api('POST', `/groups/${ga}/leave`, { token: T.alice })).s, 400); assert.equal((await api('POST', `/groups/${ga}/leave`, { token: T.carol })).s, 200); });
  await test('delete group (owner) removes messages', async () => { assert.equal((await api('DELETE', '/groups/' + ga, { token: T.alice })).s, 200); assert.equal((await api('GET', '/groups', { token: T.alice })).d.length, 0); });

  console.log('\nPhoto edit + group call (new)');
  await test('replace photo on a message, then remove it (caption kept), photo-only cannot be removed', async () => {
    const m = (await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId, text: 'cap' }, true) })).d, old = m.file;
    const r = await api('PUT', '/messages/' + m._id, { token: T.alice, form: fd({}, true, 'n.png') }); assert(r.s === 200 && r.d.file !== old && r.d.edited); assert.equal((await fetch(BASE + old)).status, 404); assert.equal((await fetch(BASE + r.d.file)).status, 200);
    const x = await api('PUT', '/messages/' + m._id, { token: T.alice, body: { removeFile: true } }); assert(x.d.type === 'text' && !x.d.file && x.d.text === 'cap');
    const p = (await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, true) })).d; assert.equal((await api('PUT', '/messages/' + p._id, { token: T.alice, body: { removeFile: true } })).s, 400); });
  await test('group call: join order, peers list, signal relay, active/left events, non-member blocked', async () => {
    const g = (await api('POST', '/groups', { token: T.alice, body: { name: 'GC', members: [T.bobId, T.daveId] } })).d._id;
    const s1 = await sock(T.alice), s2 = await sock(T.bob), s3 = await sock(T.admin);
    s1.emit('gcall:join', { group: g, video: true }); const p1 = await s1.waitFor('gcall:peers'); assert.equal(p1.peers.length, 0); await s2.waitFor('gcall:active', d => d.starter === T.aliceId && d.video);
    s2.emit('gcall:join', { group: g }); const p2 = await s2.waitFor('gcall:peers'); assert.deepEqual(p2.peers, [T.aliceId]);
    s2.emit('gcall:signal', { to: T.aliceId, group: g, data: { sdp: { type: 'offer' } } }); const sg = await s1.waitFor('gcall:signal'); assert(sg.from === T.bobId && sg.data.sdp.type === 'offer');
    s3.emit('gcall:join', { group: g }); await sleep(250); assert(!s3.log.find(([e]) => e === 'gcall:peers'), 'non-member joined');
    s3.emit('gcall:signal', { to: T.aliceId, group: g, data: { x: 1 } }); await sleep(150); assert(!s1.log.find(([e, d]) => e === 'gcall:signal' && d.from === T.adminId));
    s2.emit('gcall:leave', { group: g }); await s1.waitFor('gcall:left', d => d.from === T.bobId); await s2.waitFor('gcall:active', d => d.participants.length === 1 && d.participants[0] === T.aliceId); s1.emit('gcall:leave', { group: g }); await s2.waitFor('gcall:active', d => d.participants.length === 0); s1.close(); s2.close(); s3.close(); });

  console.log('\nReactions, forward, ICE (new)');
  await test('ICE config endpoint returns STUN (and TURN when configured)', async () => { const r = await api('GET', '/ice', { token: T.alice }); assert(r.d.iceServers[0].urls.some(u => u.startsWith('stun:'))); assert.equal((await api('GET', '/ice')).s, 401); });
  let rm;
  await test('react: add, change, toggle off; outsider blocked; live event to both', async () => {
    rm = (await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId, text: 'react me' }, false) })).d;
    let r = await api('POST', `/messages/${rm._id}/react`, { token: T.bob, body: { emoji: '❤️' } }); assert.equal(r.d.reactions.length, 1); await sa.waitFor('msg:edit', d => d._id === rm._id && d.reactions.length === 1);
    r = await api('POST', `/messages/${rm._id}/react`, { token: T.alice, body: { emoji: '😂' } }); assert.equal(r.d.reactions.length, 2);
    r = await api('POST', `/messages/${rm._id}/react`, { token: T.bob, body: { emoji: '👍' } }); assert.equal(r.d.reactions.find(x => x.user === T.bobId).emoji, '👍');
    r = await api('POST', `/messages/${rm._id}/react`, { token: T.bob, body: { emoji: '👍' } }); assert.equal(r.d.reactions.length, 1);
    assert.equal((await api('POST', `/messages/${rm._id}/react`, { token: T.admin, body: { emoji: '👍' } })).s, 404); });
  await test('forward text+photo to user and group; file is COPIED (survives original delete)', async () => {
    const g = (await api('POST', '/groups', { token: T.alice, body: { name: 'FW', members: [T.bobId] } })).d._id;
    const ph = (await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId, text: 'pic' }, true) })).d;
    const r = await api('POST', `/messages/${ph._id}/forward`, { token: T.alice, body: { users: [T.daveId], groups: [g, '5f0000000000000000000000'] } }); assert.equal(r.d.sent, 2);
    const gm = (await api('GET', `/groups/${g}/messages`, { token: T.bob })).d; assert(gm[0].file && gm[0].file !== ph.file && gm[0].text === 'pic');
    await api('DELETE', '/messages/' + ph._id, { token: T.alice }); assert.equal((await fetch(BASE + gm[0].file)).status, 200);
    assert.equal((await api('POST', `/messages/${ph._id}/forward`, { token: T.bob, body: { users: [T.daveId] } })).s, 404); });

  console.log('\nCalls (WebRTC signaling + log)');
  await test('offer -> answer -> ice -> end relayed, call logged with duration', async () => {
    sa.emit('call:offer', { to: T.bobId, offer: { sdp: 'x', type: 'offer' }, video: true }); const o = await sb.waitFor('call:offer'); assert.equal(o.from, T.aliceId);
    await sleep(100); sb.emit('call:answer', { to: T.aliceId, answer: { sdp: 'y', type: 'answer' } }); await sa.waitFor('call:answer');
    sa.emit('call:ice', { to: T.bobId, c: { candidate: 'c' } }); await sb.waitFor('call:ice'); await sleep(1100); sa.emit('call:end', { to: T.bobId }); await sb.waitFor('call:end'); await sleep(200);
    const c = (await api('GET', '/calls', { token: T.alice })).d[0]; assert(c.status === 'ended' && c.duration >= 1 && c.video === true); });
  await test('declined call + missed call (offline target)', async () => {
    sa.emit('call:offer', { to: T.bobId, offer: {}, video: false }); await sb.waitFor('call:offer', () => true); await sleep(100); sb.emit('call:end', { to: T.aliceId }); await sleep(250);
    assert.equal((await api('GET', '/calls', { token: T.alice })).d[0].status, 'declined');
    sa.log.length = 0; sa.emit('call:offer', { to: T.carolId, offer: {}, video: false }); await sa.waitFor('call:end'); await sleep(200); assert.equal((await api('GET', '/calls', { token: T.alice })).d[0].status, 'missed'); });

  console.log('\nAdmin controls on live users');
  await test('stats reflect data', async () => { const s = (await api('GET', '/admin/stats', { token: T.admin })).d; assert(s.users.total >= 5 && s.messages.total > 0 && s.calls >= 3 && s.online >= 2); });
  await test('admin deletes a message (moderation)', async () => { const h = (await api('GET', '/messages/' + T.bobId, { token: T.alice })).d; const m = h.find(x => x.type === 'image' && !x.deleted); assert.equal((await api('DELETE', '/admin/messages/' + m._id, { token: T.admin })).s, 200); });
  await test('deactivate bob: socket kicked, API 401, login 403, hidden from user list', async () => {
    const dis = new Promise(r => sb.on('disconnect', r)); assert.equal((await api('PUT', '/admin/users/' + T.bobId, { token: T.admin, body: { active: false } })).s, 200); await Promise.race([dis, sleep(2000).then(() => { throw new Error('socket not kicked'); })]);
    assert.equal((await api('GET', '/me', { token: T.bob })).s, 401); assert.equal((await api('POST', '/auth/login', { body: { email: 'bob@t.com', password: 'secret1' } })).s, 403); assert(!(await api('GET', '/users', { token: T.alice })).d.users.find(u => u._id === T.bobId));
    assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId, text: 'x' }, false) })).s, 404); });
  await test('reactivate bob works again', async () => { await api('PUT', '/admin/users/' + T.bobId, { token: T.admin, body: { active: true } }); assert.equal((await api('POST', '/auth/login', { body: { email: 'bob@t.com', password: 'secret1' } })).s, 200); });
  await test('admin deletes carol: account, messages, owned groups gone', async () => { const g = (await api('POST', '/groups', { token: T.carol, body: { name: 'CG', members: [T.aliceId] } })).d._id; assert.equal((await api('DELETE', '/admin/users/' + T.carolId, { token: T.admin })).s, 200); assert.equal((await api('GET', '/me', { token: T.carol })).s, 401); assert.equal((await api('GET', '/groups', { token: T.alice })).d.find(x => x._id === g), undefined); assert.equal((await api('GET', '/messages/' + T.carolId, { token: T.alice })).d.length, 0); });
  await test('audit log recorded admin actions (password masked)', async () => { const l = (await api('GET', '/admin/logs', { token: T.admin })).d; const acts = l.map(x => x.action); assert(['user.create', 'user.update', 'user.delete', 'message.delete'].every(a => acts.includes(a))); assert(!JSON.stringify(l).includes('$2')); });
  await test('socket rejects invalid token', async () => { await assert.rejects(sock('bad')); });

  console.log('\nSessions, password recovery, email verify (new)');
  const outbox = async () => (await api('GET', '/__test/outbox', { token: T.admin })).d;
  const linkToken = (mail, k) => new RegExp('[?]' + k + '=([\\w-]+)').exec(mail.text)[1];
  let Z;
  await test('register gives access+refresh token; refresh ROTATES; old refresh token is dead', async () => {
    const r = await api('POST', '/auth/register', { body: { name: 'zoe', email: 'zoe@t.com', password: 'secret1' } }); assert(r.d.token && r.d.refreshToken); Z = r.d;
    const n = await api('POST', '/auth/refresh', { body: { refreshToken: Z.refreshToken } }); assert.equal(n.s, 200); assert(n.d.refreshToken !== Z.refreshToken);
    assert.equal((await api('GET', '/me', { token: n.d.token })).d.email, 'zoe@t.com');
    assert.equal((await api('POST', '/auth/refresh', { body: { refreshToken: Z.refreshToken } })).s, 401); assert.equal((await api('POST', '/auth/refresh', { body: { refreshToken: 'junk' } })).s, 401); Z = n.d; });
  await test('logout revokes the refresh token', async () => { assert.equal((await api('POST', '/auth/logout', { body: { refreshToken: Z.refreshToken } })).s, 200); assert.equal((await api('POST', '/auth/refresh', { body: { refreshToken: Z.refreshToken } })).s, 401); });
  await test('email verification: mail sent at register, link verifies, token is single-use', async () => {
    const m = (await outbox()).find((x) => x.to === 'zoe@t.com' && /verify/i.test(x.subject)); assert(m, 'no verify mail'); const tok = linkToken(m, 'verify');
    const lg = await api('POST', '/auth/login', { body: { email: 'zoe@t.com', password: 'secret1' } }); Z = lg.d; assert.equal(lg.d.user.verified, false);
    assert.equal((await api('POST', '/auth/verify', { body: { token: tok } })).s, 200); assert.equal((await api('GET', '/me', { token: Z.token })).d.verified, true);
    assert.equal((await api('POST', '/auth/verify', { body: { token: tok } })).s, 400); });
  await test('forgot password: unknown email still 200 (no user enumeration); real email gets reset link', async () => {
    assert.equal((await api('POST', '/auth/forgot', { body: { email: 'nobody@t.com' } })).s, 200); const n = (await outbox()).length;
    assert.equal((await api('POST', '/auth/forgot', { body: { email: 'ZOE@t.com' } })).s, 200); const o = await outbox(); assert.equal(o.length, n + 1); assert(/reset/i.test(o[o.length - 1].subject)); });
  await test('reset password: sets new password, logs in, kills old sessions, link is single-use', async () => {
    const o = await outbox(), tok = linkToken(o[o.length - 1], 'reset');
    assert.equal((await api('POST', '/auth/reset', { body: { token: 'bad', password: 'newsecret1' } })).s, 400); assert.equal((await api('POST', '/auth/reset', { body: { token: tok, password: '123' } })).s, 400);
    const r = await api('POST', '/auth/reset', { body: { token: tok, password: 'newsecret1' } }); assert(r.s === 200 && r.d.token);
    assert.equal((await api('POST', '/auth/login', { body: { email: 'zoe@t.com', password: 'secret1' } })).s, 400); assert.equal((await api('POST', '/auth/login', { body: { email: 'zoe@t.com', password: 'newsecret1' } })).s, 200);
    assert.equal((await api('POST', '/auth/refresh', { body: { refreshToken: Z.refreshToken } })).s, 401); assert.equal((await api('POST', '/auth/reset', { body: { token: tok, password: 'another1' } })).s, 400); Z = r.d; });
  await test('change password returns fresh session and revokes the old refresh tokens', async () => {
    const r = await api('PUT', '/me/password', { token: Z.token, body: { current: 'newsecret1', password: 'third123' } }); assert(r.s === 200 && r.d.refreshToken);
    assert.equal((await api('POST', '/auth/refresh', { body: { refreshToken: Z.refreshToken } })).s, 401); assert.equal((await api('POST', '/auth/refresh', { body: { refreshToken: r.d.refreshToken } })).s, 200); });
  await test('admin deactivates a user -> their refresh token stops working', async () => {
    const lg = await api('POST', '/auth/login', { body: { email: 'dave@t.com', password: 'secret1' } }); assert.equal(lg.s, 200);
    await api('PUT', '/admin/users/' + T.daveId, { token: T.admin, body: { active: false } }); assert.equal((await api('POST', '/auth/refresh', { body: { refreshToken: lg.d.refreshToken } })).s, 401);
    await api('PUT', '/admin/users/' + T.daveId, { token: T.admin, body: { active: true } }); });
  await test('validation messages are clear (zod)', async () => { const r = await api('POST', '/auth/register', { body: { name: 'x', email: 'a@b.co', password: '12' } }); assert(r.s === 400 && /6 characters/.test(r.d.error)); assert.equal((await api('POST', '/auth/register', { body: { name: 'x', email: 'nope', password: '123456' } })).d.error, 'Invalid email'); });

  console.log('\nBlock users (new)');
  const sb2 = await sock(T.bob);
  await test('block: nobody can message each other, listed, calls rejected; unblock restores', async () => {
    assert.equal((await api('POST', '/blocks/' + T.aliceId, { token: T.alice })).s, 400); assert.equal((await api('POST', '/blocks/' + T.bobId, { token: T.alice })).s, 200);
    assert.deepEqual((await api('GET', '/blocks', { token: T.alice })).d.blocked, [T.bobId]);
    assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId, text: 'x' }, false) })).s, 403); assert.equal((await api('POST', '/messages', { token: T.bob, form: fd({ to: T.aliceId, text: 'x' }, false) })).s, 403);
    sa.log.length = 0; sa.emit('call:offer', { to: T.bobId, offer: {}, video: false }); await sa.waitFor('call:end', (d) => d.from === T.bobId); assert(!sb2.log.find(([e]) => e === 'call:offer'));
    assert.equal((await api('DELETE', '/blocks/' + T.bobId, { token: T.alice })).s, 200); assert.equal((await api('POST', '/messages', { token: T.bob, form: fd({ to: T.aliceId, text: 'hi again' }, false) })).s, 200);
    sa.emit('call:offer', { to: T.bobId, offer: {}, video: false }); await sb2.waitFor('call:offer', (d) => d.from === T.aliceId); sa.emit('call:end', { to: T.bobId }); await sleep(150); });

  console.log('\nGroup call limit + storage drivers (new)');
  await test('group call is capped (MAX_GROUP_CALL=2): 3rd joiner gets gcall:full', async () => {
    const e = (await api('POST', '/auth/register', { body: { name: 'erin', email: 'erin@t.com', password: 'secret1' } })).d, se = await sock(e.token);
    const g = (await api('POST', '/groups', { token: T.alice, body: { name: 'Cap', members: [T.bobId, e.user._id] } })).d._id; await sleep(200);
    sa.emit('gcall:join', { group: g }); sb2.emit('gcall:join', { group: g }); await sb2.waitFor('gcall:peers', (d) => d.group === g);
    se.emit('gcall:join', { group: g }); const f = await se.waitFor('gcall:full', (d) => d.group === g); assert.equal(f.max, 2); assert(!se.log.find(([ev]) => ev === 'gcall:peers'));
    sa.emit('gcall:leave', { group: g }); sb2.emit('gcall:leave', { group: g }); se.close(); });
  await test('S3 storage driver (injected stub client): save/copy/remove build correct commands', async () => {
    const sent = []; const stub = { send: async (c) => { sent.push([c.constructor.name, c.input]); } };
    const s3 = require('../src/services/storage/s3')({ S3_BUCKET: 'bk', S3_REGION: 'ap-south-1', S3_PUBLIC_URL: 'https://cdn.x.com/' }, stub);
    const url = await s3.save({ originalname: 'a.PNG', mimetype: 'image/png', buffer: Buffer.from('x') }); assert(/^https:\/\/cdn\.x\.com\/\d+-[0-9a-f]{8}\.png$/.test(url));
    assert.equal(sent[0][0], 'PutObjectCommand'); assert(sent[0][1].Bucket === 'bk' && sent[0][1].ContentType === 'image/png');
    const c = await s3.copy(url); assert(c !== url && sent[1][0] === 'CopyObjectCommand' && sent[1][1].CopySource.startsWith('bk/')); await s3.remove(url); assert.equal(sent[2][0], 'DeleteObjectCommand'); await s3.remove('/uploads/local.png'); assert.equal(sent.length, 3); });

  console.log('\nSecurity headers & limits');
  await test('helmet headers present', async () => { const r = await fetch(BASE + '/api/health'); assert.equal(r.headers.get('x-content-type-options'), 'nosniff'); assert(!r.headers.get('x-powered-by')); });
  await test('login rate limit kicks in (429)', async () => { let last; for (let i = 0; i < 100; i++) last = (await api('POST', '/auth/login', { body: { email: 'x@t.com', password: 'y' } })).s; assert.equal(last, 429); });

  [sa, sb, sb2].forEach(s => s.close()); srv.kill('SIGTERM'); await sleep(500);
  try { const c = await require('mongoose').createConnection(env.MONGO_URI).asPromise(); await c.dropDatabase(); await c.close(); } catch {}
  console.log(`\n${pass} passed, ${fail} failed`); if (fail) { console.log('Failed:', fails.join(' | ')); console.log(out.slice(-1500)); } process.exit(fail ? 1 : 0);
})();
