# Bondhu Chat — MERN Messenger

Real-time messenger: chat, photo/voice/file, emoji, reply/reaction/forward, group chat, **audio/video call (1:1 + group)**, screen share,
admin panel, dark/light, English/বাংলা, mobile responsive.

| Layer | Tech |
|---|---|
| Frontend | React 18 + Vite, lucide-react, socket.io-client, WebRTC |
| Backend | Node 18+, Express, Socket.IO, Mongoose (MongoDB), zod, JWT + rotating refresh tokens |
| Infra | Docker Compose, nginx, coturn (TURN), optional S3 storage |

## Quick start (development)
```bash
# 1) MongoDB chalu rakhun, tarpor:
cd server && cp .env.example .env && npm i && npm run dev     # API + sockets  :5000
cd client && npm i && npm run dev                              # UI             :5173
```
Default admin: `admin@bondhu.com` / `admin123` (`server/.env` e bodlan). Email (verify/reset) SMTP na thakle server console e print hoy.

## Folder map (kon code kothay)
```
server/src
  server.js        entry: DB connect -> seed -> listen
  app.js           Express: security, rate limit, routes, error handler
  config/env.js    shob environment variable (validated, ek jaygay)
  routes/          URL -> controller (+ validation)           <- "ki API ache?" ekhane dekhun
  controllers/     req/res handle kore, service ke dake       (patla, logic nei)
  services/        BUSINESS LOGIC (auth, message, group, call, storage, mail ...)
  models/          MongoDB schema
  middleware/      auth, validate, upload, rate limit, error
  validators/      zod schema (request body rule)
  sockets/         real-time: presence, typing, 1:1 call, group call
  realtime.js      services theke socket e event pathanor wrapper
client/src
  services/        api (auto token refresh), socket, session
  context/         Auth, Prefs (theme/language/sound)
  hooks/           data + real-time logic (useMessages, useCall, useGroupCall ...)
  components/      UI: auth/ layout/ chat/ call/ admin/ common/
  pages/ChatPage   hooks + components ke jora lagay
tests/browser      Selenium UI test      server/test   API + socket e2e test
docs/              ARCHITECTURE.md, API.md
```
Detail: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) · API list: [docs/API.md](docs/API.md)

## Tests
```bash
cd server && npm test        # 65 e2e test (real MongoDB lage), npm run lint
# Browser (Selenium + Firefox): API :5000 ar client :5173 chalu rekhe
cd tests/browser && pip install selenium && SERVER_LOG=../../server.log python3 ui_test2.py   # ui_test3..7 o
```
CI: `.github/workflows/ci.yml` (lint + API test + client build proti push e).

## Deploy (Docker)
```bash
cp server/.env.example server/.env     # JWT_SECRET, ADMIN_PASSWORD, APP_URL, CLIENT_URL, TURN_* bodlan
docker compose up -d --build           # http://localhost  (nginx -> API + sockets)
```
**Call e kothar sound er jonno:** HTTPS (browser HTTPS chhara mic/camera dey na) + TURN server (alada network / mobile data e lagbe).
`TURN_URL`, `TURN_SECRET`, `PUBLIC_IP` din; coturn compose e ache; firewall e UDP/TCP 3478 ar 49160-49200 khulun. HTTPS er jonno nginx er samne Caddy/Cloudflare/certbot.

## Important environment variables (`server/.env.example`)
`JWT_SECRET` · `ACCESS_TTL` (15m) · `REFRESH_TTL_DAYS` · `REQUIRE_VERIFIED` · `CLIENT_URL` (CORS) · `APP_URL` (email link) · `SMTP_URL` · `STORAGE=local|s3` (+ `S3_*`) · `MAX_GROUP_CALL` · `TURN_*`

## Ja ekhono nei / sotorko thakar jinish
- **Group call = mesh WebRTC** (proti participant bakider sathe direct). 8 jon porjonto (`MAX_GROUP_CALL`), er beshi hole SFU (LiveKit/mediasoup) lagbe.
- **Web push (app bondho thakle notification)** nei; sudhu browser Notification (tab khola thakle).
- S3 driver unit-test kora (stub), real AWS/R2 e test hoyni. SMTP real provider e test hoyni.
- Screen share er logic test kora, kintu real screen-capture permission headless test e hoyni. Chrome/Safari e test hoyni (sudhu Firefox).
- Message end-to-end encrypted na. Group call server recording nei.
