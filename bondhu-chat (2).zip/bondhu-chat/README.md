# Bondhu Chat (MERN Messenger)
## Run
1. MongoDB চালু রাখুন (local অথবা Atlas)।
2. `cd server && cp .env.example .env && npm i && npm start`  (port 5000)
3. `cd client && npm i && npm run dev`  (port 5173)
Default admin: admin@bondhu.com / admin123  (.env থেকে বদলান)
Video/audio call: localhost-এ চলে; production-এ HTTPS + TURN server লাগবে।

## Backend v2 (docker)
`cp server/.env.example server/.env` -> `docker compose up --build`  (API: http://localhost:5000/api/health)
Production-e JWT_SECRET, ADMIN_PASSWORD, CLIENT_URL obossoi bodlan; HTTPS (nginx/Caddy) + TURN server lagbe.

## Test
MongoDB chalu rakhun, tarpor: `cd server && npm i && npm test`  (49 ta end-to-end test; alada test DB use kore, shesh e muche dey)

## Browser UI test (Selenium + Firefox, 35 ta test: chat, emoji, photo, audio/video call, admin, mobile, বাংলা, dark mode)
`pip install selenium` -> API (:5000) ar client (`npm run dev`, :5173) chalu rekhe `FIREFOX_BIN=/path/firefox GECKODRIVER=/path/geckodriver python3 tests/ui_test.py`
Note: login/register rate limit (15 min e 30) bar bar test chalale hit hote pare, server restart korle reset hoy.
