import time, random, traceback, os, base64
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException

URL = "http://127.0.0.1:5173"; SH = "/home/claude/shots"; R = random.randint(1000, 9999)
PNG = "/home/claude/test.png"
open(PNG, "wb").write(base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="))
def mk(w=1280, h=850):
    o = Options(); o.add_argument("-headless"); o.binary_location = os.environ.get("FIREFOX_BIN","/home/claude/mamba/envs/f/bin/firefox")
    for k, v in {"media.navigator.streams.fake": True, "media.navigator.permission.disabled": True, "media.peerconnection.ice.obfuscate_host_addresses": False,
                 "media.peerconnection.ice.loopback": True, "intl.accept_languages": "en-US"}.items(): o.set_preference(k, v)
    d = webdriver.Firefox(options=o, service=Service(os.environ.get("GECKODRIVER","/home/claude/mamba/envs/f/bin/geckodriver"))); d.set_window_size(w, h); d.get(URL); return d
def W(d, css, t=8, vis=True):
    return WebDriverWait(d, t).until(lambda x: next((e for e in x.find_elements(By.CSS_SELECTOR, css) if (e.is_displayed() or not vis)), None))
def gone(d, css, t=8): WebDriverWait(d, t).until(lambda x: not any(e.is_displayed() for e in x.find_elements(By.CSS_SELECTOR, css)))
def btn(d, text, t=8): return WebDriverWait(d, t).until(lambda x: next((e for e in x.find_elements(By.XPATH, f"//button[normalize-space()='{text}']") if e.is_displayed()), None))
def fill(d, ph, val): e = W(d, f"input[placeholder='{ph}']"); e.clear(); e.send_keys(val)
def shot(d, n): d.save_screenshot(f"{SH}/{n}.png")
def bubbles(d): return [e.text for e in d.find_elements(By.CSS_SELECTOR, ".bub")]
def has_bubble(d, s, t=8): WebDriverWait(d, t).until(lambda x: any(s in b for b in bubbles(x)))
res = []
def test(name, fn, *a):
    try: fn(*a); res.append((name, True, "")); print("  ✓", name)
    except Exception as e:
        res.append((name, False, repr(e)[:200])); print("  ✗", name, "\n     ", repr(e)[:300])
        for d in DR: 
            try: shot(d, "FAIL_" + name[:20].replace(" ", "_") + str(DR.index(d)))
            except: pass
DR = []
A = f"alice{R}@t.com"; B = f"bob{R}@t.com"; P = "secret12"
def register(d, name, email):
    btn(d, "New here? Create an account").click(); fill(d, "Full name", name); fill(d, "Email", email); fill(d, "Password", P); btn(d, "Create account").click(); W(d, ".list")
def login(d, email, pw=P): fill(d, "Email", email); fill(d, "Password", pw); btn(d, "Log in").click()

a = mk(); b = mk(); DR += [a, b]
print("\nAuth & preferences")
test("login screen renders", lambda: (W(a, ".card"), shot(a, "01_login_light")))
test("register alice via UI -> chat screen", register, a, f"Alice{R}", A)
test("register bob via UI", register, b, f"Bob{R}", B)
test("session persists after reload", lambda: (a.refresh(), W(a, ".list")))
def theme():
    before = a.execute_script("return document.documentElement.dataset.theme"); [e for e in a.find_elements(By.CSS_SELECTOR, ".tools button")][1].click()
    after = a.execute_script("return document.documentElement.dataset.theme"); assert before != after, (before, after)
    a.refresh(); W(a, ".list"); assert a.execute_script("return document.documentElement.dataset.theme") == after; shot(a, "02_dark_mode")
test("dark/light toggle works and persists", theme)
def lang():
    btn(a, "বাংলা").click(); W(a, "input[placeholder='মানুষ খুঁজুন']"); assert "বন্ধু চ্যাট" in a.find_element(By.CSS_SELECTOR, ".top h1").text; shot(a, "03_bangla")
    a.refresh(); W(a, "input[placeholder='মানুষ খুঁজুন']"); btn(a, "EN").click(); W(a, "input[placeholder='Search people']")
test("English <-> বাংলা toggle works and persists", lang)
test("alice sees bob in people list", lambda: (a.refresh(), W(a, ".item")) and None)

print("\nMessaging")
def open_chat(d, name):
    W(d, ".list"); WebDriverWait(d, 10).until(lambda x: x.execute_script("const e=[...document.querySelectorAll('.item')].find(i=>i.textContent.includes(arguments[0])); if(e){e.click();return true}", name)); W(d, ".compose")
def say(d, text): e = W(d, ".compose input[placeholder='Write a message…']"); e.send_keys(text, Keys.ENTER)
test("alice opens chat with bob (online dot)", lambda: (open_chat(a, f"Bob{R}"), W(a, ".rhead .dot.on")))
test("alice sends text; appears in her chat", lambda: (say(a, "Hello Bob 👋"), has_bubble(a, "Hello Bob")))
test("bob gets unread badge in real time", lambda: W(b, ".item .badge"))
test("bob opens chat and sees message", lambda: (open_chat(b, f"Alice{R}"), has_bubble(b, "Hello Bob")))
test("bob replies; alice receives instantly", lambda: (say(b, "Hi Alice!"), has_bubble(a, "Hi Alice!")))
def typing():
    a.find_element(By.CSS_SELECTOR, ".compose input[placeholder='Write a message…']").send_keys("x"); WebDriverWait(b, 5).until(lambda d: "typing" in d.find_element(By.CSS_SELECTOR, ".rhead small").text)
    a.find_element(By.CSS_SELECTOR, ".compose input[placeholder='Write a message…']").clear()
test("typing indicator", typing)
def emoji():
    inp = lambda: a.find_element(By.CSS_SELECTOR, ".compose input[placeholder='Write a message…']")
    inp().clear(); W(a, ".compose .ic").click()
    WebDriverWait(a, 10).until(lambda x: x.execute_script("const e=document.querySelector('.emoji button.epr-emoji'); if(e){e.click();return true}"))
    v = inp().get_attribute("value"); assert v.strip(), "no emoji inserted"; print("      emoji inserted:", v.strip())
    shot(a, "04_emoji_picker"); inp().send_keys(Keys.ENTER); has_bubble(b, v.strip())
test("emoji picker inserts emoji and sends", emoji)
def photo():
    a.find_element(By.CSS_SELECTOR, ".compose input[type=file]").send_keys(PNG); W(a, ".bub img"); W(b, ".bub img")
    ok = b.execute_script("return [...document.querySelectorAll('.bub img')].some(i=>i.complete&&i.naturalWidth>0)"); assert ok, "image not loaded"
test("photo send: renders for both users", photo)
def hist():
    a.refresh(); open_chat(a, f"Bob{R}"); has_bubble(a, "Hi Alice!"); W(a, ".bub img")
test("history persists after reload", hist)

print("\nCalls (fake camera/mic, real WebRTC between two browsers)")
def media_ok(d, video):
    return d.execute_script("""const v=document.querySelector('.remote'); const s=v&&v.srcObject; if(!s) return 'no stream';
      const a=s.getAudioTracks().filter(t=>t.readyState==='live').length, vt=s.getVideoTracks().filter(t=>t.readyState==='live').length;
      return JSON.stringify({a,vt,w:v.videoWidth,t:v.currentTime});""")
def call(video):
    title = "Video" if video else "Audio"; W(a, f".rhead button[title='{title}']").click()
    W(b, ".callbox .btn.ok", 10); assert "calling you" in b.find_element(By.CSS_SELECTOR, ".callbox").text; shot(b, "05_incoming_call")
    b.find_element(By.CSS_SELECTOR, ".callbox .btn.ok").click()
    import json
    def connected(d):
        r = media_ok(d, video)
        if r == 'no stream': return False
        j = json.loads(r); return j['a'] >= 1 and (j['vt'] >= 1 and j['w'] > 0 if video else True)
    WebDriverWait(a, 20).until(connected); WebDriverWait(b, 20).until(connected)
    t1 = json.loads(media_ok(a, video))['t']; time.sleep(1.5); t2 = json.loads(media_ok(a, video))['t']
    if video: assert t2 > t1, f"video not advancing {t1}->{t2}"
    shot(a, f"06_call_{title.lower()}")
    W(a, ".callbox .endc").click(); gone(a, ".callbox"); gone(b, ".callbox")
test("audio call: ring -> accept -> live audio both ways -> end", call, False)
test("video call: ring -> accept -> live video flowing -> end", call, True)
def decline():
    W(a, ".rhead button[title='Audio']").click(); W(b, ".callbox .btn.bad", 10).click(); gone(a, ".callbox"); gone(b, ".callbox")
test("decline call closes both sides", decline)
def cancel():
    W(a, ".rhead button[title='Audio']").click(); W(b, ".callbox .btn.ok", 10); W(a, ".callbox .endc").click(); gone(b, ".callbox")
test("caller cancels while ringing", cancel)
def calllog():
    import json, urllib.request
    def api(path, body=None):
        r = urllib.request.Request("http://127.0.0.1:5000/api" + path, data=body and json.dumps(body).encode(), headers={"Content-Type": "application/json", **({"Authorization": "Bearer " + tok} if body is None else {})})
        return json.load(urllib.request.urlopen(r))
    global tok; tok = api("/auth/login", {"email": A, "password": P})["token"]; calls = api("/calls"); st = sorted((c["status"], c["video"]) for c in calls); print("      call log:", st)
    assert ("ended", True) in st and ("ended", False) in st and any(x[0] == "declined" for x in st) and any(x[0] == "missed" for x in st)
    assert all(c["duration"] >= 1 for c in calls if c["status"] == "ended")
test("call log saved by server (audio+video ended with duration, declined, cancelled)", calllog)

print("\nResponsive (mobile 390x800)")
m = mk(390, 800); DR.append(m)
def mobile():
    login(m, A); W(m, ".list")
    assert m.execute_script("return getComputedStyle(document.querySelector('.room')).display") == "none"; shot(m, "07_mobile_list")
    open_chat(m, f"Bob{R}"); assert m.execute_script("return getComputedStyle(document.querySelector('.list')).display") == "none"
    assert W(m, ".back").is_displayed(); shot(m, "08_mobile_chat")
    assert m.execute_script("return document.documentElement.scrollWidth <= window.innerWidth"), "horizontal overflow"
    m.find_element(By.CSS_SELECTOR, ".back").click(); W(m, ".list")
test("mobile: list/chat navigation + no horizontal overflow", mobile)

print("\nAdmin panel")
ad = mk(); DR.append(ad)
test("admin login shows Admin panel tab", lambda: (login(ad, "admin@bondhu.com", "admin123"), btn(ad, "Admin panel")))
test("normal user has no Admin tab", lambda: [e for e in a.find_elements(By.XPATH, "//button[normalize-space()='Admin panel']")] == [] or (_ for _ in ()).throw(AssertionError("visible")))
DN = f"Dave{R}"; DE = f"dave{R}@t.com"
def add_user():
    btn(ad, "Admin panel").click(); btn(ad, "+ Add user").click(); fill(ad, "Full name", DN); fill(ad, "Email", DE); fill(ad, "Password", P); btn(ad, "Save").click()
    WebDriverWait(ad, 8).until(lambda d: DN in d.find_element(By.CSS_SELECTOR, "table").text); shot(ad, "09_admin_panel")
test("admin adds user", add_user)
def row(d, name): return [r for r in d.find_elements(By.CSS_SELECTOR, "tbody tr") if name in r.text][0]
def search():
    fill(ad, "Search people", f"dave{R}"); time.sleep(.3); rows = [r for r in ad.find_elements(By.CSS_SELECTOR, "tbody tr")]; assert len(rows) == 1; ad.find_element(By.CSS_SELECTOR, ".bar input").clear()
test("admin search filters table", search)
def edit():
    btn(ad, "Edit").click() if False else row(ad, DN).find_element(By.XPATH, ".//button[normalize-space()='Edit']").click(); e = W(ad, ".modal input[placeholder='Full name']"); e.clear(); e.send_keys(DN + "X"); btn(ad, "Save").click()
    WebDriverWait(ad, 8).until(lambda d: DN + "X" in d.find_element(By.CSS_SELECTOR, "table").text)
test("admin edits user", edit)
def toggle():
    row(ad, DN).find_element(By.CSS_SELECTOR, ".switch i").click(); WebDriverWait(ad, 8).until(lambda d: "Inactive" in row(d, DN).text)
test("admin deactivates user (switch)", toggle)
def inactive_login():
    c = mk(); DR.append(c)
    try: login(c, DE); WebDriverWait(c, 8).until(lambda d: "inactive" in d.find_element(By.CSS_SELECTOR, ".err").text.lower()); shot(c, "10_inactive_login")
    finally: c.quit(); DR.remove(c)
test("inactive user cannot log in (clear error shown)", inactive_login)
def kick():
    ad.execute_script("arguments[0].click()", row(ad, f"Alice{R}").find_element(By.CSS_SELECTOR, ".switch input")); WebDriverWait(ad, 8).until(lambda d: "Inactive" in row(d, f"Alice{R}").text)
    W(a, ".card", 8)
test("deactivating an ONLINE user logs them out instantly (no reload)", kick)
test("admin re-activates alice", lambda: (ad.execute_script("arguments[0].click()", row(ad, f"Alice{R}").find_element(By.CSS_SELECTOR, ".switch input")), WebDriverWait(ad, 8).until(lambda d: "Inactive" not in row(d, f"Alice{R}").text)))
def delete():
    row(ad, DN).find_element(By.XPATH, ".//button[normalize-space()='Delete']").click(); ad.switch_to.alert.accept(); WebDriverWait(ad, 8).until(lambda d: DN not in d.find_element(By.CSS_SELECTOR, "table").text)
test("admin deletes user (confirm dialog)", delete)
test("admin cannot delete/deactivate self (controls disabled)", lambda: (lambda r: r.find_element(By.XPATH, ".//button[normalize-space()='Delete']").get_attribute("disabled") and r.find_element(By.CSS_SELECTOR, ".switch input").get_attribute("disabled") or (_ for _ in ()).throw(AssertionError("enabled")))(row(ad, "Admin")))
def admin_mobile():
    ad.set_window_size(390, 800); time.sleep(.5); shot(ad, "11_admin_mobile"); assert ad.execute_script("return document.documentElement.scrollWidth <= window.innerWidth"), "overflow"
test("admin panel fits mobile (table becomes cards)", admin_mobile)
test("logout returns to login", lambda: (btn(ad, "Log out").click(), W(ad, ".card")))

for d in DR:
    try: d.quit()
    except: pass
p = sum(1 for r in res if r[1]); print(f"\n{p} passed, {len(res)-p} failed")
