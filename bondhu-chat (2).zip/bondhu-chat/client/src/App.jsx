import { useEffect, useState } from 'react';
import { api } from './api'; import { tr } from './i18n'; import Chat from './Chat'; import Admin from './Admin';
export default function App() {
  const [theme, setTheme] = useState(localStorage.theme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  const [lang, setLang] = useState(localStorage.lang || 'en'), [me, setMe] = useState(null), [ready, setReady] = useState(false), [tab, setTab] = useState('chat');
  const [mode, setMode] = useState('login'), [f, setF] = useState({ name: '', email: '', password: '' }), [err, setErr] = useState('');
  const t = k => tr(lang, k);
  useEffect(() => { document.documentElement.dataset.theme = theme; localStorage.theme = theme; }, [theme]);
  useEffect(() => { document.documentElement.lang = lang; localStorage.lang = lang; }, [lang]);
  useEffect(() => { localStorage.token ? api('/me').then(setMe).catch(() => localStorage.removeItem('token')).finally(() => setReady(true)) : setReady(true); }, []);
  const submit = async e => {
    e.preventDefault(); setErr('');
    try { const d = await api('/auth/' + mode, { method: 'POST', body: f }); localStorage.token = d.token; setMe(d.user); } catch (x) { setErr(x.message); }
  };
  const logout = () => { localStorage.removeItem('token'); setMe(null); setTab('chat'); };
  const tools = <div className="tools"><button className="ghost" onClick={() => setLang(lang === 'en' ? 'bn' : 'en')}>{lang === 'en' ? 'বাংলা' : 'EN'}</button>
    <button className="ghost" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? '☀️' : '🌙'}</button></div>;
  if (!ready) return null;
  if (!me) return (<div className="auth"><form className="card" onSubmit={submit}><div className="rowb"><h1>{t('app')}</h1>{tools}</div>
    {mode === 'register' && <input required placeholder={t('name')} value={f.name} onChange={e => setF({ ...f, name: e.target.value })} />}
    <input required type="email" placeholder={t('email')} value={f.email} onChange={e => setF({ ...f, email: e.target.value })} />
    <input required type="password" minLength={6} placeholder={t('password')} value={f.password} onChange={e => setF({ ...f, password: e.target.value })} />
    {err && <p className="err">{err}</p>}<button className="btn">{t(mode)}</button>
    <button type="button" className="link" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setErr(''); }}>{t(mode === 'login' ? 'noAcc' : 'haveAcc')}</button></form></div>);
  return (<div className="app"><header className="top"><h1>{t('app')}</h1>
    <nav><button className={tab === 'chat' ? 'tab on' : 'tab'} onClick={() => setTab('chat')}>{t('chat')}</button>
      {me.role === 'admin' && <button className={tab === 'admin' ? 'tab on' : 'tab'} onClick={() => setTab('admin')}>{t('admin')}</button>}</nav>
    {tools}<button className="ghost" onClick={logout}>{t('logout')}</button></header>
    <main>{tab === 'chat' ? <Chat t={t} me={me} theme={theme} /> : <Admin t={t} me={me} />}</main></div>);
}
