export const api = async (url, { method = 'GET', body, form } = {}) => {
  const h = { Authorization: 'Bearer ' + (localStorage.token || '') };
  if (body) h['Content-Type'] = 'application/json';
  const r = await fetch('/api' + url, { method, headers: h, body: form || (body && JSON.stringify(body)) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Error');
  return d;
};
