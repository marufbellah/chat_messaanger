import { useEffect, useState } from 'react';
import { api } from './api';
const blank = { name: '', email: '', password: '', role: 'user', active: true };
export default function Admin({ t, me }) {
  const [list, setList] = useState([]), [q, setQ] = useState(''), [f, setF] = useState(null), [err, setErr] = useState('');
  const load = () => api('/admin/users').then(setList);
  useEffect(() => { load(); }, []);
  const save = async e => {
    e.preventDefault(); setErr('');
    try { f._id ? await api('/admin/users/' + f._id, { method: 'PUT', body: f }) : await api('/admin/users', { method: 'POST', body: f }); setF(null); load(); }
    catch (x) { setErr(x.message); }
  };
  const toggle = u => api('/admin/users/' + u._id, { method: 'PUT', body: { active: !u.active } }).then(load);
  const del = async u => { if (confirm(t('confirm'))) { try { await api('/admin/users/' + u._id, { method: 'DELETE' }); load(); } catch (x) { alert(x.message); } } };
  const rows = list.filter(u => (u.name + u.email).toLowerCase().includes(q.toLowerCase()));
  return (<div className="admin">
    <div className="bar"><h2>{t('users')} <small>{t('total')}: {list.length}</small></h2>
      <input placeholder={t('search')} value={q} onChange={e => setQ(e.target.value)} />
      <button className="btn" onClick={() => setF(blank)}>+ {t('add')}</button></div>
    <div className="tablewrap"><table><thead><tr><th>{t('name')}</th><th>{t('email')}</th><th>{t('role')}</th><th>{t('status')}</th><th>{t('actions')}</th></tr></thead>
      <tbody>{rows.map(u => <tr key={u._id}><td data-l={t('name')}>{u.name}</td><td data-l={t('email')}>{u.email}</td><td data-l={t('role')}><span className="chip">{u.role}</span></td>
        <td data-l={t('status')}><label className="switch"><input type="checkbox" checked={u.active} disabled={u._id === me._id} onChange={() => toggle(u)} /><i /></label> {u.active ? t('active') : t('inactive')}</td>
        <td data-l={t('actions')} className="acts"><button className="ghost" onClick={() => setF({ ...u, password: '' })}>{t('edit')}</button>
          <button className="ghost danger" disabled={u._id === me._id} onClick={() => del(u)}>{t('del')}</button></td></tr>)}
        {!rows.length && <tr><td colSpan="5">{t('noUsers')}</td></tr>}</tbody></table></div>
    {f && <div className="overlay" onClick={() => setF(null)}><form className="modal" onClick={e => e.stopPropagation()} onSubmit={save}>
      <h3>{f._id ? t('edit') : t('add')}</h3>
      <input required placeholder={t('name')} value={f.name} onChange={e => setF({ ...f, name: e.target.value })} />
      <input required type="email" placeholder={t('email')} value={f.email} onChange={e => setF({ ...f, email: e.target.value })} />
      <input type="password" minLength={f.password ? 6 : 0} required={!f._id} placeholder={f._id ? t('passHint') : t('password')} value={f.password} onChange={e => setF({ ...f, password: e.target.value })} />
      <select value={f.role} onChange={e => setF({ ...f, role: e.target.value })}><option value="user">user</option><option value="admin">admin</option></select>
      <label className="row"><input type="checkbox" checked={f.active} onChange={e => setF({ ...f, active: e.target.checked })} /> {t('active')}</label>
      {err && <p className="err">{err}</p>}
      <div className="row end"><button type="button" className="ghost" onClick={() => setF(null)}>{t('cancel')}</button><button className="btn">{t('save')}</button></div>
    </form></div>}
  </div>);
}
