const D = {
  en: { app: 'Bondhu Chat', login: 'Log in', register: 'Create account', name: 'Full name', email: 'Email', password: 'Password', noAcc: 'New here? Create an account', haveAcc: 'Already have an account? Log in',
    search: 'Search people', type: 'Write a message…', online: 'Online', offline: 'Offline', pick: 'Choose someone to start chatting', logout: 'Log out', admin: 'Admin panel', chat: 'Chats',
    users: 'Users', add: 'Add user', edit: 'Edit', del: 'Delete', save: 'Save', cancel: 'Cancel', role: 'Role', status: 'Status', active: 'Active', inactive: 'Inactive', actions: 'Actions',
    confirm: 'Delete this user and their messages?', incoming: 'is calling you…', accept: 'Accept', reject: 'Decline', end: 'End call', calling: 'Calling…', video: 'Video', audio: 'Audio',
    typing: 'typing…', noUsers: 'No users found', passHint: 'Leave blank to keep current', total: 'Total', camErr: 'Camera/microphone permission needed', empty: 'Say hello 👋' },
  bn: { app: 'বন্ধু চ্যাট', login: 'লগ ইন', register: 'অ্যাকাউন্ট খুলুন', name: 'পুরো নাম', email: 'ইমেইল', password: 'পাসওয়ার্ড', noAcc: 'নতুন? অ্যাকাউন্ট খুলুন', haveAcc: 'অ্যাকাউন্ট আছে? লগ ইন করুন',
    search: 'মানুষ খুঁজুন', type: 'মেসেজ লিখুন…', online: 'অনলাইন', offline: 'অফলাইন', pick: 'চ্যাট শুরু করতে কাউকে বেছে নিন', logout: 'লগ আউট', admin: 'অ্যাডমিন প্যানেল', chat: 'চ্যাট',
    users: 'ইউজার', add: 'ইউজার যোগ', edit: 'এডিট', del: 'ডিলিট', save: 'সেভ', cancel: 'বাতিল', role: 'রোল', status: 'স্ট্যাটাস', active: 'সক্রিয়', inactive: 'নিষ্ক্রিয়', actions: 'অ্যাকশন',
    confirm: 'এই ইউজার ও তার মেসেজ ডিলিট করবেন?', incoming: 'আপনাকে কল করছে…', accept: 'ধরুন', reject: 'কেটে দিন', end: 'কল শেষ', calling: 'কল হচ্ছে…', video: 'ভিডিও', audio: 'অডিও',
    typing: 'লিখছে…', noUsers: 'কাউকে পাওয়া যায়নি', passHint: 'ফাঁকা রাখলে আগেরটাই থাকবে', total: 'মোট', camErr: 'ক্যামেরা/মাইক্রোফোনের অনুমতি দিন', empty: 'হ্যালো বলুন 👋' }
};
export const tr = (lang, k) => D[lang][k] || k;
