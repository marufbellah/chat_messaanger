import { useEffect, useRef, useState } from 'react';
import EmojiPicker from 'emoji-picker-react';
import { io } from 'socket.io-client';
import { api } from './api';
const ICE = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };
const Av = ({ u, on }) => <span className="av">{u.name[0].toUpperCase()}{on !== undefined && <b className={on ? 'dot on' : 'dot'} />}</span>;

export default function Chat({ t, me, theme }) {
  const [users, setUsers] = useState([]), [onl, setOnl] = useState([]), [sel, setSel] = useState(null), [msgs, setMsgs] = useState([]);
  const [text, setText] = useState(''), [emoji, setEmoji] = useState(false), [q, setQ] = useState(''), [unread, setUnread] = useState({}), [typing, setTyping] = useState(false);
  const [call, setCall] = useState(null);
  const sock = useRef(), selRef = useRef(), pc = useRef(), local = useRef(), lv = useRef(), rv = useRef(), queue = useRef([]), end = useRef(), file = useRef(), callRef = useRef();
  selRef.current = sel; callRef.current = call;

  const cleanup = () => { pc.current?.close(); pc.current = null; local.current?.getTracks().forEach(x => x.stop()); local.current = null; queue.current = []; setCall(null); };
  const setup = async (peer, video) => {
    const s = await navigator.mediaDevices.getUserMedia({ audio: true, video }); local.current = s;
    const p = new RTCPeerConnection(ICE); pc.current = p;
    s.getTracks().forEach(x => p.addTrack(x, s));
    p.onicecandidate = e => e.candidate && sock.current.emit('call:ice', { to: peer._id, c: e.candidate });
    p.ontrack = e => { if (rv.current) rv.current.srcObject = e.streams[0]; };
    if (lv.current) lv.current.srcObject = s;
    return p;
  };
  const flush = async () => { for (const c of queue.current) await pc.current.addIceCandidate(c); queue.current = []; };
  const start = async video => {
    setCall({ peer: sel, video, state: 'calling' });
    try { await new Promise(r => setTimeout(r)); const p = await setup(sel, video); const offer = await p.createOffer(); await p.setLocalDescription(offer); sock.current.emit('call:offer', { to: sel._id, offer, video }); }
    catch { alert(t('camErr')); cleanup(); }
  };
  const accept = async () => {
    const c = callRef.current; setCall({ ...c, state: 'active' });
    try { await new Promise(r => setTimeout(r)); const p = await setup(c.peer, c.video); await p.setRemoteDescription(c.offer); await flush(); const a = await p.createAnswer(); await p.setLocalDescription(a); sock.current.emit('call:answer', { to: c.peer._id, answer: a }); }
    catch { alert(t('camErr')); hang(); }
  };
  const hang = () => { const c = callRef.current; c && sock.current.emit('call:end', { to: c.peer._id }); cleanup(); };

  useEffect(() => {
    api('/users').then(d => { setUsers(d.users); setOnl(d.online); });
    const s = io({ auth: { token: localStorage.token } }); sock.current = s;
    s.on('presence', setOnl);
    s.on('msg', m => { if (selRef.current?._id === m.from) setMsgs(x => [...x, m]); else setUnread(x => ({ ...x, [m.from]: (x[m.from] || 0) + 1 })); });
    s.on('typing', d => { if (selRef.current?._id === d.from) { setTyping(true); clearTimeout(end.current); end.current = setTimeout(() => setTyping(false), 1500); } });
    s.on('call:offer', d => setUsers(us => { const peer = us.find(u => u._id === d.from); if (peer && !callRef.current) setCall({ peer, video: d.video, state: 'ringing', offer: d.offer }); return us; }));
    s.on('call:answer', async d => { await pc.current?.setRemoteDescription(d.answer); await flush(); setCall(c => c && { ...c, state: 'active' }); });
    s.on('call:ice', async d => { if (pc.current?.remoteDescription) pc.current.addIceCandidate(d.c); else queue.current.push(d.c); });
    s.on('call:end', cleanup);
    s.on('disconnect', r => { if (r === 'io server disconnect') { localStorage.removeItem('token'); location.reload(); } });
    s.on('connect_error', () => { localStorage.removeItem('token'); location.reload(); });
    return () => { s.disconnect(); cleanup(); };
  }, []);
  useEffect(() => { if (lv.current && local.current) lv.current.srcObject = local.current; }, [call?.state]);
  useEffect(() => { if (!sel) return; setMsgs([]); setUnread(x => ({ ...x, [sel._id]: 0 })); api('/messages/' + sel._id).then(setMsgs); }, [sel]);
  useEffect(() => { document.getElementById('end')?.scrollIntoView({ behavior: 'smooth' }); }, [msgs, typing]);

  const send = async (f) => {
    if (!text.trim() && !f) return;
    const fd = new FormData(); fd.append('to', sel._id); if (text.trim()) fd.append('text', text); if (f) fd.append('file', f);
    setText(''); setEmoji(false);
    try { const m = await api('/messages', { method: 'POST', form: fd }); setMsgs(x => [...x, m]); } catch (e) { alert(e.message); }
  };
  const shown = users.filter(u => u.name.toLowerCase().includes(q.toLowerCase()));
  const time = d => new Date(d).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const isOn = id => onl.includes(id);

  return (<div className={'chat ' + (sel ? 'open' : '')}>
    <aside className="list">
      <input className="search" placeholder={t('search')} value={q} onChange={e => setQ(e.target.value)} />
      {shown.map(u => <button key={u._id} className={'item ' + (sel?._id === u._id ? 'sel' : '')} onClick={() => setSel(u)}>
        <Av u={u} on={isOn(u._id)} /><span className="meta"><b>{u.name}</b><small>{isOn(u._id) ? t('online') : t('offline')}</small></span>
        {unread[u._id] > 0 && <em className="badge">{unread[u._id]}</em>}</button>)}
      {!shown.length && <p className="muted pad">{t('noUsers')}</p>}
    </aside>
    <section className="room">
      {!sel ? <div className="placeholder">💬<p>{t('pick')}</p></div> : <>
        <header className="rhead"><button className="ghost back" onClick={() => setSel(null)}>←</button><Av u={sel} on={isOn(sel._id)} />
          <span className="meta"><b>{sel.name}</b><small>{typing ? t('typing') : isOn(sel._id) ? t('online') : t('offline')}</small></span>
          <button className="ghost ic" title={t('audio')} disabled={!isOn(sel._id)} onClick={() => start(false)}>📞</button>
          <button className="ghost ic" title={t('video')} disabled={!isOn(sel._id)} onClick={() => start(true)}>🎥</button></header>
        <div className="msgs">{!msgs.length && <p className="muted center">{t('empty')}</p>}
          {msgs.map(m => <div key={m._id} className={'bub ' + (m.from === me._id ? 'me' : '')}>
            {m.type === 'image' && <img src={m.file} onClick={() => window.open(m.file)} />}
            {m.type === 'video' && <video src={m.file} controls />}{m.type === 'audio' && <audio src={m.file} controls />}
            {m.type === 'file' && <a href={m.file} target="_blank">📎 {m.file.split('/').pop()}</a>}
            {m.text && <p>{m.text}</p>}<small>{time(m.createdAt)}</small></div>)}<div id="end" /></div>
        {emoji && <div className="emoji"><EmojiPicker emojiStyle="native" theme={theme} width="100%" height={340} onEmojiClick={e => setText(x => x + e.emoji)} /></div>}
        <footer className="compose">
          <button className="ghost ic" onClick={() => setEmoji(!emoji)}>😊</button>
          <button className="ghost ic" onClick={() => file.current.click()}>📷</button>
          <input type="file" hidden ref={file} accept="image/*,video/*,audio/*,.pdf,.zip,.doc,.docx" onChange={e => { send(e.target.files[0]); e.target.value = ''; }} />
          <input value={text} placeholder={t('type')} onChange={e => { setText(e.target.value); sock.current.emit('typing', { to: sel._id }); }} onKeyDown={e => e.key === 'Enter' && send()} />
          <button className="btn send" onClick={() => send()}>➤</button></footer></>}
    </section>
    {call && <div className="overlay call"><div className="callbox">
      {call.state === 'ringing' ? <><Av u={call.peer} /><h3>{call.peer.name}</h3><p>{t('incoming')}</p>
        <div className="row"><button className="btn ok" onClick={accept}>{t('accept')}</button><button className="btn bad" onClick={hang}>{t('reject')}</button></div></> : <>
        <video ref={rv} autoPlay playsInline className="remote" /><video ref={lv} autoPlay playsInline muted className="selfv" />
        {call.state === 'calling' && <p className="calling">{t('calling')} {call.peer.name}</p>}
        <button className="btn bad endc" onClick={hang}>{t('end')}</button></>}
    </div></div>}
  </div>);
}
