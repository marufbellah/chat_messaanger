// End-to-end test: spawns the server on a fresh DB and exercises every API + socket feature.
// Run: MongoDB chalu rakhun, tarpor `npm test`
const { spawn } = require('child_process'), { io } = require('socket.io-client'), assert = require('assert');
const PORT = 5055, BASE = `http://localhost:${PORT}`, DB = 'bondhu_test_' + Date.now();
const env = { ...process.env, PORT, MONGO_URI: (process.env.MONGO_URI_BASE || 'mongodb://127.0.0.1:27017/') + DB, ADMIN_EMAIL: 'admin@t.com', ADMIN_PASSWORD: 'admin123', JWT_SECRET: 'test_secret', NODE_ENV: 'test' };
let pass = 0, fail = 0; const fails = [];
const test = async (name, fn) => { try { await fn(); pass++; console.log('  ✓', name); } catch (e) { fail++; fails.push(name); console.log('  ✗', name, '\n     ', e.message); } };
const api = async (method, url, { token, body, form } = {}) => {
  const h = {}; if (token) h.Authorization = 'Bearer ' + token; if (body) h['Content-Type'] = 'application/json';
  const r = await fetch(BASE + '/api' + url, { method, headers: h, body: form || (body && JSON.stringify(body)) });
  return { s: r.status, d: await r.json().catch(() => ({})) };
};
const png = () => new Blob([Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64')], { type: 'image/png' });
const fd = (o, file, name = 'a.png', blob = png()) => { const f = new FormData(); Object.entries(o).forEach(([k, v]) => f.append(k, v)); if (file !== false) f.append('file', blob, name); return f; };
const sock = token => new Promise((res, rej) => {
  const s = io(BASE, { auth: { token }, transports: ['websocket'], reconnection: false }); s.log = [];
  s.onAny((ev, d) => s.log.push([ev, d]));
  s.waitFor = (ev, pred = () => true, ms = 3000) => new Promise((ok, no) => { const t0 = Date.now(), iv = setInterval(() => { const h = s.log.find(([e, d]) => e === ev && pred(d)); if (h) { clearInterval(iv); ok(h[1]); } else if (Date.now() - t0 > ms) { clearInterval(iv); no(new Error('timeout waiting for ' + ev)); } }, 20); });
  s.on('connect', () => res(s)); s.on('connect_error', rej);
});
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const srv = spawn('node', ['index.js'], { env, cwd: __dirname + '/..' }); let out = ''; srv.stdout.on('data', d => out += d); srv.stderr.on('data', d => out += d);
  for (let i = 0; i < 60; i++) { try { if ((await fetch(BASE + '/api/health')).ok) break; } catch {} await sleep(250); }
  const T = {}; let A, B, C, ga, gb; // tokens / users
  console.log('\nHealth & Auth');
  await test('health endpoint + db connected', async () => { const r = await api('GET', '/health'); assert(r.s === 200 && r.d.db === true); });
  await test('register rejects bad input', async () => { assert.equal((await api('POST', '/auth/register', { body: { name: '', email: 'x', password: '1' } })).s, 400); });
  for (const n of ['alice', 'bob', 'carol']) await test('register ' + n, async () => { const r = await api('POST', '/auth/register', { body: { name: n, email: n + '@t.com', password: 'secret1' } }); assert.equal(r.s, 200); T[n] = r.d.token; T[n + 'Id'] = r.d.user._id; assert.equal(r.d.user.role, 'user'); assert(!r.d.user.password); });
  await test('duplicate email -> 409', async () => assert.equal((await api('POST', '/auth/register', { body: { name: 'a', email: 'ALICE@t.com', password: 'secret1' } })).s, 409));
  await test('login ok / wrong password -> 400', async () => { assert.equal((await api('POST', '/auth/login', { body: { email: 'alice@t.com', password: 'secret1' } })).s, 200); assert.equal((await api('POST', '/auth/login', { body: { email: 'alice@t.com', password: 'nope' } })).s, 400); });
  await test('admin seeded and can login', async () => { const r = await api('POST', '/auth/login', { body: { email: 'admin@t.com', password: 'admin123' } }); assert.equal(r.d.user.role, 'admin'); T.admin = r.d.token; T.adminId = r.d.user._id; });
  await test('protected route without/with bad token -> 401', async () => { assert.equal((await api('GET', '/me')).s, 401); assert.equal((await api('GET', '/me', { token: 'junk' })).s, 401); });

  console.log('\nProfile');
  await test('GET/PUT /me', async () => { assert.equal((await api('GET', '/me', { token: T.alice })).d.email, 'alice@t.com'); assert.equal((await api('PUT', '/me', { token: T.alice, body: { name: 'Alice W' } })).d.name, 'Alice W'); });
  await test('change password (wrong current rejected, then ok)', async () => {
    assert.equal((await api('PUT', '/me/password', { token: T.alice, body: { current: 'bad', password: 'newpass1' } })).s, 400);
    assert.equal((await api('PUT', '/me/password', { token: T.alice, body: { current: 'secret1', password: 'newpass1' } })).s, 200);
    assert.equal((await api('POST', '/auth/login', { body: { email: 'alice@t.com', password: 'newpass1' } })).s, 200); });
  await test('avatar upload ok, svg rejected', async () => { const r = await api('POST', '/me/avatar', { token: T.alice, form: fd({}, true) }); assert.equal(r.s, 200); assert(r.d.avatar.startsWith('/uploads/')); assert.equal((await fetch(BASE + r.d.avatar)).status, 200);
    assert.equal((await api('POST', '/me/avatar', { token: T.alice, form: fd({}, true, 'x.svg', new Blob(['<svg/>'], { type: 'image/svg+xml' })) })).s, 400); });

  console.log('\nAdmin');
  await test('normal user blocked from admin routes (403)', async () => assert.equal((await api('GET', '/admin/users', { token: T.alice })).s, 403));
  await test('admin create user', async () => { const r = await api('POST', '/admin/users', { token: T.admin, body: { name: 'Dave', email: 'dave@t.com', password: 'secret1', role: 'user', active: true } }); assert.equal(r.s, 200); T.daveId = r.d._id; });
  await test('admin list + search', async () => { const a = await api('GET', '/admin/users', { token: T.admin }); assert(a.d.length >= 5); const q = await api('GET', '/admin/users?q=dav', { token: T.admin }); assert.equal(q.d.length, 1); });
  await test('admin update user (rename, role)', async () => { const r = await api('PUT', '/admin/users/' + T.daveId, { token: T.admin, body: { name: 'David', role: 'admin' } }); assert(r.d.name === 'David' && r.d.role === 'admin'); await api('PUT', '/admin/users/' + T.daveId, { token: T.admin, body: { role: 'user' } }); });
  await test('admin cannot demote/deactivate/delete self', async () => { for (const [m, b] of [['PUT', { role: 'user' }], ['PUT', { active: false }], ['DELETE']]) assert.equal((await api(m, '/admin/users/' + T.adminId, { token: T.admin, body: b })).s, 400); });
  await test('invalid id -> 400, unknown api -> 404', async () => { assert.equal((await api('PUT', '/admin/users/xyz', { token: T.admin, body: {} })).s, 400); assert.equal((await api('GET', '/nothing', { token: T.admin })).s, 404); });

  console.log('\nDirect chat (REST + realtime)');
  const sa = await sock(T.alice), sb = await sock(T.bob);
  await test('presence shows both online', async () => { const r = await api('GET', '/users', { token: T.alice }); assert(r.d.online.includes(T.bobId)); assert(!r.d.users.find(u => u._id === T.aliceId)); });
  let m1;
  await test('send text -> bob receives via socket', async () => { const r = await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId, text: 'hello bob' }, false) }); assert.equal(r.s, 200); m1 = r.d; assert(m1.deliveredAt); const got = await sb.waitFor('msg', d => d._id === m1._id); assert.equal(got.text, 'hello bob'); });
  await test('cannot message self / unknown user / empty', async () => { assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.aliceId, text: 'x' }, false) })).s, 400); assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: '5f0000000000000000000000', text: 'x' }, false) })).s, 404); assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, false) })).s, 400); });
  await test('send image + audio + disallowed exe', async () => {
    const i = await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, true) }); assert.equal(i.d.type, 'image'); assert.equal((await fetch(BASE + i.d.file)).status, 200);
    const a = await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, true, 'v.webm', new Blob(['x'], { type: 'audio/webm' })) }); assert.equal(a.d.type, 'audio');
    assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, true, 'x.exe', new Blob(['MZ'], { type: 'application/x-msdownload' })) })).s, 400); });
  await test('oversize file (>25MB) rejected', async () => assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId }, true, 'big.mp4', new Blob([Buffer.alloc(26 * 1024 * 1024)], { type: 'video/mp4' })) })).s, 400));
  await test('history + pagination', async () => { const all = (await api('GET', '/messages/' + T.bobId, { token: T.alice })).d; assert.equal(all.length, 3); assert.equal(all[0]._id, m1._id); const p = (await api('GET', `/messages/${T.bobId}?limit=1`, { token: T.alice })).d; assert.equal(p.length, 1); const b = (await api('GET', `/messages/${T.bobId}?before=${all[2].createdAt}`, { token: T.alice })).d; assert.equal(b.length, 2); });
  await test('conversations: last message + unread for bob', async () => { const r = (await api('GET', '/conversations', { token: T.bob })).d; assert.equal(r.unread.find(u => u._id === T.aliceId).n, 3); assert.equal(r.last.length, 1); });
  await test('mark read -> alice gets read event, unread cleared', async () => { await api('POST', '/messages/read/' + T.aliceId, { token: T.bob }); await sa.waitFor('read', d => d.by === T.bobId); assert.equal((await api('GET', '/conversations', { token: T.bob })).d.unread.length, 0); });
  await test('typing indicator', async () => { sa.emit('typing', { to: T.bobId }); await sb.waitFor('typing', d => d.from === T.aliceId); });
  await test('edit own message (bob sees msg:edit); cannot edit others', async () => { const r = await api('PUT', '/messages/' + m1._id, { token: T.alice, body: { text: 'hello edited' } }); assert(r.d.edited); await sb.waitFor('msg:edit', d => d.text === 'hello edited'); assert.equal((await api('PUT', '/messages/' + m1._id, { token: T.bob, body: { text: 'hack' } })).s, 404); });
  await test('delete own message (soft, bob notified); cannot delete others', async () => { assert.equal((await api('DELETE', '/messages/' + m1._id, { token: T.bob })).s, 404); assert.equal((await api('DELETE', '/messages/' + m1._id, { token: T.alice })).s, 200); await sb.waitFor('msg:delete', d => d._id === m1._id); const h = (await api('GET', '/messages/' + T.bobId, { token: T.alice })).d; assert(h.find(m => m._id === m1._id).deleted); });
  await test('offline user: message marked delivered on connect', async () => { const r = await api('POST', '/messages', { token: T.alice, form: fd({ to: T.carolId, text: 'hi carol' }, false) }); assert(!r.d.deliveredAt); const sc = await sock(T.carol); await sleep(300); const h = (await api('GET', '/messages/' + T.aliceId, { token: T.carol })).d; assert(h[0].deliveredAt); sc.close(); });

  console.log('\nGroups');
  await test('create group (alice + bob; unknown member ignored)', async () => { const r = await api('POST', '/groups', { token: T.alice, body: { name: 'Team', members: [T.bobId, 'bad', '5f0000000000000000000000'] } }); assert.equal(r.s, 200); assert.equal(r.d.members.length, 2); ga = r.d._id; await sb.waitFor('group:update'); });
  await test('list groups (member only)', async () => { assert.equal((await api('GET', '/groups', { token: T.bob })).d.length, 1); assert.equal((await api('GET', '/groups', { token: T.carol })).d.length, 0); });
  await test('group message -> bob receives, alice (sender) does not echo, carol blocked', async () => {
    const r = await api('POST', `/groups/${ga}/messages`, { token: T.alice, form: fd({ text: 'team hello' }, false) }); assert.equal(r.s, 200); const g = await sb.waitFor('msg', d => d.group === ga); assert.equal(g.text, 'team hello');
    await sleep(150); assert(!sa.log.find(([e, d]) => e === 'msg' && d.group === ga));
    assert.equal((await api('GET', `/groups/${ga}/messages`, { token: T.carol })).s, 404); assert.equal((await api('POST', `/groups/${ga}/messages`, { token: T.carol, form: fd({ text: 'x' }, false) })).s, 404); assert.equal((await api('GET', `/groups/${ga}/messages`, { token: T.bob })).d.length, 1); });
  await test('group file message + typing', async () => { assert.equal((await api('POST', `/groups/${ga}/messages`, { token: T.bob, form: fd({}, true) })).d.type, 'image'); sb.emit('typing', { group: ga }); await sa.waitFor('typing', d => d.group === ga); });
  await test('owner adds carol live; carol receives; non-owner cannot edit', async () => { const sc = await sock(T.carol); assert.equal((await api('PUT', '/groups/' + ga, { token: T.bob, body: { name: 'x' } })).s, 403); const r = await api('PUT', '/groups/' + ga, { token: T.alice, body: { add: [T.carolId], name: 'Team A' } }); assert.equal(r.d.members.length, 3); await api('POST', `/groups/${ga}/messages`, { token: T.alice, form: fd({ text: 'welcome' }, false) }); await sc.waitFor('msg', d => d.group === ga && d.text === 'welcome'); sc.close(); });
  await test('remove member: bob stops receiving', async () => { await api('PUT', '/groups/' + ga, { token: T.alice, body: { remove: [T.bobId] } }); const n = sb.log.length; await api('POST', `/groups/${ga}/messages`, { token: T.alice, form: fd({ text: 'after remove' }, false) }); await sleep(300); assert(!sb.log.slice(n).find(([e, d]) => e === 'msg' && d.text === 'after remove')); });
  await test('leave group / owner cannot leave', async () => { assert.equal((await api('POST', `/groups/${ga}/leave`, { token: T.alice })).s, 400); assert.equal((await api('POST', `/groups/${ga}/leave`, { token: T.carol })).s, 200); });
  await test('delete group (owner) removes messages', async () => { assert.equal((await api('DELETE', '/groups/' + ga, { token: T.alice })).s, 200); assert.equal((await api('GET', '/groups', { token: T.alice })).d.length, 0); });

  console.log('\nCalls (WebRTC signaling + log)');
  await test('offer -> answer -> ice -> end relayed, call logged with duration', async () => {
    sa.emit('call:offer', { to: T.bobId, offer: { sdp: 'x', type: 'offer' }, video: true }); const o = await sb.waitFor('call:offer'); assert.equal(o.from, T.aliceId);
    await sleep(100); sb.emit('call:answer', { to: T.aliceId, answer: { sdp: 'y', type: 'answer' } }); await sa.waitFor('call:answer');
    sa.emit('call:ice', { to: T.bobId, c: { candidate: 'c' } }); await sb.waitFor('call:ice'); await sleep(1100); sa.emit('call:end', { to: T.bobId }); await sb.waitFor('call:end'); await sleep(200);
    const c = (await api('GET', '/calls', { token: T.alice })).d[0]; assert(c.status === 'ended' && c.duration >= 1 && c.video === true); });
  await test('declined call + missed call (offline target)', async () => {
    sa.emit('call:offer', { to: T.bobId, offer: {}, video: false }); await sb.waitFor('call:offer', () => true); await sleep(100); sb.emit('call:end', { to: T.aliceId }); await sleep(250);
    assert.equal((await api('GET', '/calls', { token: T.alice })).d[0].status, 'declined');
    sa.log.length = 0; sa.emit('call:offer', { to: T.carolId, offer: {}, video: false }); await sa.waitFor('call:end'); await sleep(200); assert.equal((await api('GET', '/calls', { token: T.alice })).d[0].status, 'missed'); });

  console.log('\nAdmin controls on live users');
  await test('stats reflect data', async () => { const s = (await api('GET', '/admin/stats', { token: T.admin })).d; assert(s.users.total >= 5 && s.messages.total > 0 && s.calls >= 3 && s.online >= 2); });
  await test('admin deletes a message (moderation)', async () => { const h = (await api('GET', '/messages/' + T.bobId, { token: T.alice })).d; const m = h.find(x => x.type === 'image' && !x.deleted); assert.equal((await api('DELETE', '/admin/messages/' + m._id, { token: T.admin })).s, 200); });
  await test('deactivate bob: socket kicked, API 401, login 403, hidden from user list', async () => {
    const dis = new Promise(r => sb.on('disconnect', r)); assert.equal((await api('PUT', '/admin/users/' + T.bobId, { token: T.admin, body: { active: false } })).s, 200); await Promise.race([dis, sleep(2000).then(() => { throw new Error('socket not kicked'); })]);
    assert.equal((await api('GET', '/me', { token: T.bob })).s, 401); assert.equal((await api('POST', '/auth/login', { body: { email: 'bob@t.com', password: 'secret1' } })).s, 403); assert(!(await api('GET', '/users', { token: T.alice })).d.users.find(u => u._id === T.bobId));
    assert.equal((await api('POST', '/messages', { token: T.alice, form: fd({ to: T.bobId, text: 'x' }, false) })).s, 404); });
  await test('reactivate bob works again', async () => { await api('PUT', '/admin/users/' + T.bobId, { token: T.admin, body: { active: true } }); assert.equal((await api('POST', '/auth/login', { body: { email: 'bob@t.com', password: 'secret1' } })).s, 200); });
  await test('admin deletes carol: account, messages, owned groups gone', async () => { const g = (await api('POST', '/groups', { token: T.carol, body: { name: 'CG', members: [T.aliceId] } })).d._id; assert.equal((await api('DELETE', '/admin/users/' + T.carolId, { token: T.admin })).s, 200); assert.equal((await api('GET', '/me', { token: T.carol })).s, 401); assert.equal((await api('GET', '/groups', { token: T.alice })).d.find(x => x._id === g), undefined); assert.equal((await api('GET', '/messages/' + T.carolId, { token: T.alice })).d.length, 0); });
  await test('audit log recorded admin actions (password masked)', async () => { const l = (await api('GET', '/admin/logs', { token: T.admin })).d; const acts = l.map(x => x.action); assert(['user.create', 'user.update', 'user.delete', 'message.delete'].every(a => acts.includes(a))); assert(!JSON.stringify(l).includes('$2')); });
  await test('socket rejects invalid token', async () => { await assert.rejects(sock('bad')); });

  console.log('\nSecurity headers & limits');
  await test('helmet headers present', async () => { const r = await fetch(BASE + '/api/health'); assert.equal(r.headers.get('x-content-type-options'), 'nosniff'); assert(!r.headers.get('x-powered-by')); });
  await test('login rate limit kicks in (429)', async () => { let last; for (let i = 0; i < 40; i++) last = (await api('POST', '/auth/login', { body: { email: 'x@t.com', password: 'y' } })).s; assert.equal(last, 429); });

  [sa, sb].forEach(s => s.close()); srv.kill('SIGTERM'); await sleep(500);
  const { MongoClient } = (() => { try { return require('mongoose').mongo; } catch { return {}; } })(); try { const c = await require('mongoose').createConnection(env.MONGO_URI).asPromise(); await c.dropDatabase(); await c.close(); } catch {}
  console.log(`\n${pass} passed, ${fail} failed`); if (fail) { console.log('Failed:', fails.join(' | ')); console.log(out.slice(-1500)); } process.exit(fail ? 1 : 0);
})();
