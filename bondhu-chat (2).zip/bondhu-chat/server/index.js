require('dotenv').config();
const express = require('express'), http = require('http'), mongoose = require('mongoose'), cors = require('cors');
const helmet = require('helmet'), morgan = require('morgan'), rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken'), bcrypt = require('bcryptjs'), multer = require('multer'), path = require('path'), fs = require('fs');
const { Server } = require('socket.io');

const { PORT = 5000, MONGO_URI = 'mongodb://127.0.0.1:27017/bondhu', JWT_SECRET, CLIENT_URL = '*', NODE_ENV } = process.env;
if (NODE_ENV === 'production' && (!JWT_SECRET || JWT_SECRET === 'change_me')) { console.error('Set a strong JWT_SECRET'); process.exit(1); }
const SECRET = JWT_SECRET || 'dev_secret', origin = CLIENT_URL === '*' ? '*' : CLIENT_URL.split(',');
const app = express(), server = http.createServer(app), io = new Server(server, { cors: { origin } });
const UP = path.join(__dirname, 'uploads'); fs.mkdirSync(UP, { recursive: true });
app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }), cors({ origin }), express.json({ limit: '100kb' }), morgan(NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use('/uploads', express.static(UP));
app.use('/api', rateLimit({ windowMs: 60e3, max: 300 }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60e3, max: 30, message: { error: 'Too many attempts, try later' } }));

// ---------- Models ----------
const { ObjectId } = mongoose.Schema.Types, ref = r => ({ type: ObjectId, ref: r });
const mk = (n, def, idx) => { const s = new mongoose.Schema(def, { timestamps: true }); idx && s.index(idx); return mongoose.model(n, s); };
const User = mk('User', { name: { type: String, trim: true, required: true, maxlength: 60 }, email: { type: String, unique: true, lowercase: true, trim: true, required: true }, password: { type: String, required: true },
  avatar: String, role: { type: String, enum: ['user', 'admin'], default: 'user' }, active: { type: Boolean, default: true }, lastSeen: Date });
const Group = mk('Group', { name: { type: String, trim: true, required: true, maxlength: 60 }, owner: ref('User'), members: [ref('User')] });
const Msg = mk('Msg', { from: ref('User'), to: ref('User'), group: ref('Group'), text: { type: String, maxlength: 5000 }, file: String, type: { type: String, default: 'text' },
  replyTo: ref('Msg'), edited: Boolean, deleted: Boolean, deliveredAt: Date, readAt: Date }, { from: 1, to: 1, createdAt: -1 });
Msg.schema.index({ group: 1, createdAt: -1 });
const Call = mk('Call', { from: ref('User'), to: ref('User'), video: Boolean, status: { type: String, default: 'ringing' }, answeredAt: Date, endedAt: Date, duration: Number });
const Audit = mk('Audit', { admin: ref('User'), action: String, target: String, meta: Object });

// ---------- Helpers ----------
const E = (status, message) => Object.assign(new Error(message), { status });
const ok = id => mongoose.isValidObjectId(id), esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const safe = u => ({ _id: u._id, name: u.name, email: u.email, avatar: u.avatar, role: u.role, active: u.active, lastSeen: u.lastSeen, createdAt: u.createdAt });
const sign = u => jwt.sign({ id: u._id }, SECRET, { expiresIn: '7d' });
const wrap = fn => (req, res, next) => fn(req, res, next).catch(e => next(e.code === 11000 ? E(409, 'Email already exists') : e));
const online = () => [...io.sockets.adapter.rooms.keys()].filter(k => /^[a-f0-9]{24}$/.test(k));
const roomOf = m => m.group ? 'g:' + m.group : String(m.to);
const audit = (req, action, target, meta) => Audit.create({ admin: req.user._id, action, target: String(target), meta }).catch(() => {});
app.param('id', (req, res, next, v) => ok(v) ? next() : res.status(400).json({ error: 'Invalid id' }));
const auth = wrap(async (req, res, next) => {
  let id; try { id = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET).id; } catch { throw E(401, 'Unauthorized'); }
  const u = await User.findById(id); if (!u || !u.active) throw E(401, 'Unauthorized or inactive');
  req.user = u; next();
});
const admin = (req, res, next) => req.user.role === 'admin' ? next() : next(E(403, 'Admin only'));
const storage = multer.diskStorage({ destination: UP, filename: (r, f, cb) => cb(null, Date.now() + '-' + Math.round(Math.random() * 1e6) + path.extname(f.originalname).toLowerCase().replace(/[^.a-z0-9]/g, '')) });
const uploader = (re, mb) => multer({ storage, limits: { fileSize: mb * 1024 * 1024 }, fileFilter: (r, f, cb) => re.test(f.mimetype) ? cb(null, true) : cb(E(400, 'File type not allowed')) });
const upMsg = uploader(/^(image\/(?!svg)|audio\/|video\/|application\/(pdf|zip|msword|vnd\.openxmlformats))/, 25), upImg = uploader(/^image\/(?!svg)/, 3);
const softDelete = async m => { if (m.file) fs.unlink(path.join(UP, path.basename(m.file)), () => {}); Object.assign(m, { deleted: true, text: '', file: undefined }); await m.save(); io.to(roomOf(m)).emit('msg:delete', { _id: m._id }); };
const sendMsg = async (req, res, { to, group }) => {
  const text = (req.body.text || '').trim(); let type = 'text', file;
  if (req.file) { file = '/uploads/' + req.file.filename; const m = req.file.mimetype; type = m.startsWith('image') ? 'image' : m.startsWith('audio') ? 'audio' : m.startsWith('video') ? 'video' : 'file'; }
  if (!text && !file) throw E(400, 'Empty message');
  const m = await Msg.create({ from: req.user._id, to, group, text, file, type, replyTo: ok(req.body.replyTo) ? req.body.replyTo : undefined, deliveredAt: to && online().includes(String(to)) ? new Date() : undefined });
  group ? io.to('g:' + group).except(String(req.user._id)).emit('msg', m) : io.to(String(to)).emit('msg', m);
  res.json(m);
};
const myGroup = async req => (await Group.findOne({ _id: req.params.id, members: req.user._id })) || (() => { throw E(404, 'Group not found'); })();
const joinAll = (members, gid, leave) => members.forEach(u => io.in(String(u))[leave ? 'socketsLeave' : 'socketsJoin']('g:' + gid));

// ---------- Health / Auth / Profile ----------
app.get('/api/health', (req, res) => res.json({ ok: true, db: mongoose.connection.readyState === 1, uptime: process.uptime() }));
app.post('/api/auth/register', wrap(async (req, res) => {
  const { name, email, password } = req.body;
  if (!name?.trim() || !EMAIL.test(email || '') || (password || '').length < 6) throw E(400, 'Valid name, email and 6+ char password required');
  const u = await User.create({ name, email, password: await bcrypt.hash(password, 10) });
  res.json({ token: sign(u), user: safe(u) });
}));
app.post('/api/auth/login', wrap(async (req, res) => {
  const u = await User.findOne({ email: String(req.body.email || '').toLowerCase() });
  if (!u || !(await bcrypt.compare(String(req.body.password || ''), u.password))) throw E(400, 'Wrong email or password');
  if (!u.active) throw E(403, 'Account is inactive');
  res.json({ token: sign(u), user: safe(u) });
}));
app.get('/api/me', auth, (req, res) => res.json(safe(req.user)));
app.put('/api/me', auth, wrap(async (req, res) => { if (req.body.name?.trim()) req.user.name = req.body.name; await req.user.save(); res.json(safe(req.user)); }));
app.put('/api/me/password', auth, wrap(async (req, res) => {
  const { current, password } = req.body;
  if (!(await bcrypt.compare(String(current || ''), req.user.password)) || (password || '').length < 6) throw E(400, 'Wrong current password or new one too short');
  req.user.password = await bcrypt.hash(password, 10); await req.user.save(); res.json({ ok: true });
}));
app.post('/api/me/avatar', auth, upImg.single('file'), wrap(async (req, res) => { if (!req.file) throw E(400, 'Image required'); req.user.avatar = '/uploads/' + req.file.filename; await req.user.save(); res.json(safe(req.user)); }));

// ---------- Direct chat ----------
app.get('/api/users', auth, wrap(async (req, res) => {
  const list = await User.find({ active: true, _id: { $ne: req.user._id } }).sort('name');
  res.json({ users: list.map(safe), online: online() });
}));
app.get('/api/conversations', auth, wrap(async (req, res) => {
  const me = req.user._id;
  const last = await Msg.aggregate([{ $match: { group: { $exists: false }, $or: [{ from: me }, { to: me }] } }, { $sort: { createdAt: -1 } },
    { $group: { _id: { $cond: [{ $eq: ['$from', me] }, '$to', '$from'] }, last: { $first: '$$ROOT' } } }]);
  const unread = await Msg.aggregate([{ $match: { to: me, readAt: { $exists: false } } }, { $group: { _id: '$from', n: { $sum: 1 } } }]);
  res.json({ last, unread });
}));
app.get('/api/messages/:id', auth, wrap(async (req, res) => {
  const me = req.user._id, o = req.params.id, q = { $or: [{ from: me, to: o }, { from: o, to: me }] };
  if (req.query.before) q.createdAt = { $lt: new Date(req.query.before) };
  res.json((await Msg.find(q).sort('-createdAt').limit(Math.min(+req.query.limit || 50, 100))).reverse());
}));
app.post('/api/messages', auth, upMsg.single('file'), wrap(async (req, res) => {
  const { to } = req.body;
  if (String(to) === String(req.user._id)) throw E(400, "Can't message yourself");
  if (!ok(to) || !(await User.exists({ _id: to, active: true }))) throw E(404, 'User not found');
  await sendMsg(req, res, { to });
}));
app.post('/api/messages/read/:id', auth, wrap(async (req, res) => {
  const now = new Date(), r = await Msg.updateMany({ from: req.params.id, to: req.user._id, readAt: { $exists: false } }, { readAt: now, deliveredAt: now });
  io.to(req.params.id).emit('read', { by: String(req.user._id), at: now }); res.json({ updated: r.modifiedCount });
}));
app.put('/api/messages/:id', auth, wrap(async (req, res) => {
  const m = await Msg.findOne({ _id: req.params.id, from: req.user._id, deleted: { $ne: true } }); if (!m) throw E(404, 'Message not found');
  if (!req.body.text?.trim()) throw E(400, 'Empty message');
  m.text = req.body.text.trim(); m.edited = true; await m.save(); io.to(roomOf(m)).emit('msg:edit', m); res.json(m);
}));
app.delete('/api/messages/:id', auth, wrap(async (req, res) => {
  const m = await Msg.findOne({ _id: req.params.id, from: req.user._id }); if (!m) throw E(404, 'Message not found');
  await softDelete(m); res.json({ ok: true });
}));
app.get('/api/calls', auth, wrap(async (req, res) => res.json(await Call.find({ $or: [{ from: req.user._id }, { to: req.user._id }] }).sort('-createdAt').limit(50).populate('from to', 'name avatar'))));

// ---------- Groups ----------
const activeIds = async ids => (await User.find({ _id: { $in: (ids || []).filter(ok) }, active: true }).select('_id')).map(u => String(u._id));
app.post('/api/groups', auth, wrap(async (req, res) => {
  if (!req.body.name?.trim()) throw E(400, 'Group name required');
  const members = [...new Set([String(req.user._id), ...(await activeIds(req.body.members))])];
  const g = await Group.create({ name: req.body.name, owner: req.user._id, members });
  joinAll(members, g._id); members.forEach(u => io.to(u).emit('group:update', g)); res.json(g);
}));
app.get('/api/groups', auth, wrap(async (req, res) => res.json(await Group.find({ members: req.user._id }).populate('members', 'name avatar').sort('-updatedAt'))));
app.put('/api/groups/:id', auth, wrap(async (req, res) => {
  const g = await myGroup(req); if (String(g.owner) !== String(req.user._id)) throw E(403, 'Only the owner can edit');
  if (req.body.name?.trim()) g.name = req.body.name;
  const add = await activeIds(req.body.add), rem = (req.body.remove || []).filter(x => ok(x) && String(x) !== String(g.owner));
  g.members = [...new Set([...g.members.map(String).filter(x => !rem.includes(x)), ...add])];
  await g.save(); joinAll(add, g._id); joinAll(rem, g._id, true); [...g.members, ...rem].forEach(u => io.to(String(u)).emit('group:update', g)); res.json(g);
}));
app.post('/api/groups/:id/leave', auth, wrap(async (req, res) => {
  const g = await myGroup(req); if (String(g.owner) === String(req.user._id)) throw E(400, 'Owner must delete the group');
  g.members.pull(req.user._id); await g.save(); joinAll([req.user._id], g._id, true); res.json({ ok: true });
}));
app.delete('/api/groups/:id', auth, wrap(async (req, res) => {
  const g = await myGroup(req); if (String(g.owner) !== String(req.user._id) && req.user.role !== 'admin') throw E(403, 'Only the owner can delete');
  await Msg.deleteMany({ group: g._id }); await g.deleteOne(); joinAll(g.members, g._id, true); res.json({ ok: true });
}));
app.get('/api/groups/:id/messages', auth, wrap(async (req, res) => {
  await myGroup(req); const q = { group: req.params.id }; if (req.query.before) q.createdAt = { $lt: new Date(req.query.before) };
  res.json((await Msg.find(q).sort('-createdAt').limit(Math.min(+req.query.limit || 50, 100))).reverse());
}));
app.post('/api/groups/:id/messages', auth, upMsg.single('file'), wrap(async (req, res) => { await myGroup(req); await sendMsg(req, res, { group: req.params.id }); }));

// ---------- Admin ----------
app.use('/api/admin', auth, admin);
app.get('/api/admin/stats', wrap(async (req, res) => {
  const day = new Date(); day.setHours(0, 0, 0, 0);
  const [total, active, admins, msgs, today, groups, calls] = await Promise.all([User.countDocuments(), User.countDocuments({ active: true }), User.countDocuments({ role: 'admin' }),
    Msg.countDocuments(), Msg.countDocuments({ createdAt: { $gte: day } }), Group.countDocuments(), Call.countDocuments()]);
  res.json({ users: { total, active, inactive: total - active, admins }, online: online().length, messages: { total: msgs, today }, groups, calls });
}));
app.get('/api/admin/users', wrap(async (req, res) => {
  const q = req.query.q ? { $or: ['name', 'email'].map(k => ({ [k]: new RegExp(esc(String(req.query.q)), 'i') })) } : {};
  res.json((await User.find(q).sort('-createdAt').limit(500)).map(safe));
}));
app.post('/api/admin/users', wrap(async (req, res) => {
  const { name, email, password, role, active } = req.body;
  if (!name?.trim() || !EMAIL.test(email || '') || (password && password.length < 6)) throw E(400, 'Invalid data');
  const u = await User.create({ name, email, role, active, password: await bcrypt.hash(password || '123456', 10) });
  audit(req, 'user.create', u._id, { email }); res.json(safe(u));
}));
app.put('/api/admin/users/:id', wrap(async (req, res) => {
  const { name, email, password, role, active } = req.body, up = { name, email, role, active };
  if (String(req.user._id) === req.params.id && (role === 'user' || active === false)) throw E(400, "You can't demote or deactivate yourself");
  if (email && !EMAIL.test(email)) throw E(400, 'Invalid email');
  if (password) { if (password.length < 6) throw E(400, 'Password too short'); up.password = await bcrypt.hash(password, 10); }
  Object.keys(up).forEach(k => up[k] === undefined && delete up[k]);
  const u = await User.findByIdAndUpdate(req.params.id, up, { new: true, runValidators: true }); if (!u) throw E(404, 'User not found');
  if (!u.active) io.in(String(u._id)).disconnectSockets(true);
  audit(req, 'user.update', u._id, { ...up, password: up.password ? '***' : undefined }); res.json(safe(u));
}));
app.delete('/api/admin/users/:id', wrap(async (req, res) => {
  const id = req.params.id; if (String(req.user._id) === id) throw E(400, "You can't delete yourself");
  const u = await User.findByIdAndDelete(id); if (!u) throw E(404, 'User not found');
  for (const g of await Group.find({ owner: id })) { await Msg.deleteMany({ group: g._id }); joinAll(g.members, g._id, true); await g.deleteOne(); }
  await Group.updateMany({ members: id }, { $pull: { members: id } });
  await Msg.deleteMany({ $or: [{ from: id }, { to: id }] }); io.in(id).disconnectSockets(true);
  audit(req, 'user.delete', id, { email: u.email }); res.json({ ok: true });
}));
app.delete('/api/admin/messages/:id', wrap(async (req, res) => { const m = await Msg.findById(req.params.id); if (!m) throw E(404, 'Not found'); await softDelete(m); audit(req, 'message.delete', m._id); res.json({ ok: true }); }));
app.get('/api/admin/logs', wrap(async (req, res) => res.json(await Audit.find().sort('-createdAt').limit(100).populate('admin', 'name email'))));

// ---------- 404 / errors ----------
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use((e, req, res, next) => { if (!e.status && e.name !== 'MulterError') console.error(e); res.status(e.status || (e.name === 'MulterError' ? 400 : 500)).json({ error: e.status || e.name === 'MulterError' ? e.message : 'Server error' }); });

// ---------- Socket: auth, presence, typing, WebRTC signaling + call log ----------
io.use(async (s, next) => {
  try { const { id } = jwt.verify(s.handshake.auth.token, SECRET); const u = await User.findById(id); if (!u || !u.active) throw 0; s.uid = String(id); next(); }
  catch { next(new Error('unauthorized')); }
});
const live = new Map(), pk = (a, b) => [a, b].sort().join(':');
io.on('connection', async s => {
  s.join(s.uid);
  s.join((await Group.find({ members: s.uid }).select('_id')).map(g => 'g:' + g._id));
  Msg.updateMany({ to: s.uid, deliveredAt: { $exists: false } }, { deliveredAt: new Date() }).catch(() => {});
  io.emit('presence', online());
  s.on('typing', d => {
    if (d?.group && s.rooms.has('g:' + d.group)) io.to('g:' + d.group).except(s.uid).emit('typing', { from: s.uid, group: d.group });
    else if (ok(d?.to)) io.to(d.to).emit('typing', { from: s.uid });
  });
  const relay = (ev, d) => io.to(d.to).emit(ev, { ...d, from: s.uid });
  s.on('call:offer', d => {
    if (!ok(d?.to) || d.to === s.uid) return;
    if (!online().includes(d.to)) { Call.create({ from: s.uid, to: d.to, video: !!d.video, status: 'missed', endedAt: new Date() }).catch(() => {}); return s.emit('call:end', { from: d.to }); }
    relay('call:offer', d); Call.create({ from: s.uid, to: d.to, video: !!d.video }).then(c => live.set(pk(s.uid, d.to), c._id)).catch(() => {});
  });
  s.on('call:answer', d => { if (!ok(d?.to)) return; relay('call:answer', d); Call.findByIdAndUpdate(live.get(pk(s.uid, d.to)), { status: 'answered', answeredAt: new Date() }).catch(() => {}); });
  s.on('call:ice', d => ok(d?.to) && relay('call:ice', d));
  s.on('call:end', async d => {
    if (!ok(d?.to)) return; relay('call:end', d);
    const k = pk(s.uid, d.to), id = live.get(k); live.delete(k); const c = id && await Call.findById(id); if (!c) return;
    c.endedAt = new Date();
    if (c.answeredAt) { c.status = 'ended'; c.duration = Math.round((c.endedAt - c.answeredAt) / 1000); } else c.status = String(c.from) === s.uid ? 'missed' : 'declined';
    c.save().catch(() => {});
  });
  s.on('disconnect', async () => {
    if (!io.sockets.adapter.rooms.has(s.uid)) await User.findByIdAndUpdate(s.uid, { lastSeen: new Date() }).catch(() => {});
    io.emit('presence', online());
  });
});

// ---------- Boot ----------
mongoose.connect(MONGO_URI).then(async () => {
  const email = (process.env.ADMIN_EMAIL || 'admin@bondhu.com').toLowerCase();
  if (!(await User.findOne({ email }))) await User.create({ name: 'Admin', email, role: 'admin', password: await bcrypt.hash(process.env.ADMIN_PASSWORD || 'admin123', 10) });
  server.listen(PORT, () => console.log('Server running on ' + PORT));
}).catch(e => { console.error('Mongo connection failed', e.message); process.exit(1); });
['SIGINT', 'SIGTERM'].forEach(sig => process.on(sig, () => { io.close(); server.close(() => mongoose.disconnect().then(() => process.exit(0))); }));
